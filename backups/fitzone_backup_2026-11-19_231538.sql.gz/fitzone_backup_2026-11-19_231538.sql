--
-- PostgreSQL database dump
--

\restrict 98VY5NnEcWNqXw9vv2j8injtRMWu5KWPeBkZjDgSFXqR2SznwZ4Ckd4W3Yre7D7

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.workout_plans DROP CONSTRAINT IF EXISTS workout_plans_trainer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workout_plans DROP CONSTRAINT IF EXISTS workout_plans_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_billing_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.staff DROP CONSTRAINT IF EXISTS staff_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.staff DROP CONSTRAINT IF EXISTS staff_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.staff DROP CONSTRAINT IF EXISTS staff_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.staff_attendance DROP CONSTRAINT IF EXISTS staff_attendance_staff_id_fkey;
ALTER TABLE IF EXISTS ONLY public.staff_attendance DROP CONSTRAINT IF EXISTS staff_attendance_marked_by_fkey;
ALTER TABLE IF EXISTS ONLY public.staff_attendance DROP CONSTRAINT IF EXISTS staff_attendance_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_trainer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.refunds DROP CONSTRAINT IF EXISTS refunds_refunded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.refunds DROP CONSTRAINT IF EXISTS refunds_payment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.refunds DROP CONSTRAINT IF EXISTS refunds_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.referrals DROP CONSTRAINT IF EXISTS referrals_referrer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.referrals DROP CONSTRAINT IF EXISTS referrals_referred_id_fkey;
ALTER TABLE IF EXISTS ONLY public.push_tokens DROP CONSTRAINT IF EXISTS push_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.push_tokens DROP CONSTRAINT IF EXISTS push_tokens_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.plans DROP CONSTRAINT IF EXISTS plans_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_membership_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.membership_plans DROP CONSTRAINT IF EXISTS membership_plans_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS members_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS members_referred_by_fkey;
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS members_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_memberships DROP CONSTRAINT IF EXISTS member_memberships_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_memberships DROP CONSTRAINT IF EXISTS member_memberships_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_memberships DROP CONSTRAINT IF EXISTS member_memberships_coupon_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_documents DROP CONSTRAINT IF EXISTS member_documents_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.maintenance_logs DROP CONSTRAINT IF EXISTS maintenance_logs_equipment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_converted_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_assigned_to_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_interactions DROP CONSTRAINT IF EXISTS lead_interactions_lead_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lead_interactions DROP CONSTRAINT IF EXISTS lead_interactions_done_by_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_payment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoice_sequences DROP CONSTRAINT IF EXISTS invoice_sequences_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gyms DROP CONSTRAINT IF EXISTS gyms_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gyms DROP CONSTRAINT IF EXISTS gyms_billing_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gym_role_permissions DROP CONSTRAINT IF EXISTS gym_role_permissions_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gym_module_configs DROP CONSTRAINT IF EXISTS gym_module_configs_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_added_by_fkey;
ALTER TABLE IF EXISTS ONLY public.equipment DROP CONSTRAINT IF EXISTS equipment_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.diet_plans DROP CONSTRAINT IF EXISTS diet_plans_trainer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.diet_plans DROP CONSTRAINT IF EXISTS diet_plans_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coupons DROP CONSTRAINT IF EXISTS coupons_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_manager_id_fkey;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_gym_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance DROP CONSTRAINT IF EXISTS attendance_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance DROP CONSTRAINT IF EXISTS attendance_marked_by_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance DROP CONSTRAINT IF EXISTS attendance_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ai_logs DROP CONSTRAINT IF EXISTS ai_logs_triggered_by_fkey;
ALTER TABLE IF EXISTS ONLY public.ai_logs DROP CONSTRAINT IF EXISTS ai_logs_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.achievements DROP CONSTRAINT IF EXISTS achievements_member_id_fkey;
DROP INDEX IF EXISTS public.uq_invoices_payment_id;
DROP INDEX IF EXISTS public.uq_gym_role_permissions;
DROP INDEX IF EXISTS public.uq_gym_module_configs;
DROP INDEX IF EXISTS public.uq_attendance_member_date;
DROP INDEX IF EXISTS public.idx_users_gym_role;
DROP INDEX IF EXISTS public.idx_users_branch;
DROP INDEX IF EXISTS public.idx_payments_member;
DROP INDEX IF EXISTS public.idx_payments_date;
DROP INDEX IF EXISTS public.idx_payments_branch_date;
DROP INDEX IF EXISTS public.idx_notifications_user;
DROP INDEX IF EXISTS public.idx_notifications_status;
DROP INDEX IF EXISTS public.idx_messages_is_active;
DROP INDEX IF EXISTS public.idx_messages_gym_branch;
DROP INDEX IF EXISTS public.idx_membership_plans_branch_active;
DROP INDEX IF EXISTS public.idx_members_branch_active;
DROP INDEX IF EXISTS public.idx_members_branch;
DROP INDEX IF EXISTS public.idx_member_memberships_status;
DROP INDEX IF EXISTS public.idx_member_memberships_member;
DROP INDEX IF EXISTS public.idx_member_memberships_composite;
DROP INDEX IF EXISTS public.idx_leads_status;
DROP INDEX IF EXISTS public.idx_leads_branch_status;
DROP INDEX IF EXISTS public.idx_leads_branch;
DROP INDEX IF EXISTS public.idx_invoices_payment;
DROP INDEX IF EXISTS public.idx_invoices_member;
DROP INDEX IF EXISTS public.idx_invoices_gym_number;
DROP INDEX IF EXISTS public.idx_invoices_gym_issued;
DROP INDEX IF EXISTS public.idx_invoices_branch_issued;
DROP INDEX IF EXISTS public.idx_expenses_branch_date;
DROP INDEX IF EXISTS public.idx_branches_gym_active;
DROP INDEX IF EXISTS public.idx_audit_logs_table;
DROP INDEX IF EXISTS public.idx_attendance_member;
DROP INDEX IF EXISTS public.idx_attendance_checkin;
DROP INDEX IF EXISTS public.idx_attendance_branch_date_status;
DROP INDEX IF EXISTS public.idx_attendance_branch_date;
DROP INDEX IF EXISTS public.idx_ai_logs_feature;
ALTER TABLE IF EXISTS ONLY public.workout_plans DROP CONSTRAINT IF EXISTS workout_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS uq_invoices_gym_invoice_number;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.staff DROP CONSTRAINT IF EXISTS staff_pkey;
ALTER TABLE IF EXISTS ONLY public.staff_attendance DROP CONSTRAINT IF EXISTS staff_attendance_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_gym_id_key_key;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_name_key;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.role_menu_items DROP CONSTRAINT IF EXISTS role_menu_items_pkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_pkey;
ALTER TABLE IF EXISTS ONLY public.refunds DROP CONSTRAINT IF EXISTS refunds_pkey;
ALTER TABLE IF EXISTS ONLY public.referrals DROP CONSTRAINT IF EXISTS referrals_pkey;
ALTER TABLE IF EXISTS ONLY public.push_tokens DROP CONSTRAINT IF EXISTS push_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.plans DROP CONSTRAINT IF EXISTS plans_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_module_action_key;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS menu_items_pkey;
ALTER TABLE IF EXISTS ONLY public.membership_plans DROP CONSTRAINT IF EXISTS membership_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS members_pkey;
ALTER TABLE IF EXISTS ONLY public.member_memberships DROP CONSTRAINT IF EXISTS member_memberships_pkey;
ALTER TABLE IF EXISTS ONLY public.member_documents DROP CONSTRAINT IF EXISTS member_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.maintenance_logs DROP CONSTRAINT IF EXISTS maintenance_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_pkey;
ALTER TABLE IF EXISTS ONLY public.lead_interactions DROP CONSTRAINT IF EXISTS lead_interactions_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_sequences DROP CONSTRAINT IF EXISTS invoice_sequences_pkey;
ALTER TABLE IF EXISTS ONLY public.gyms DROP CONSTRAINT IF EXISTS gyms_pkey;
ALTER TABLE IF EXISTS ONLY public.gym_role_permissions DROP CONSTRAINT IF EXISTS gym_role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.gym_module_configs DROP CONSTRAINT IF EXISTS gym_module_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.equipment DROP CONSTRAINT IF EXISTS equipment_pkey;
ALTER TABLE IF EXISTS ONLY public.diet_plans DROP CONSTRAINT IF EXISTS diet_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.coupons DROP CONSTRAINT IF EXISTS coupons_pkey;
ALTER TABLE IF EXISTS ONLY public.coupons DROP CONSTRAINT IF EXISTS coupons_code_key;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_pkey;
ALTER TABLE IF EXISTS ONLY public.billing_plans DROP CONSTRAINT IF EXISTS billing_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.attendance DROP CONSTRAINT IF EXISTS attendance_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_logs DROP CONSTRAINT IF EXISTS ai_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.achievements DROP CONSTRAINT IF EXISTS achievements_pkey;
DROP TABLE IF EXISTS public.workout_plans;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.subscriptions;
DROP TABLE IF EXISTS public.staff_attendance;
DROP TABLE IF EXISTS public.staff;
DROP TABLE IF EXISTS public.settings;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP TABLE IF EXISTS public.role_menu_items;
DROP TABLE IF EXISTS public.reviews;
DROP TABLE IF EXISTS public.refunds;
DROP TABLE IF EXISTS public.referrals;
DROP TABLE IF EXISTS public.push_tokens;
DROP TABLE IF EXISTS public.plans;
DROP TABLE IF EXISTS public.permissions;
DROP TABLE IF EXISTS public.payments;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.menu_items;
DROP TABLE IF EXISTS public.membership_plans;
DROP TABLE IF EXISTS public.members;
DROP TABLE IF EXISTS public.member_memberships;
DROP TABLE IF EXISTS public.member_documents;
DROP TABLE IF EXISTS public.maintenance_logs;
DROP TABLE IF EXISTS public.leads;
DROP TABLE IF EXISTS public.lead_interactions;
DROP TABLE IF EXISTS public.invoices;
DROP TABLE IF EXISTS public.invoice_sequences;
DROP TABLE IF EXISTS public.gyms;
DROP TABLE IF EXISTS public.gym_role_permissions;
DROP TABLE IF EXISTS public.gym_module_configs;
DROP TABLE IF EXISTS public.expenses;
DROP TABLE IF EXISTS public.equipment;
DROP TABLE IF EXISTS public.diet_plans;
DROP TABLE IF EXISTS public.coupons;
DROP TABLE IF EXISTS public.branches;
DROP TABLE IF EXISTS public.billing_plans;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.attendance;
DROP TABLE IF EXISTS public.ai_logs;
DROP TABLE IF EXISTS public.achievements;
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: achievements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.achievements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid,
    title character varying(255) NOT NULL,
    description text,
    date_earned date DEFAULT CURRENT_DATE NOT NULL,
    badge_icon character varying(100),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ai_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    feature character varying(100) NOT NULL,
    input_data jsonb,
    output_data jsonb,
    model_used character varying(100),
    tokens_used integer,
    latency_ms integer,
    triggered_by uuid,
    member_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    member_id uuid,
    check_in timestamp with time zone,
    check_out timestamp with time zone,
    check_in_method character varying(30) DEFAULT 'manual'::character varying,
    marked_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    attendance_date date DEFAULT CURRENT_DATE NOT NULL,
    status smallint DEFAULT 1 NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id uuid,
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: billing_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    price_monthly numeric(10,2),
    price_yearly numeric(10,2),
    max_branches integer,
    max_members integer,
    features jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    manager_id uuid,
    name character varying(200) NOT NULL,
    address text,
    city character varying(100),
    phone character varying(20),
    email character varying(255),
    opening_time time without time zone,
    closing_time time without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    code character varying(50) NOT NULL,
    discount_type character varying(20) NOT NULL,
    discount_value numeric(10,2) NOT NULL,
    max_uses integer,
    used_count integer DEFAULT 0,
    valid_from timestamp with time zone,
    valid_until timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: diet_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diet_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid,
    trainer_id uuid,
    title character varying(150),
    goal character varying(100),
    plan_details jsonb,
    ai_generated boolean DEFAULT false,
    valid_from date,
    valid_until date,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    name character varying(150) NOT NULL,
    category character varying(100),
    brand character varying(100),
    model_number character varying(100),
    purchase_date date,
    purchase_price numeric(10,2),
    warranty_until date,
    status character varying(30) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    category character varying(100),
    amount numeric(10,2) NOT NULL,
    description text,
    expense_date date NOT NULL,
    receipt_url text,
    added_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: gym_module_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gym_module_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    module_id character varying(100) NOT NULL,
    module_name character varying(150) NOT NULL,
    category character varying(100) DEFAULT 'MODULE SETTINGS'::character varying,
    path character varying(100),
    is_enabled boolean DEFAULT true NOT NULL,
    plan_tier character varying(50) DEFAULT 'Starter'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: gym_role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gym_role_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    role_id character varying(100) NOT NULL,
    permission_key character varying(100) NOT NULL,
    is_allowed boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: gyms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gyms (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id uuid,
    name character varying(200) NOT NULL,
    logo_url text,
    address text,
    city character varying(100),
    state character varying(100),
    country character varying(100) DEFAULT 'India'::character varying,
    pincode character varying(10),
    phone character varying(20),
    email character varying(255),
    gstin character varying(20),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    billing_plan_id uuid
);


--
-- Name: invoice_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_sequences (
    gym_id uuid NOT NULL,
    year_month character varying(6) NOT NULL,
    last_seq integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    payment_id uuid,
    member_id uuid,
    invoice_number character varying(100) NOT NULL,
    issued_date date DEFAULT CURRENT_DATE,
    due_date date,
    subtotal numeric(10,2),
    gst_rate numeric(5,2) DEFAULT 18.00,
    gst_amount numeric(10,2),
    total numeric(10,2),
    status character varying(30) DEFAULT 'paid'::character varying,
    pdf_url text,
    created_at timestamp with time zone DEFAULT now(),
    gym_id uuid,
    branch_id uuid,
    plan_name character varying(150),
    amount numeric(10,2),
    payment_mode character varying(50),
    issued_at timestamp with time zone DEFAULT now()
);


--
-- Name: lead_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lead_id uuid,
    interaction_type character varying(50),
    notes text,
    done_by uuid,
    interaction_date timestamp with time zone DEFAULT now()
);


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    full_name character varying(150) NOT NULL,
    email character varying(255),
    phone character varying(20),
    source character varying(100),
    interest_in character varying(150),
    status character varying(50) DEFAULT 'new'::character varying,
    assigned_to uuid,
    ai_score numeric(5,2),
    notes text,
    follow_up_date date,
    converted_member_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: maintenance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    equipment_id uuid,
    maintenance_type character varying(100),
    description text,
    cost numeric(10,2),
    serviced_by character varying(150),
    service_date date NOT NULL,
    next_service_date date,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: member_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid,
    doc_type character varying(100) NOT NULL,
    file_url text NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now()
);


--
-- Name: member_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_memberships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid,
    plan_id uuid,
    coupon_id uuid,
    start_date date NOT NULL,
    end_date date NOT NULL,
    freeze_start date,
    freeze_end date,
    status character varying(30) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    gym_id uuid,
    branch_id uuid
);


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    user_id uuid,
    referred_by uuid,
    full_name character varying(150) NOT NULL,
    email character varying(255),
    phone character varying(20) NOT NULL,
    date_of_birth date,
    gender character varying(20),
    address text,
    profile_photo_url text,
    emergency_contact_name character varying(150),
    emergency_contact_phone character varying(20),
    health_notes text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    join_date date
);


--
-- Name: membership_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    name character varying(150) NOT NULL,
    description text,
    duration_days integer NOT NULL,
    price numeric(10,2) NOT NULL,
    max_freeze_days integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    freeze_fee numeric(10,2) DEFAULT 0.00
);


--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(50) NOT NULL,
    path character varying(255),
    icon character varying(50),
    text character varying(100) NOT NULL,
    plan character varying(50),
    required_role character varying(50),
    sort_order integer DEFAULT 0 NOT NULL,
    is_placeholder boolean DEFAULT false NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    branch_id uuid,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    category character varying(100) DEFAULT 'Closure / Holiday'::character varying,
    priority character varying(50) DEFAULT 'Normal'::character varying,
    start_date date DEFAULT CURRENT_DATE,
    end_date date,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_sent_at timestamp with time zone,
    sent_count integer DEFAULT 0
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    user_id uuid,
    member_id uuid,
    type character varying(100) NOT NULL,
    channel character varying(30) NOT NULL,
    title character varying(255),
    body text,
    status character varying(30) DEFAULT 'pending'::character varying,
    scheduled_at timestamp with time zone,
    sent_at timestamp with time zone,
    ai_generated boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid,
    membership_id uuid,
    branch_id uuid,
    amount numeric(10,2) NOT NULL,
    payment_mode character varying(50),
    payment_ref character varying(255),
    payment_date timestamp with time zone DEFAULT now(),
    status character varying(30) DEFAULT 'completed'::character varying,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    gym_id uuid
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    description text
);


--
-- Name: plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    name character varying(255) NOT NULL,
    description text,
    duration_months integer NOT NULL,
    price numeric(10,2) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: push_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    member_id uuid,
    device_token text NOT NULL,
    platform character varying(20),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referrals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    referrer_id uuid,
    referred_id uuid,
    reward_given boolean DEFAULT false,
    reward_amount numeric(10,2),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: refunds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refunds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    payment_id uuid,
    member_id uuid,
    amount numeric(10,2) NOT NULL,
    reason text,
    refund_mode character varying(50),
    refund_ref character varying(255),
    refunded_by uuid,
    refunded_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    member_id uuid,
    trainer_id uuid,
    rating integer,
    review_text text,
    is_public boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: role_menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_menu_items (
    role_id uuid NOT NULL,
    menu_item_id uuid NOT NULL
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    is_accountant boolean DEFAULT false,
    is_default boolean DEFAULT false
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    key character varying(150) NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    user_id uuid,
    role_id uuid,
    full_name character varying(150) NOT NULL,
    email character varying(255),
    phone character varying(20),
    designation character varying(100),
    salary numeric(10,2),
    joining_date date,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: staff_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_attendance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    staff_id uuid,
    branch_id uuid,
    check_in timestamp with time zone NOT NULL,
    check_out timestamp with time zone,
    marked_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gym_id uuid,
    billing_plan_id uuid,
    status character varying(30) DEFAULT 'active'::character varying,
    trial_ends_at timestamp with time zone,
    current_period_start timestamp with time zone,
    current_period_end timestamp with time zone,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid,
    email character varying(255) NOT NULL,
    password_hash text NOT NULL,
    full_name character varying(150) NOT NULL,
    phone character varying(20),
    is_active boolean DEFAULT true,
    refresh_token text,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    gym_id uuid,
    branch_id uuid
);


--
-- Name: workout_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workout_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid,
    trainer_id uuid,
    title character varying(150),
    goal character varying(100),
    plan_details jsonb,
    ai_generated boolean DEFAULT false,
    valid_from date,
    valid_until date,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Data for Name: achievements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.achievements (id, member_id, title, description, date_earned, badge_icon, created_at) FROM stdin;
\.


--
-- Data for Name: ai_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_logs (id, feature, input_data, output_data, model_used, tokens_used, latency_ms, triggered_by, member_id, created_at) FROM stdin;
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance (id, branch_id, member_id, check_in, check_out, check_in_method, marked_by, created_at, attendance_date, status) FROM stdin;
1339d26f-a99d-476b-b25e-344a9fa32d2b	df582d89-ffe0-49d2-ad94-bb426725bfd6	c990fda2-a28d-4e5b-b905-6bef3bb0c51b	\N	\N	bulk	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-12 23:40:06.233232+05:30	2026-10-12	0
8f02582a-08ae-4f23-b09a-8c8a0c52aa77	df582d89-ffe0-49d2-ad94-bb426725bfd6	64a36616-38c9-4b44-a230-d599c46055ee	2026-10-12 23:39:00+05:30	2026-10-12 23:40:00+05:30	bulk	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-12 23:40:06.233232+05:30	2026-10-12	1
a1ace41b-5521-414f-9b8d-736fa85daf1f	df582d89-ffe0-49d2-ad94-bb426725bfd6	60745889-e140-4bcf-82f0-9f1f5c951bc0	2026-10-12 23:39:00+05:30	\N	bulk	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-12 23:40:06.233232+05:30	2026-10-12	1
350871fd-4a78-478c-a830-0ed08b7e568b	2b0c6048-dbf6-4dae-b831-48111246603e	94f23150-931e-4c30-893f-d0e460460961	2026-10-12 23:41:00+05:30	\N	bulk	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-12 23:41:40.822072+05:30	2026-10-12	1
f3cae23b-13fc-4d12-94c0-ef4b701f21cc	2b0c6048-dbf6-4dae-b831-48111246603e	8bebe1af-cd3c-413d-a009-fddf98b9cedd	2026-10-12 23:41:00+05:30	\N	bulk	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-12 23:41:40.822072+05:30	2026-10-12	1
2c1bab38-397e-4bcf-aa87-d77405a9db2a	1cc93c71-1c46-490f-97a7-1a14b831df75	35ac6c34-3fc4-4843-931b-76a89e093583	2026-11-01 22:07:53.346033+05:30	\N	manual	\N	2026-11-01 22:07:53.346033+05:30	2026-11-01	1
5c82bbff-30cb-4441-99c1-eeb6f1c90f28	1cc93c71-1c46-490f-97a7-1a14b831df75	98bb4c45-cf11-4e40-bff5-aa8224bc99da	2026-11-01 22:07:53.464795+05:30	\N	manual	\N	2026-11-01 22:07:53.464795+05:30	2026-11-01	0
008830b4-c292-4ba7-84b6-0e2636a8f2f1	df582d89-ffe0-49d2-ad94-bb426725bfd6	c990fda2-a28d-4e5b-b905-6bef3bb0c51b	2026-10-18 20:24:00+05:30	\N	bulk	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-18 22:22:10.557098+05:30	2026-10-18	1
e51bf8b4-a1b3-4cf2-ba23-40140c31c755	df582d89-ffe0-49d2-ad94-bb426725bfd6	64a36616-38c9-4b44-a230-d599c46055ee	\N	\N	bulk	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-18 22:22:10.557098+05:30	2026-10-18	0
f5cde0f0-842d-45ee-a932-5e9aa207690a	df582d89-ffe0-49d2-ad94-bb426725bfd6	60745889-e140-4bcf-82f0-9f1f5c951bc0	\N	\N	bulk	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-18 22:22:10.557098+05:30	2026-10-18	0
ae34dece-2fe4-44a1-b0b4-3e553a3453d1	1cc93c71-1c46-490f-97a7-1a14b831df75	8eb492bf-7d7c-4a49-a2c9-e35c027518f4	\N	\N	manual	\N	2026-11-01 22:07:53.503237+05:30	2026-11-01	1
8fb47e13-e7b9-48ac-864a-cb7fc400c07c	5a487df0-199b-4b34-b88e-c83dac808811	5a9fb1b0-7078-4d6a-8d06-247464e152b3	2026-11-01 18:05:59.381287+05:30	\N	manual	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 18:05:59.381287+05:30	2026-11-01	1
1dda79e4-37b9-4f5c-927e-1c5363e17942	5a487df0-199b-4b34-b88e-c83dac808811	9939e769-7d03-41d7-bbb9-49da78ff6787	2026-11-01 18:06:19.320891+05:30	\N	manual	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 18:06:19.320891+05:30	2026-11-01	1
5a456abb-a283-4e43-9a1d-d5ffe72cbd71	0f965952-0b37-4401-aa79-87b7e9ba982b	fcf44996-90e5-4781-886e-f1ed86a4e0f0	2026-11-01 22:07:53.563481+05:30	\N	manual	\N	2026-11-01 22:07:53.563481+05:30	2026-11-01	1
ca4da615-41b9-4ce6-ba02-1a01495deb52	5a487df0-199b-4b34-b88e-c83dac808811	7fcb3c33-454c-4e3f-8c98-77eae7068aa1	2026-11-01 19:17:29.92548+05:30	\N	manual	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 19:17:29.92548+05:30	2026-11-01	1
e2cc2a25-0737-4436-be23-511684677c8a	91a5f79e-a8b8-4749-b043-65533e7c8a3b	46a50eaa-a751-4bc1-9e6f-82e45997db55	2026-11-01 22:07:53.721106+05:30	\N	manual	\N	2026-11-01 22:07:53.721106+05:30	2026-11-01	1
643e0b33-a693-4669-b364-a703b195e94b	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	a35bda2a-8ebf-4ebd-85a7-55db7d52d15a	\N	\N	bulk	6168be6b-2f29-4cd3-b99c-c4b5dcea828c	2026-11-01 22:08:16.56397+05:30	2026-11-01	0
49adf93c-25e5-4995-b327-b85c5a548674	5b667fea-b783-49d0-a8e3-e85be41f5943	147a2fb6-a81c-40c0-8cce-89e504ffaa1f	2026-11-01 22:08:03.508468+05:30	2026-11-01 22:08:03.541484+05:30	manual	c979ce6f-4e70-4d21-8cd8-f3863fb7c25e	2026-11-01 22:08:03.508468+05:30	2026-11-01	1
c73eb8fb-789d-48c8-abbc-61c109f0f5d7	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	36e83cee-3658-4935-bdb0-b87e92b69025	\N	\N	bulk	6168be6b-2f29-4cd3-b99c-c4b5dcea828c	2026-11-01 22:08:16.353901+05:30	2026-11-01	0
e52e5c06-01f5-44a1-8d3e-9eeb9a7685b6	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	7c1f4539-1e36-4c84-8528-6f6a5ede7be8	2026-11-01 22:08:16.413+05:30	\N	bulk	6168be6b-2f29-4cd3-b99c-c4b5dcea828c	2026-11-01 22:08:16.353901+05:30	2026-11-01	1
96abba62-c776-4eaa-8af0-b8c63dc1cea6	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	c67eebf9-b9f9-4675-aa45-e3a73eae914e	2026-11-01 22:08:16.413+05:30	\N	bulk	6168be6b-2f29-4cd3-b99c-c4b5dcea828c	2026-11-01 22:08:16.353901+05:30	2026-11-01	1
58629e63-265d-4e25-8109-9ef1302d7e3b	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	dcb99703-aacb-433e-843d-766fe82b7fe2	\N	\N	bulk	6168be6b-2f29-4cd3-b99c-c4b5dcea828c	2026-11-01 22:08:16.60223+05:30	2026-11-01	0
66f2221e-c3c7-495a-b441-f869e658a3fc	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	faed8c47-af39-4ea8-8145-ee40cda43b0f	2026-10-29 14:30:00+05:30	2026-10-29 15:30:00+05:30	bulk	6f722507-98f3-4df9-b4ad-974a39c5224f	2026-11-01 21:49:26.526829+05:30	2026-10-29	1
1b406ea3-4919-4fa7-bbaa-8698ca7679d1	e1d06c17-154f-40dc-a736-6e5d45aff429	e98fd142-eae8-43a6-ba0c-8d668b89d1eb	2026-10-29 14:30:00+05:30	2026-10-29 15:30:00+05:30	bulk	effce214-fa1d-441c-a8f1-854cf73e0e28	2026-11-01 22:08:27.727716+05:30	2026-10-29	1
4bbbaf47-809c-45d7-80a0-1d815e00c022	e1d06c17-154f-40dc-a736-6e5d45aff429	13fab36d-cefa-4bf9-a090-8c1277b1b200	2026-10-29 16:30:00+05:30	\N	bulk	effce214-fa1d-441c-a8f1-854cf73e0e28	2026-11-01 22:08:27.727716+05:30	2026-10-29	1
3e2662bc-efc8-4637-a7fe-3a0b0bb0ebe8	e1d06c17-154f-40dc-a736-6e5d45aff429	61ba65a8-d8ba-4894-bc1b-2b5385306b0b	\N	\N	bulk	effce214-fa1d-441c-a8f1-854cf73e0e28	2026-11-01 22:08:27.727716+05:30	2026-10-29	0
11a1fb38-7daf-403b-ada5-64ce6bf3252a	e1d06c17-154f-40dc-a736-6e5d45aff429	e98fd142-eae8-43a6-ba0c-8d668b89d1eb	2026-11-01 13:30:00+05:30	\N	bulk	effce214-fa1d-441c-a8f1-854cf73e0e28	2026-11-01 22:08:28.516847+05:30	2026-11-01	1
a8221879-7d9e-4c63-95fc-21e1ede6b957	e1d06c17-154f-40dc-a736-6e5d45aff429	13fab36d-cefa-4bf9-a090-8c1277b1b200	2026-11-01 14:00:00+05:30	\N	bulk	effce214-fa1d-441c-a8f1-854cf73e0e28	2026-11-01 22:08:28.516847+05:30	2026-11-01	1
ce8f03b0-8bdf-4f27-96c7-6454e80aef95	e1d06c17-154f-40dc-a736-6e5d45aff429	61ba65a8-d8ba-4894-bc1b-2b5385306b0b	\N	\N	bulk	effce214-fa1d-441c-a8f1-854cf73e0e28	2026-11-01 22:08:28.516847+05:30	2026-11-01	0
c42da6dc-472d-469e-9e12-02eb3671b290	5a487df0-199b-4b34-b88e-c83dac808811	b240b856-dea9-4f0b-8d23-1c1c43d5cc56	2026-11-01 21:20:40.245088+05:30	\N	manual	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 21:20:40.245088+05:30	2026-11-01	1
9c513355-afb4-4109-9c4d-8bd075c10d42	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	a4ee66ca-a5fe-4103-a02b-a5231fc1fd15	2026-10-29 16:30:00+05:30	\N	bulk	6f722507-98f3-4df9-b4ad-974a39c5224f	2026-11-01 21:49:26.526829+05:30	2026-10-29	1
442cd495-dfdb-443c-a33c-e41ee8f71d4d	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	af29c170-4319-4099-8da5-e6c3d4285a0d	2026-10-29 14:30:00+05:30	2026-10-29 15:30:00+05:30	bulk	5f1e873a-b483-484a-ad12-b3749f16d61b	2026-11-01 21:46:16.195084+05:30	2026-10-29	1
beb933b8-bd9d-4d69-b947-a3692eecdaf2	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	80256997-b191-41d4-b0da-aabe82109df1	2026-10-29 16:30:00+05:30	\N	bulk	5f1e873a-b483-484a-ad12-b3749f16d61b	2026-11-01 21:46:16.195084+05:30	2026-10-29	1
fec70083-1529-45c9-8660-7a1410383671	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	683f13bb-46a7-4d88-a7cc-9c28f514f5a4	\N	\N	bulk	5f1e873a-b483-484a-ad12-b3749f16d61b	2026-11-01 21:46:16.195084+05:30	2026-10-29	0
052cde8f-0b81-4ee5-bf3f-6a52ad2f0475	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	af29c170-4319-4099-8da5-e6c3d4285a0d	2026-11-01 13:30:00+05:30	\N	bulk	5f1e873a-b483-484a-ad12-b3749f16d61b	2026-11-01 21:46:17.064144+05:30	2026-11-01	1
4a2e60ba-57a9-41a3-a4e3-1e1a69761739	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	80256997-b191-41d4-b0da-aabe82109df1	2026-11-01 14:00:00+05:30	\N	bulk	5f1e873a-b483-484a-ad12-b3749f16d61b	2026-11-01 21:46:17.064144+05:30	2026-11-01	1
5b2c0260-f78e-4551-9b93-d6526ac8fa97	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	683f13bb-46a7-4d88-a7cc-9c28f514f5a4	\N	\N	bulk	5f1e873a-b483-484a-ad12-b3749f16d61b	2026-11-01 21:46:17.064144+05:30	2026-11-01	0
f0d64138-e8be-4905-8cdc-8fdd7b50a25f	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	f395d9c1-2c4d-4a6f-9558-384a0c2f502e	2026-10-29 14:30:00+05:30	2026-10-29 15:30:00+05:30	bulk	a01f4be1-1d3a-424e-8561-46a836a99c1b	2026-11-01 21:48:13.770366+05:30	2026-10-29	1
9a9ea2dd-6327-4e42-af07-ceb912449e90	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	f0b3d976-2ddb-4817-b1ef-ae51abb7f133	2026-10-29 16:30:00+05:30	\N	bulk	a01f4be1-1d3a-424e-8561-46a836a99c1b	2026-11-01 21:48:13.770366+05:30	2026-10-29	1
f3709c02-9e28-47ff-aefb-a6b67c9434c5	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	ce1799c1-fcfb-43e8-a06b-685bd0a39dd0	\N	\N	bulk	a01f4be1-1d3a-424e-8561-46a836a99c1b	2026-11-01 21:48:13.770366+05:30	2026-10-29	0
a58aedc1-c9a6-44ba-9f1c-966965c7e4f3	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	f395d9c1-2c4d-4a6f-9558-384a0c2f502e	2026-11-01 13:30:00+05:30	\N	bulk	a01f4be1-1d3a-424e-8561-46a836a99c1b	2026-11-01 21:48:14.422881+05:30	2026-11-01	1
53b9971e-c7ec-46a3-a5ee-a847aa4e0731	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	f0b3d976-2ddb-4817-b1ef-ae51abb7f133	2026-11-01 14:00:00+05:30	\N	bulk	a01f4be1-1d3a-424e-8561-46a836a99c1b	2026-11-01 21:48:14.422881+05:30	2026-11-01	1
28b7b3ec-b9f3-4d79-8718-d727b66b8b82	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	ce1799c1-fcfb-43e8-a06b-685bd0a39dd0	\N	\N	bulk	a01f4be1-1d3a-424e-8561-46a836a99c1b	2026-11-01 21:48:14.422881+05:30	2026-11-01	0
0cf6654b-dd13-42f2-84da-8258ec69b7e4	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	1741dfb5-4ec3-489e-8a91-c39d64a3d7f0	\N	\N	bulk	6f722507-98f3-4df9-b4ad-974a39c5224f	2026-11-01 21:49:26.526829+05:30	2026-10-29	0
47269417-5761-43e8-94e6-856d1034e2f3	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	faed8c47-af39-4ea8-8145-ee40cda43b0f	2026-11-01 13:30:00+05:30	\N	bulk	6f722507-98f3-4df9-b4ad-974a39c5224f	2026-11-01 21:49:27.097016+05:30	2026-11-01	1
9a7e8145-4c11-4136-80bc-2342699ebf20	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	a4ee66ca-a5fe-4103-a02b-a5231fc1fd15	2026-11-01 14:00:00+05:30	\N	bulk	6f722507-98f3-4df9-b4ad-974a39c5224f	2026-11-01 21:49:27.097016+05:30	2026-11-01	1
64b66c68-4fb2-451b-911e-405306d13775	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	1741dfb5-4ec3-489e-8a91-c39d64a3d7f0	\N	\N	bulk	6f722507-98f3-4df9-b4ad-974a39c5224f	2026-11-01 21:49:27.097016+05:30	2026-11-01	0
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) FROM stdin;
bb722737-1d61-4845-b02b-780a6e1910cc	16b698d3-8127-48cd-aebc-5803e3d4a812	HOLD_FEES	member_memberships	11779802-9cd1-4f0f-9a1b-3524bd35650f	{"status": "active", "end_date": "2026-11-29T18:30:00.000Z"}	{"reason": "Medical leave", "status": "on_hold", "freeze_end": "2026-11-11", "freeze_fee": 150, "freeze_start": "2026-11-01", "projected_end_date": "2026-12-10"}	\N	\N	2026-11-01 18:05:59.211674+05:30
f343bd25-e35f-4302-a3ce-2f8eafca9a87	16b698d3-8127-48cd-aebc-5803e3d4a812	RESUME_FEES	member_memberships	11779802-9cd1-4f0f-9a1b-3524bd35650f	{"status": "on_hold", "end_date": "2026-11-29T18:30:00.000Z"}	{"status": "active", "end_date": "2026-12-05", "resumed_at": "2026-11-06", "days_extended": 5}	\N	\N	2026-11-01 18:05:59.348175+05:30
bb8fa819-bc5b-4a95-95cc-ce9ab322e8eb	16b698d3-8127-48cd-aebc-5803e3d4a812	HOLD_FEES	member_memberships	db270b18-bad4-432e-b776-f77b04ca25d0	{"status": "active", "end_date": "2026-11-29T18:30:00.000Z"}	{"reason": "Medical leave", "status": "on_hold", "freeze_end": "2026-11-11", "freeze_fee": 150, "freeze_start": "2026-11-01", "projected_end_date": "2026-12-10"}	\N	\N	2026-11-01 18:06:19.213507+05:30
da254a3c-d86b-4f29-8084-833722b3fc8f	16b698d3-8127-48cd-aebc-5803e3d4a812	RESUME_FEES	member_memberships	db270b18-bad4-432e-b776-f77b04ca25d0	{"status": "on_hold", "end_date": "2026-11-29T18:30:00.000Z"}	{"status": "active", "end_date": "2026-12-05", "resumed_at": "2026-11-06", "days_extended": 5}	\N	\N	2026-11-01 18:06:19.301907+05:30
5b6ba522-1c1d-409a-adce-8383906f840f	16b698d3-8127-48cd-aebc-5803e3d4a812	HOLD_FEES	member_memberships	86afd5c8-13c1-40ac-85c2-d7b8d5bc2fd1	{"status": "active", "end_date": "2026-11-29T18:30:00.000Z"}	{"reason": "Medical leave", "status": "on_hold", "freeze_end": "2026-11-11", "freeze_fee": 150, "freeze_start": "2026-11-01", "projected_end_date": "2026-12-10"}	\N	\N	2026-11-01 19:17:29.805343+05:30
057dfd48-2796-498a-922b-41ba8ad2777f	16b698d3-8127-48cd-aebc-5803e3d4a812	RESUME_FEES	member_memberships	86afd5c8-13c1-40ac-85c2-d7b8d5bc2fd1	{"status": "on_hold", "end_date": "2026-11-29T18:30:00.000Z"}	{"status": "active", "end_date": "2026-12-05", "resumed_at": "2026-11-06", "days_extended": 5}	\N	\N	2026-11-01 19:17:29.904666+05:30
f19b3500-4101-40af-9c5b-4522dea62c92	16b698d3-8127-48cd-aebc-5803e3d4a812	HOLD_FEES	member_memberships	ce09e4f6-d812-4741-b508-993d56a825ac	{"status": "active", "end_date": "2026-11-29T18:30:00.000Z"}	{"reason": "Medical leave", "status": "on_hold", "freeze_end": "2026-11-11", "freeze_fee": 150, "freeze_start": "2026-11-01", "projected_end_date": "2026-12-10"}	\N	\N	2026-11-01 21:20:40.092611+05:30
90c28237-dfa2-46dc-8d07-4480d911bd5e	16b698d3-8127-48cd-aebc-5803e3d4a812	RESUME_FEES	member_memberships	ce09e4f6-d812-4741-b508-993d56a825ac	{"status": "on_hold", "end_date": "2026-11-29T18:30:00.000Z"}	{"status": "active", "end_date": "2026-12-05", "resumed_at": "2026-11-06", "days_extended": 5}	\N	\N	2026-11-01 21:20:40.212514+05:30
\.


--
-- Data for Name: billing_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_plans (id, name, price_monthly, price_yearly, max_branches, max_members, features, is_active, created_at) FROM stdin;
075277f5-1867-4052-bece-beb82bbcdacd	Starter	999.00	9990.00	1	200	{"modules": ["dashboard", "gym", "branches", "members", "membership_plans", "attendance", "payments", "settings", "billing_plans"]}	t	2026-08-15 17:59:31.561076+05:30
ea0ba9e9-7545-4935-b8a0-6ffc971bb2a2	Pro	4999.00	49990.00	10	5000	{"modules": ["dashboard", "gym", "branches", "members", "membership_plans", "staff", "attendance", "payments", "expenses", "reports", "notifications", "leads", "billing", "rbac", "equipment", "reviews", "coupons", "settings", "billing_plans"]}	t	2026-08-15 17:59:31.561076+05:30
ad095cb8-77a6-4f3a-8254-6b2848401832	Enterprise	9999.00	99990.00	-1	-1	{"modules": ["dashboard", "gym", "branches", "members", "membership_plans", "staff", "attendance", "payments", "expenses", "reports", "notifications", "leads", "billing", "rbac", "equipment", "reviews", "coupons", "ai_chatbot", "ai_insights", "ai_churn", "ai_forecasting", "ai_workout", "trainer_portal", "member_portal", "settings", "billing_plans"]}	t	2026-08-15 17:59:31.561076+05:30
8a5ef42e-8982-43cc-a8f7-fbf6c2bebfc9	Growth	2499.00	24990.00	5	1000	{"modules": ["dashboard", "gym", "branches", "members", "membership_plans", "staff", "attendance", "payments", "expenses", "reports", "notifications", "leads", "settings", "billing_plans"]}	t	2026-08-15 17:59:31.561076+05:30
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (id, gym_id, manager_id, name, address, city, phone, email, opening_time, closing_time, is_active, created_at, updated_at) FROM stdin;
2b0c6048-dbf6-4dae-b831-48111246603e	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	Erode Branch 1	\N	\N	\N	\N	\N	\N	t	2026-10-11 11:28:51.700299+05:30	2026-10-11 11:28:51.700299+05:30
df582d89-ffe0-49d2-ad94-bb426725bfd6	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	Sankari branch	\N	\N	\N	\N	\N	\N	t	2026-10-11 11:29:06.736455+05:30	2026-10-11 11:29:06.736455+05:30
630b3844-e660-45a5-bdbc-abc8c0f19802	4e440296-d558-46e6-b0f6-5fad5910a8f3	\N	Test Gym- Branch -1	\N	\N	\N	branch1@gmail.com	\N	\N	t	2026-10-18 22:32:00.293024+05:30	2026-10-18 22:32:00.293024+05:30
38af11b9-0eff-41b0-9cac-a40a74fb31cf	4e440296-d558-46e6-b0f6-5fad5910a8f3	\N	Test Gym- Branch -2	\N	\N	\N	\N	\N	\N	t	2026-10-18 22:32:15.081747+05:30	2026-10-18 22:32:15.081747+05:30
5a487df0-199b-4b34-b88e-c83dac808811	e85928f5-e06d-4663-84ba-697347816efb	\N	P4 Main Branch	Connaught Place	\N	9876540002	\N	\N	\N	t	2026-11-01 18:04:34.640424+05:30	2026-11-01 18:04:34.640424+05:30
74582c4a-396e-4b56-8b86-b382d6769c85	e52d93f7-cb46-4285-bec1-ff2016ccc39c	\N	P4 Other Branch	Noida Sec 18	\N	9876540004	\N	\N	\N	t	2026-11-01 18:04:34.648053+05:30	2026-11-01 18:04:34.648053+05:30
9bc40a4f-d182-4a9b-817b-16979b96ac1d	59179c14-86e4-4950-8833-74c46736bbee	\N	P5 Main Branch	Bandra West	\N	9876541112	\N	\N	\N	t	2026-11-01 19:14:16.943346+05:30	2026-11-01 19:14:16.943346+05:30
bef3c9f9-e15c-435d-8615-3419ca30d617	b2bcd449-334f-482e-8f90-d1e731ac6ca9	\N	P5 Other Branch	Andheri East	\N	9876542222	\N	\N	\N	t	2026-11-01 19:14:16.952684+05:30	2026-11-01 19:14:16.952684+05:30
1cc93c71-1c46-490f-97a7-1a14b831df75	2a5efdd1-aebf-4f3a-93de-fe673d727a55	\N	Branch 1A	South Delhi	\N	9876550002	\N	\N	\N	t	2026-11-01 21:11:16.475623+05:30	2026-11-01 21:11:16.475623+05:30
0f965952-0b37-4401-aa79-87b7e9ba982b	2a5efdd1-aebf-4f3a-93de-fe673d727a55	\N	Branch 1B	North Delhi	\N	9876550003	\N	\N	\N	t	2026-11-01 21:11:16.487142+05:30	2026-11-01 21:11:16.487142+05:30
91a5f79e-a8b8-4749-b043-65533e7c8a3b	46e49c9f-3bea-4b93-a86f-40b886ecdb60	\N	Branch 2	Gurugram	\N	9876550005	\N	\N	\N	t	2026-11-01 21:11:16.495247+05:30	2026-11-01 21:11:16.495247+05:30
5b667fea-b783-49d0-a8e3-e85be41f5943	8c35c396-7f04-4802-9ed5-ecc4c12dc81b	\N	Main Branch	Hauz Khas	\N	9876560002	\N	\N	\N	t	2026-11-01 21:19:08.958886+05:30	2026-11-01 21:19:08.958886+05:30
dacc9432-e01e-4120-8f8a-780741558570	35fc5264-607e-4663-a79b-03a756984e78	\N	Other Branch	Noida	\N	9876560004	\N	\N	\N	t	2026-11-01 21:19:08.970511+05:30	2026-11-01 21:19:08.970511+05:30
e0aa422e-a36f-4dde-8b5f-3298d0ae457c	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	\N	P3 Branch 1A	Lajpat Nagar	\N	9876570002	\N	\N	\N	t	2026-11-01 21:29:28.140481+05:30	2026-11-01 21:29:28.140481+05:30
18b12db8-93a1-4aa8-9c59-a21419e01fe6	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	\N	P3 Branch 1B	Dwarka	\N	9876570003	\N	\N	\N	t	2026-11-01 21:29:28.17281+05:30	2026-11-01 21:29:28.17281+05:30
de39de91-f4e1-4ac4-b856-aa8025115452	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	P3 Branch 2	Gurgaon	\N	9876570005	\N	\N	\N	t	2026-11-01 21:29:28.188774+05:30	2026-11-01 21:29:28.188774+05:30
410904fb-423a-4d73-aa83-e5daf643968f	e93d6a19-7d4a-4032-956b-3b5a0936bc2c	\N	D5 Main Branch	456 Bulk Way	\N	9888877701	\N	\N	\N	t	2026-11-01 21:42:20.615813+05:30	2026-11-01 21:42:20.615813+05:30
1a79c630-5a33-41ab-8655-5271e28e0939	fbc2ba24-7886-403e-b2f1-0c88e3926eae	\N	D5 Main Branch	456 Bulk Way	\N	9888877701	\N	\N	\N	t	2026-11-01 21:43:19.050304+05:30	2026-11-01 21:43:19.050304+05:30
da0c0d64-6ea2-4e55-9a46-75dfa4d0bb93	a7210f47-0738-4176-981e-d1c2a50d4438	\N	D5 Main Branch	456 Bulk Way	\N	988877211	\N	\N	\N	t	2026-11-01 21:43:55.469351+05:30	2026-11-01 21:43:55.469351+05:30
89f1214c-6ca0-4077-b2e6-ad3f53a62c0d	f666a106-2ccf-4682-8941-2949c3230de2	\N	D5 Main Branch	456 Bulk Way	\N	988875826	\N	\N	\N	t	2026-11-01 21:44:35.334928+05:30	2026-11-01 21:44:35.334928+05:30
0371cdb0-821d-442e-855d-cc2f814130ca	c0452148-dc36-40d0-92bb-1d9870fe0d15	\N	D5 Main Branch	456 Bulk Way	\N	988875660	\N	\N	\N	t	2026-11-01 21:44:55.616455+05:30	2026-11-01 21:44:55.616455+05:30
ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	3c5ea471-e574-4ffe-a088-437928965419	\N	D5 Main Branch	456 Bulk Way	\N	988878509	\N	\N	\N	t	2026-11-01 21:46:15.651625+05:30	2026-11-01 21:46:15.651625+05:30
0520e7ac-8ac2-45f1-88f7-1027595bc2c3	e008d4f0-a775-42c9-a8ca-7475c89df3b2	\N	D5 Main Branch	456 Bulk Way	\N	988872171	\N	\N	\N	t	2026-11-01 21:48:13.168015+05:30	2026-11-01 21:48:13.168015+05:30
c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	07181c9d-8f25-42c9-a2ee-8fb959a5a373	\N	D5 Main Branch	456 Bulk Way	\N	988873855	\N	\N	\N	t	2026-11-01 21:49:25.878768+05:30	2026-11-01 21:49:25.878768+05:30
e1d06c17-154f-40dc-a736-6e5d45aff429	bb849e64-96a4-4091-997d-c52fbff6ed8b	\N	D5 Main Branch	456 Bulk Way	\N	988878852	\N	\N	\N	t	2026-11-01 22:08:27.104901+05:30	2026-11-01 22:08:27.104901+05:30
9a09c837-a0e5-4fa5-8c5c-1ab356d8fe7c	01fdeb6f-44c1-4996-9a49-03c085f11d3d	\N	D6 Branch Test	123 Main St	\N	9887711223	\N	\N	\N	t	2026-11-01 22:18:12.324712+05:30	2026-11-01 22:18:12.324712+05:30
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupons (id, gym_id, code, discount_type, discount_value, max_uses, used_count, valid_from, valid_until, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: diet_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.diet_plans (id, member_id, trainer_id, title, goal, plan_details, ai_generated, valid_from, valid_until, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.equipment (id, branch_id, name, category, brand, model_number, purchase_date, purchase_price, warranty_until, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, branch_id, category, amount, description, expense_date, receipt_url, added_by, created_at) FROM stdin;
3c43abd9-6123-4497-ab06-f2c333999deb	2b0c6048-dbf6-4dae-b831-48111246603e	Utilities	5000.00	Electricity Gym 2	2026-10-31	\N	\N	2026-10-31 23:07:14.136244+05:30
dbfad9ee-3ab2-445e-9f42-a275b1ae831b	630b3844-e660-45a5-bdbc-abc8c0f19802	Equipment	200.00	Test Expense Restrict	2026-11-01	\N	\N	2026-11-01 11:27:03.28572+05:30
\.


--
-- Data for Name: gym_module_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gym_module_configs (id, gym_id, module_id, module_name, category, path, is_enabled, plan_tier, created_at, updated_at) FROM stdin;
0eb92c5c-01b4-46b7-80f6-fb90ca222952	\N	members	Members	MODULE SETTINGS	/members	t	Starter	2026-10-25 12:22:51.181632+05:30	2026-10-25 12:22:51.181632+05:30
fe6c4541-a21c-49db-a397-7757c996d554	\N	staff	Staff & Trainers	MODULE SETTINGS	/staff	t	Growth	2026-10-25 12:22:51.192088+05:30	2026-10-25 12:22:51.192088+05:30
ca9b945a-7202-4d9f-bfda-62aa06acb6d8	\N	attendance	Attendance & Access	MODULE SETTINGS	/attendance	t	Starter	2026-10-25 12:22:51.194953+05:30	2026-10-25 12:22:51.194953+05:30
1dbf208e-6d15-44c2-9648-abac1cb61225	\N	payments	Payments & Billing	MODULE SETTINGS	/payments	t	Starter	2026-10-25 12:22:51.197331+05:30	2026-10-25 12:22:51.197331+05:30
86bc31ba-d428-43c5-ab31-5c59aa9be7d3	\N	membership_plans	Membership Plans	MODULE SETTINGS	/membership-plans	t	Starter	2026-10-25 12:22:51.199653+05:30	2026-10-25 12:22:51.199653+05:30
f049ef45-3500-4f50-9358-39617acf4f65	\N	leads_crm	Leads / CRM	MODULE SETTINGS	/leads-crm	t	Growth	2026-10-25 12:22:51.201109+05:30	2026-10-25 12:22:51.201109+05:30
c0028647-1d0b-48e0-9775-2d0715b43826	\N	workout_diet_ai	Workout / Diet AI	MODULE SETTINGS	/workout-diet-ai	t	Enterprise	2026-10-25 12:22:51.203067+05:30	2026-10-25 12:22:51.203067+05:30
47ac3d17-cb2c-4ef8-a94d-a978bc256276	\N	equipment	Equipment & Maintenance	MODULE SETTINGS	/equipment	t	Pro	2026-10-25 12:22:51.204404+05:30	2026-10-25 12:22:51.204404+05:30
d6800774-c06e-4cc5-9a6c-6f4c57739441	\N	expenses	Expenses Tracker	MODULE SETTINGS	/expenses	t	Growth	2026-10-25 12:22:51.205672+05:30	2026-10-25 12:22:51.205672+05:30
0ac88e45-5d68-43f2-998c-61b773fe6a3e	\N	messages	Messages & Notices	MODULE SETTINGS	/messages	t	Starter	2026-10-30 07:41:27.133299+05:30	2026-10-30 07:41:27.133299+05:30
\.


--
-- Data for Name: gym_role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gym_role_permissions (id, gym_id, role_id, permission_key, is_allowed, created_at, updated_at) FROM stdin;
9bfe3493-7d6a-4a1e-a4ef-cc9459bf3066	\N	admin	members:view	t	2026-10-25 12:22:51.211311+05:30	2026-10-25 12:22:51.211311+05:30
228c13d4-dc7f-4314-bc05-b0f92e00f67c	\N	admin	members:add	t	2026-10-25 12:22:51.214207+05:30	2026-10-25 12:22:51.214207+05:30
abdc4263-6ea4-41c6-980f-5bcd3e95b1b0	\N	admin	members:edit	t	2026-10-25 12:22:51.215309+05:30	2026-10-25 12:22:51.215309+05:30
cc172dfb-835c-43e1-bbe8-aa61c01b22f2	\N	admin	members:delete	t	2026-10-25 12:22:51.216407+05:30	2026-10-25 12:22:51.216407+05:30
f237d7cd-5572-4fd0-87b5-c7503434b225	\N	admin	members:duplicate	t	2026-10-25 12:22:51.217321+05:30	2026-10-25 12:22:51.217321+05:30
5d31dc5a-ab9a-4a7b-9476-0ad67bcd397c	\N	admin	members:import	t	2026-10-25 12:22:51.220025+05:30	2026-10-25 12:22:51.220025+05:30
9cdcb907-330d-4672-85b9-b2f7e935dc70	\N	admin	members:export	t	2026-10-25 12:22:51.221882+05:30	2026-10-25 12:22:51.221882+05:30
52745a14-00bc-44a7-b76d-ece2d2ada549	\N	admin	members:hold_fees	t	2026-10-25 12:22:51.222759+05:30	2026-10-25 12:22:51.222759+05:30
bf85bd93-4109-4680-b6c1-64111a578197	\N	admin	staff:view	t	2026-10-25 12:22:51.224054+05:30	2026-10-25 12:22:51.224054+05:30
40dbed07-24a3-4797-9028-c7cf561351e9	\N	admin	staff:add	t	2026-10-25 12:22:51.225534+05:30	2026-10-25 12:22:51.225534+05:30
e45e66c4-80c7-466f-9ac1-cc9e3b4196dd	\N	admin	staff:edit	t	2026-10-25 12:22:51.22691+05:30	2026-10-25 12:22:51.22691+05:30
72316913-692e-48fe-af2c-0ebf9849b6a4	\N	admin	staff:delete	t	2026-10-25 12:22:51.228148+05:30	2026-10-25 12:22:51.228148+05:30
9f7c4cee-4cdd-495c-9782-888066c7e54b	\N	admin	staff:assign	t	2026-10-25 12:22:51.229332+05:30	2026-10-25 12:22:51.229332+05:30
b8c08bae-23ab-42e1-942e-de6ad9285dbb	\N	admin	attendance:view	t	2026-10-25 12:22:51.230348+05:30	2026-10-25 12:22:51.230348+05:30
e2102dbd-3aeb-4cb9-9754-c7d0bd7f1f92	\N	admin	attendance:checkin	t	2026-10-25 12:22:51.231372+05:30	2026-10-25 12:22:51.231372+05:30
cc6e1185-65c2-4a94-9d4e-bd01629540f5	\N	admin	attendance:bulk	t	2026-10-25 12:22:51.23233+05:30	2026-10-25 12:22:51.23233+05:30
6e3e9024-63a3-4987-838b-00349e362daf	\N	admin	attendance:biometric	t	2026-10-25 12:22:51.233891+05:30	2026-10-25 12:22:51.233891+05:30
fe2434a4-4b88-4db5-8f50-83b286e49223	\N	admin	payments:view	t	2026-10-25 12:22:51.234901+05:30	2026-10-25 12:22:51.234901+05:30
e7a37d4e-1831-4f87-bcde-5f6091fe92f9	\N	admin	payments:collect	t	2026-10-25 12:22:51.235936+05:30	2026-10-25 12:22:51.235936+05:30
c26aa4aa-6723-48e9-9157-f2a023e891bb	\N	admin	payments:discount	t	2026-10-25 12:22:51.237265+05:30	2026-10-25 12:22:51.237265+05:30
e8e3c1b5-0302-4299-b186-5546de69f316	\N	admin	payments:refund	t	2026-10-25 12:22:51.238488+05:30	2026-10-25 12:22:51.238488+05:30
92d4552d-21f4-4a47-a86e-dc59413bb58d	\N	admin	payments:delete	t	2026-10-25 12:22:51.239713+05:30	2026-10-25 12:22:51.239713+05:30
3a5ec6d3-e2f8-4799-a364-753d4f09056e	\N	front-desk	members:view	t	2026-10-25 12:22:51.240985+05:30	2026-10-25 12:22:51.240985+05:30
f10b09dc-e568-414d-bfb6-7beba7215e4b	\N	front-desk	members:add	t	2026-10-25 12:22:51.2577+05:30	2026-10-25 12:22:51.2577+05:30
6e9d8c2e-41af-4bb8-8cf4-0bc5bcfd040d	\N	front-desk	members:edit	t	2026-10-25 12:22:51.258972+05:30	2026-10-25 12:22:51.258972+05:30
f793b19b-065a-4a8a-bbf5-cc940f7e06f5	\N	front-desk	members:delete	f	2026-10-25 12:22:51.260121+05:30	2026-10-25 12:22:51.260121+05:30
3c77a057-767f-42f9-aa1f-5a3c2b00daee	\N	front-desk	members:duplicate	t	2026-10-25 12:22:51.261179+05:30	2026-10-25 12:22:51.261179+05:30
d29037e5-451b-4bf0-82ef-9d741e27740b	\N	front-desk	members:import	f	2026-10-25 12:22:51.262197+05:30	2026-10-25 12:22:51.262197+05:30
d3978424-0782-4c81-8405-071fc7c404fd	\N	front-desk	members:export	t	2026-10-25 12:22:51.26331+05:30	2026-10-25 12:22:51.26331+05:30
659629c6-a48c-462f-ae7a-d2f2013ba1ac	\N	front-desk	members:hold_fees	t	2026-10-25 12:22:51.264552+05:30	2026-10-25 12:22:51.264552+05:30
3123ac0f-8fc3-4114-a55e-dac308b98f0e	\N	front-desk	staff:view	t	2026-10-25 12:22:51.265563+05:30	2026-10-25 12:22:51.265563+05:30
a0d26bf1-5125-4041-876c-3277875f6ea5	\N	front-desk	staff:add	f	2026-10-25 12:22:51.266622+05:30	2026-10-25 12:22:51.266622+05:30
8bdd8721-98b6-4d63-afd0-371f2958d24b	\N	front-desk	staff:edit	f	2026-10-25 12:22:51.267696+05:30	2026-10-25 12:22:51.267696+05:30
3078c23e-16ac-42a1-9b88-609e20caebc5	\N	front-desk	staff:delete	f	2026-10-25 12:22:51.268776+05:30	2026-10-25 12:22:51.268776+05:30
163f0138-a1ea-476d-90e4-032986583c0c	\N	front-desk	staff:assign	f	2026-10-25 12:22:51.270263+05:30	2026-10-25 12:22:51.270263+05:30
18349eb7-3b46-4e3d-b43c-3e4660ce7cfe	\N	front-desk	attendance:view	t	2026-10-25 12:22:51.271628+05:30	2026-10-25 12:22:51.271628+05:30
de8afdb5-e6e2-4fbc-8acc-855b20faedbe	\N	front-desk	attendance:checkin	t	2026-10-25 12:22:51.272993+05:30	2026-10-25 12:22:51.272993+05:30
d39d9ecb-17d3-450b-aee8-57eff937e679	\N	front-desk	attendance:bulk	t	2026-10-25 12:22:51.274248+05:30	2026-10-25 12:22:51.274248+05:30
0a773731-de00-4c39-b3ee-e7e57bb305f3	\N	front-desk	attendance:biometric	f	2026-10-25 12:22:51.275425+05:30	2026-10-25 12:22:51.275425+05:30
94210868-9542-4bb5-b2e1-8f7b97cd3546	\N	front-desk	payments:view	t	2026-10-25 12:22:51.276602+05:30	2026-10-25 12:22:51.276602+05:30
d2b2b230-41ed-44e1-9979-4f218d33a927	\N	front-desk	payments:collect	t	2026-10-25 12:22:51.277763+05:30	2026-10-25 12:22:51.277763+05:30
e3310141-794e-41c0-beb4-be34c2577130	\N	front-desk	payments:discount	f	2026-10-25 12:22:51.278836+05:30	2026-10-25 12:22:51.278836+05:30
dd0528da-c964-4ad7-b28b-3fd52ab3e7ee	\N	front-desk	payments:refund	f	2026-10-25 12:22:51.280103+05:30	2026-10-25 12:22:51.280103+05:30
e543050d-9de8-416d-8a75-b864de2d3d9a	\N	front-desk	payments:delete	f	2026-10-25 12:22:51.281444+05:30	2026-10-25 12:22:51.281444+05:30
978446d8-b4bb-44db-8b51-f75b0f99cd0a	\N	trainer	members:view	t	2026-10-25 12:22:51.28256+05:30	2026-10-25 12:22:51.28256+05:30
ea6a02f2-3928-4907-af8a-82bfb1a5f615	\N	trainer	members:add	f	2026-10-25 12:22:51.283838+05:30	2026-10-25 12:22:51.283838+05:30
650145c5-ef5f-4b37-9392-dd7e3ea95cb1	\N	trainer	members:edit	f	2026-10-25 12:22:51.284871+05:30	2026-10-25 12:22:51.284871+05:30
c5e84245-4395-4866-88f4-8d0a90f0f40a	\N	trainer	members:delete	f	2026-10-25 12:22:51.286289+05:30	2026-10-25 12:22:51.286289+05:30
3a61e986-220c-46b7-9b88-569084adbe3a	\N	trainer	members:duplicate	f	2026-10-25 12:22:51.287284+05:30	2026-10-25 12:22:51.287284+05:30
193ed55b-c96a-45e1-b9e9-ba6c98ba2706	\N	trainer	members:import	f	2026-10-25 12:22:51.288287+05:30	2026-10-25 12:22:51.288287+05:30
460b6a79-3d7e-42fb-9d1e-cc9821d9b8fd	\N	trainer	members:export	f	2026-10-25 12:22:51.289349+05:30	2026-10-25 12:22:51.289349+05:30
32bb432b-cb05-4ec3-a458-ef7db74efe48	\N	trainer	members:hold_fees	f	2026-10-25 12:22:51.290439+05:30	2026-10-25 12:22:51.290439+05:30
ce75bed1-1a7f-40bf-a646-cc564c7b63be	\N	trainer	staff:view	t	2026-10-25 12:22:51.291522+05:30	2026-10-25 12:22:51.291522+05:30
6befc456-a7ff-4e23-a649-7417931d74f7	\N	trainer	staff:add	f	2026-10-25 12:22:51.293024+05:30	2026-10-25 12:22:51.293024+05:30
1761a8d8-3d74-40d1-97c8-bec7af517d82	\N	trainer	staff:edit	f	2026-10-25 12:22:51.294271+05:30	2026-10-25 12:22:51.294271+05:30
230d4cb9-84d9-4d0e-b2dd-e1c03165ea85	\N	trainer	staff:delete	f	2026-10-25 12:22:51.295727+05:30	2026-10-25 12:22:51.295727+05:30
e19cee41-7eff-4237-98ad-1b0518faa1fc	\N	trainer	staff:assign	f	2026-10-25 12:22:51.297071+05:30	2026-10-25 12:22:51.297071+05:30
49e4db28-18c3-466e-a63e-f500e336c3da	\N	trainer	attendance:view	t	2026-10-25 12:22:51.298672+05:30	2026-10-25 12:22:51.298672+05:30
fadab945-4bb2-4390-9292-b478cb3a066f	\N	trainer	attendance:checkin	t	2026-10-25 12:22:51.299971+05:30	2026-10-25 12:22:51.299971+05:30
602178d6-785b-474f-9632-4d316a317c2a	\N	trainer	attendance:bulk	f	2026-10-25 12:22:51.301204+05:30	2026-10-25 12:22:51.301204+05:30
a9d1e06e-2618-48c6-a9f8-c9de0012cb2b	\N	trainer	attendance:biometric	f	2026-10-25 12:22:51.303162+05:30	2026-10-25 12:22:51.303162+05:30
8a49723e-50b8-452e-be60-9157387003bb	\N	trainer	payments:view	f	2026-10-25 12:22:51.304471+05:30	2026-10-25 12:22:51.304471+05:30
903bdca1-b64f-48a1-95f8-576ee4cc1e39	\N	trainer	payments:collect	f	2026-10-25 12:22:51.305751+05:30	2026-10-25 12:22:51.305751+05:30
1942412d-793d-4402-92df-c65fd5e5db7b	\N	trainer	payments:discount	f	2026-10-25 12:22:51.307023+05:30	2026-10-25 12:22:51.307023+05:30
456b52cc-a443-462e-b607-8822f95421a3	\N	trainer	payments:refund	f	2026-10-25 12:22:51.308348+05:30	2026-10-25 12:22:51.308348+05:30
049c74af-3d3b-46cc-9161-7782c1b2ee51	\N	trainer	payments:delete	f	2026-10-25 12:22:51.310009+05:30	2026-10-25 12:22:51.310009+05:30
3a90ce9b-ad2d-42fd-adad-697c985f491b	\N	accountant	members:view	t	2026-10-25 12:22:51.311516+05:30	2026-10-25 12:22:51.311516+05:30
a627cbb7-f1db-4452-ba10-0aad277713ba	\N	accountant	members:add	f	2026-10-25 12:22:51.312933+05:30	2026-10-25 12:22:51.312933+05:30
8cc859a2-9998-4fd0-bde4-b9273688c9c0	\N	accountant	members:edit	f	2026-10-25 12:22:51.314369+05:30	2026-10-25 12:22:51.314369+05:30
feca8004-5e6c-4743-a99e-c7f8f729f5b0	\N	accountant	members:delete	f	2026-10-25 12:22:51.315809+05:30	2026-10-25 12:22:51.315809+05:30
5ebd2771-edd3-472a-9d3c-4ff6c1be3d9a	\N	accountant	members:duplicate	f	2026-10-25 12:22:51.316997+05:30	2026-10-25 12:22:51.316997+05:30
ce4fadc3-e921-4b7a-9cc5-759dfdd5ef4d	\N	accountant	members:import	f	2026-10-25 12:22:51.318095+05:30	2026-10-25 12:22:51.318095+05:30
8376a0a9-d23b-4efe-94cc-f056c0174faa	\N	accountant	members:export	t	2026-10-25 12:22:51.319782+05:30	2026-10-25 12:22:51.319782+05:30
6b1fe1a5-950f-4075-887b-807eb9f2b975	\N	accountant	members:hold_fees	t	2026-10-25 12:22:51.321874+05:30	2026-10-25 12:22:51.321874+05:30
a8419b05-8d84-4988-987c-71082cee36f7	\N	accountant	staff:view	t	2026-10-25 12:22:51.323239+05:30	2026-10-25 12:22:51.323239+05:30
008e2413-c49c-4f29-8da3-3dbb457df384	\N	accountant	staff:add	f	2026-10-25 12:22:51.32438+05:30	2026-10-25 12:22:51.32438+05:30
d486b95e-b1ac-4175-a8ca-32c6d6ccddb0	\N	accountant	staff:edit	f	2026-10-25 12:22:51.326578+05:30	2026-10-25 12:22:51.326578+05:30
97fe6569-36ae-4952-b941-e4c960802329	\N	accountant	staff:delete	f	2026-10-25 12:22:51.327743+05:30	2026-10-25 12:22:51.327743+05:30
585db2ea-b951-4837-9f2a-71e7a458dff6	\N	accountant	staff:assign	f	2026-10-25 12:22:51.329464+05:30	2026-10-25 12:22:51.329464+05:30
97510fde-2c88-4035-b647-272ac2273408	\N	accountant	attendance:view	f	2026-10-25 12:22:51.330575+05:30	2026-10-25 12:22:51.330575+05:30
675b5e7c-5de8-4581-9439-75b711f2ed7a	\N	accountant	attendance:checkin	f	2026-10-25 12:22:51.332295+05:30	2026-10-25 12:22:51.332295+05:30
6e33a43e-299e-4d4c-a7d1-935abc60a720	\N	accountant	attendance:bulk	f	2026-10-25 12:22:51.333546+05:30	2026-10-25 12:22:51.333546+05:30
08e02122-7469-4a25-8f9e-bd36ab53bac0	\N	accountant	attendance:biometric	f	2026-10-25 12:22:51.334885+05:30	2026-10-25 12:22:51.334885+05:30
152e2092-e251-4372-9488-77e31da1ac18	\N	accountant	payments:view	t	2026-10-25 12:22:51.336937+05:30	2026-10-25 12:22:51.336937+05:30
05186f0a-2fee-4c9e-ad2f-41675e4b2ca8	\N	accountant	payments:collect	t	2026-10-25 12:22:51.33864+05:30	2026-10-25 12:22:51.33864+05:30
f253e2fb-7d88-48c2-a23d-e41951f37a6f	\N	accountant	payments:discount	t	2026-10-25 12:22:51.340035+05:30	2026-10-25 12:22:51.340035+05:30
6f0b0237-6e76-4150-8978-e54c815c8116	\N	accountant	payments:refund	t	2026-10-25 12:22:51.342057+05:30	2026-10-25 12:22:51.342057+05:30
6154c749-ec43-4ca6-94b4-b3f7ff63dffb	\N	accountant	payments:delete	t	2026-10-25 12:22:51.343513+05:30	2026-10-25 12:22:51.343513+05:30
\.


--
-- Data for Name: gyms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gyms (id, owner_id, name, logo_url, address, city, state, country, pincode, phone, email, gstin, is_active, created_at, updated_at, billing_plan_id) FROM stdin;
6ecfc033-52f1-444f-a3f6-65fdd664c988	7857b428-4e3f-473d-839c-79abda528973	Test Gym - 1	\N	\N	Erode	Tamil Nadu	India	\N	9629017245	jyothiprakash1812@gmail.com	\N	t	2026-10-11 11:17:15.198754+05:30	2026-10-11 11:17:15.198754+05:30	075277f5-1867-4052-bece-beb82bbcdacd
4e440296-d558-46e6-b0f6-5fad5910a8f3	7857b428-4e3f-473d-839c-79abda528973	Test Gym - 2	\N	\N	Salem	Tamil Nadu	India	\N	9500977245	naveenprakash178@gmail.com	\N	t	2026-10-11 11:18:30.759758+05:30	2026-10-11 11:18:30.759758+05:30	8a5ef42e-8982-43cc-a8f7-fbf6c2bebfc9
1d993780-4a56-4c02-8b31-c8af71c86ff7	7857b428-4e3f-473d-839c-79abda528973	Tes Gym - 3	\N	\N	Coimbatore	Tamil Nadu	India	\N	9842083976	\N	\N	t	2026-11-01 00:00:19.563449+05:30	2026-11-01 00:00:19.563449+05:30	075277f5-1867-4052-bece-beb82bbcdacd
e85928f5-e06d-4663-84ba-697347816efb	\N	Prompt4 Freeze Gym	\N	\N	\N	\N	India	\N	9876540001	p4freeze@gym.com	\N	t	2026-11-01 18:04:34.616682+05:30	2026-11-01 18:04:34.616682+05:30	\N
e52d93f7-cb46-4285-bec1-ff2016ccc39c	\N	Prompt4 Other Gym	\N	\N	\N	\N	India	\N	9876540003	p4other@gym.com	\N	t	2026-11-01 18:04:34.64587+05:30	2026-11-01 18:04:34.64587+05:30	\N
59179c14-86e4-4950-8833-74c46736bbee	\N	Prompt5 Renewal Gym	\N	\N	\N	\N	India	\N	9876541111	p5renew@gym.com	\N	t	2026-11-01 19:14:16.899956+05:30	2026-11-01 19:14:16.899956+05:30	\N
b2bcd449-334f-482e-8f90-d1e731ac6ca9	\N	Prompt5 Other Gym	\N	\N	\N	\N	India	\N	9876542221	p5other@gym.com	\N	t	2026-11-01 19:14:16.950432+05:30	2026-11-01 19:14:16.950432+05:30	\N
2a5efdd1-aebf-4f3a-93de-fe673d727a55	\N	Day5 P1 Gym 1	\N	\N	\N	\N	India	\N	9876550001	d5p1_gym1@test.com	\N	t	2026-11-01 21:11:16.449901+05:30	2026-11-01 21:11:16.449901+05:30	\N
46e49c9f-3bea-4b93-a86f-40b886ecdb60	\N	Day5 P1 Gym 2	\N	\N	\N	\N	India	\N	9876550004	d5p1_gym2@test.com	\N	t	2026-11-01 21:11:16.49045+05:30	2026-11-01 21:11:16.49045+05:30	\N
8c35c396-7f04-4802-9ed5-ecc4c12dc81b	\N	Day5 P2 Gym 1	\N	\N	\N	\N	India	\N	9876560001	d5p2_gym1@test.com	\N	t	2026-11-01 21:19:08.918786+05:30	2026-11-01 21:19:08.918786+05:30	\N
35fc5264-607e-4663-a79b-03a756984e78	\N	Day5 P2 Gym 2	\N	\N	\N	\N	India	\N	9876560003	d5p2_gym2@test.com	\N	t	2026-11-01 21:19:08.967477+05:30	2026-11-01 21:19:08.967477+05:30	\N
04bb63ce-3328-4b25-bc4e-8ad57614e2f8	\N	Day5 P3 Gym 1	\N	\N	\N	\N	India	\N	9876570001	d5p3_gym1@test.com	\N	t	2026-11-01 21:29:28.046834+05:30	2026-11-01 21:29:28.046834+05:30	\N
1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	Day5 P3 Gym 2	\N	\N	\N	\N	India	\N	9876570004	d5p3_gym2@test.com	\N	t	2026-11-01 21:29:28.18334+05:30	2026-11-01 21:29:28.18334+05:30	\N
e93d6a19-7d4a-4032-956b-3b5a0936bc2c	\N	D5 Bulk UI Gym	\N	\N	\N	\N	India	\N	9888877700	d5bulk@gym.com	\N	t	2026-11-01 21:42:20.558784+05:30	2026-11-01 21:42:20.558784+05:30	\N
fbc2ba24-7886-403e-b2f1-0c88e3926eae	\N	D5 Bulk UI Gym	\N	\N	\N	\N	India	\N	9888877700	d5bulk@gym.com	\N	t	2026-11-01 21:43:19.007015+05:30	2026-11-01 21:43:19.007015+05:30	\N
a7210f47-0738-4176-981e-d1c2a50d4438	\N	D5 Bulk UI Gym 7211	\N	\N	\N	\N	India	\N	988887211	d5bulk_7211@gym.com	\N	t	2026-11-01 21:43:55.427707+05:30	2026-11-01 21:43:55.427707+05:30	\N
f666a106-2ccf-4682-8941-2949c3230de2	\N	D5 Bulk UI Gym 5826	\N	\N	\N	\N	India	\N	988885826	d5bulk_5826@gym.com	\N	t	2026-11-01 21:44:35.295047+05:30	2026-11-01 21:44:35.295047+05:30	\N
c0452148-dc36-40d0-92bb-1d9870fe0d15	\N	D5 Bulk UI Gym 5660	\N	\N	\N	\N	India	\N	988885660	d5bulk_5660@gym.com	\N	t	2026-11-01 21:44:55.539247+05:30	2026-11-01 21:44:55.539247+05:30	\N
3c5ea471-e574-4ffe-a088-437928965419	\N	D5 Bulk UI Gym 8509	\N	\N	\N	\N	India	\N	988888509	d5bulk_8509@gym.com	\N	t	2026-11-01 21:46:15.60545+05:30	2026-11-01 21:46:15.60545+05:30	\N
e008d4f0-a775-42c9-a8ca-7475c89df3b2	\N	D5 Bulk UI Gym 2171	\N	\N	\N	\N	India	\N	988882171	d5bulk_2171@gym.com	\N	t	2026-11-01 21:48:13.106505+05:30	2026-11-01 21:48:13.106505+05:30	\N
07181c9d-8f25-42c9-a2ee-8fb959a5a373	\N	D5 Bulk UI Gym 3855	\N	\N	\N	\N	India	\N	988883855	d5bulk_3855@gym.com	\N	t	2026-11-01 21:49:25.831202+05:30	2026-11-01 21:49:25.831202+05:30	\N
bb849e64-96a4-4091-997d-c52fbff6ed8b	\N	D5 Bulk UI Gym 8852	\N	\N	\N	\N	India	\N	988888852	d5bulk_8852@gym.com	\N	t	2026-11-01 22:08:27.088715+05:30	2026-11-01 22:08:27.088715+05:30	\N
01fdeb6f-44c1-4996-9a49-03c085f11d3d	\N	D6 Invoice Gym A 5582	\N	\N	\N	\N	India	\N	988715582	d6inva_5582@gym.com	\N	t	2026-11-01 22:18:11.544617+05:30	2026-11-01 22:18:11.544617+05:30	\N
09cfaf84-3291-4a6a-8d0f-5cc0da1b7d4d	\N	D6 Invoice Gym B 5582	\N	\N	\N	\N	India	\N	988725582	d6invb_5582@gym.com	\N	t	2026-11-01 22:18:11.571056+05:30	2026-11-01 22:18:11.571056+05:30	\N
\.


--
-- Data for Name: invoice_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_sequences (gym_id, year_month, last_seq, updated_at) FROM stdin;
01fdeb6f-44c1-4996-9a49-03c085f11d3d	202611	11	2026-11-01 22:18:12.305858+05:30
09cfaf84-3291-4a6a-8d0f-5cc0da1b7d4d	202611	1	2026-11-01 22:18:12.312745+05:30
01fdeb6f-44c1-4996-9a49-03c085f11d3d	202612	1	2026-11-01 22:18:12.322735+05:30
6ecfc033-52f1-444f-a3f6-65fdd664c988	202611	3	2026-11-18 23:40:20.891265+05:30
6ecfc033-52f1-444f-a3f6-65fdd664c988	202610	3	2026-11-01 22:54:30.021269+05:30
4e440296-d558-46e6-b0f6-5fad5910a8f3	202611	1	2026-11-01 22:54:30.021269+05:30
59179c14-86e4-4950-8833-74c46736bbee	202611	18	2026-11-01 22:54:30.021269+05:30
e85928f5-e06d-4663-84ba-697347816efb	202611	9	2026-11-01 22:54:30.021269+05:30
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, payment_id, member_id, invoice_number, issued_date, due_date, subtotal, gst_rate, gst_amount, total, status, pdf_url, created_at, gym_id, branch_id, plan_name, amount, payment_mode, issued_at) FROM stdin;
009efc65-af87-47ab-a49b-f36762bd67aa	561d0931-3482-43b8-8da6-d8516fbe0ef1	3be8879b-e90c-485b-b887-3593e07d5849	INV-202610-0001	2026-10-20	\N	1499.00	18.00	\N	1499.00	paid	\N	2026-10-20 21:43:51.758+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e	1 Month Plan	1499.00	Cash	2026-10-20 21:43:51.758+05:30
e2d34196-e16e-4db5-b1b6-5f9dc29b7223	8a5f690d-1776-4475-80b3-2fabc214a3a0	94f23150-931e-4c30-893f-d0e460460961	INV-202610-0002	2026-10-20	\N	3999.00	18.00	\N	3999.00	paid	\N	2026-10-20 21:51:30.762+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e	6 Months plan	3999.00	Cash	2026-10-20 21:51:30.762+05:30
8745f24a-8f79-45ae-9568-1212443fe5af	4bff7cb9-fb6e-47c3-b4df-e6358857be09	94f23150-931e-4c30-893f-d0e460460961	INV-202610-0003	2026-10-21	\N	1499.00	18.00	\N	1499.00	paid	\N	2026-10-21 23:03:37.084+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e	1 Month Plan	1499.00	Cash	2026-10-21 23:03:37.084+05:30
99144d03-9827-4c27-b84c-371ba7a10fe8	094acb95-99a8-4fa8-a285-4bfb8f7723c8	7aeaa05b-f38b-4364-bc47-7463222144a1	INV-202611-0001	2026-11-01	\N	1500.00	18.00	\N	1500.00	paid	\N	2026-11-01 11:36:44.833+05:30	4e440296-d558-46e6-b0f6-5fad5910a8f3	630b3844-e660-45a5-bdbc-abc8c0f19802	Gym Membership Fee	1500.00	Cash	2026-11-01 11:36:44.833+05:30
b41d5f26-3dd2-4aa6-b0c5-1c62c8acc90e	7e995748-1382-460d-bcd7-9718558a84bc	706c24cf-2b67-4a25-af5d-fdd261ff9089	INV-202611-0001	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 18:05:33.708+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	2000.00	UPI	2026-11-01 18:05:33.708+05:30
c3d4acb2-fc2a-4641-91d9-54f53db0c3e5	69b1985f-9948-4888-9777-4ca54caaa1b4	5a9fb1b0-7078-4d6a-8d06-247464e152b3	INV-202611-0002	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 18:05:59.031+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	2000.00	UPI	2026-11-01 18:05:59.031+05:30
06f61470-1b2a-4341-9849-8939a373b30e	c3d1dd02-eb6c-493a-959f-13c686f05efb	5a9fb1b0-7078-4d6a-8d06-247464e152b3	INV-202611-0003	2026-11-01	\N	150.00	18.00	\N	150.00	paid	\N	2026-11-01 18:05:59.211+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	150.00	Cash	2026-11-01 18:05:59.211+05:30
43624ce1-f134-49bf-bc85-01b7838cb2f7	2e3b08a5-758e-462e-8a8c-8fec4a13ff91	9939e769-7d03-41d7-bbb9-49da78ff6787	INV-202611-0004	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 18:06:19.088+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	2000.00	UPI	2026-11-01 18:06:19.088+05:30
eb862c54-86ca-4d6b-bf1b-75fcbd17a334	7d9d94e2-4f01-4354-bc27-585cb993642d	9939e769-7d03-41d7-bbb9-49da78ff6787	INV-202611-0005	2026-11-01	\N	150.00	18.00	\N	150.00	paid	\N	2026-11-01 18:06:19.213+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	150.00	Cash	2026-11-01 18:06:19.213+05:30
b556fff9-42a6-4b80-b9db-26d1d1bc0a15	57eb0029-62ec-422c-aabd-89c8acecd7c6	bed7778c-0c68-47d7-944e-35babc865835	INV-202611-0001	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:16:05.633+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	Cash	2026-11-01 19:16:05.633+05:30
732a4ef5-5f6f-488e-a432-caa4305c2526	e9361a37-89c9-4862-b574-b07dbbb64e25	26761a7b-5161-491f-a652-f17bf1c95e30	INV-202611-0002	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:16:05.651+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	UPI	2026-11-01 19:16:05.651+05:30
4902ff71-4146-4f73-8221-cfe1ef4b7ff2	5148227b-502e-427c-b1ef-c5a7b2d8e4c7	bed7778c-0c68-47d7-944e-35babc865835	INV-202611-0003	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:16:06.091+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	Cash	2026-11-01 19:16:06.091+05:30
2e464fdb-dca3-4877-b208-460cd0ff0713	519570cf-3e1d-4209-ae20-835220649cc5	3e311304-db12-405d-b66d-7dd4b6fdd817	INV-202611-0004	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:16:54.602+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	Cash	2026-11-01 19:16:54.602+05:30
c5eac71b-e2b0-4c0e-b5ae-34c28e77bb26	39248147-ea27-4135-8227-8003e5642f4a	9c4d76db-3dda-410c-b46c-68deb36c0286	INV-202611-0005	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:16:54.613+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	UPI	2026-11-01 19:16:54.613+05:30
ecefba68-6a6f-41c6-ba0c-572500c4357e	4a343ad5-7543-4125-8464-0fa7183533f7	3e311304-db12-405d-b66d-7dd4b6fdd817	INV-202611-0006	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:16:54.904+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	Cash	2026-11-01 19:16:54.904+05:30
933f9a90-fdc7-48e6-a7c3-cfd0ca8427e6	e9805d70-b33c-47be-940e-a46a16924cad	9c4d76db-3dda-410c-b46c-68deb36c0286	INV-202611-0007	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:16:55.021+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	UPI	2026-11-01 19:16:55.021+05:30
942a8c8d-e991-4ed7-b93a-bf34f9b539ff	f7d5dc85-00d4-45ea-8d89-29441d0e2651	9c4d76db-3dda-410c-b46c-68deb36c0286	INV-202611-0008	2026-11-01	\N	18000.00	18.00	\N	18000.00	paid	\N	2026-11-01 19:16:55.087+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Year Plan	18000.00	Card	2026-11-01 19:16:55.087+05:30
88da5f27-b381-4cac-991c-dbd5c0549bf1	48ea8fc3-cc8c-460c-a579-d22733de304b	74416a0e-47ff-41f7-bd99-f2f8ca846b5e	INV-202611-0009	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:17:20.254+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	Cash	2026-11-01 19:17:20.254+05:30
1260f1c7-ca8b-4e47-b098-3cd3d970b11f	1e599248-3c98-4861-85c1-27cabe4bd639	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	INV-202611-0010	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:17:20.266+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	UPI	2026-11-01 19:17:20.266+05:30
42ebb40b-1d41-41d0-96fb-f8d9ecae6e3e	432ab925-0e09-4607-93a7-1943857db6fb	74416a0e-47ff-41f7-bd99-f2f8ca846b5e	INV-202611-0011	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:17:20.579+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	Cash	2026-11-01 19:17:20.579+05:30
9a36bd98-474c-4473-bc12-86bedaea5a5d	e89f0913-8722-48c5-a8cd-b5172807601a	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	INV-202611-0012	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:17:20.685+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	UPI	2026-11-01 19:17:20.685+05:30
48d8cec1-4835-464f-8724-2db260090d7f	172dd49f-277b-4f27-874b-4008eb7a71d3	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	INV-202611-0013	2026-11-01	\N	18000.00	18.00	\N	18000.00	paid	\N	2026-11-01 19:17:20.752+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Year Plan	18000.00	Card	2026-11-01 19:17:20.752+05:30
a9e25752-4da6-4da9-8ed2-6f044df2322a	b6cd06d0-bc19-4446-8521-19a2787c18e9	7fcb3c33-454c-4e3f-8c98-77eae7068aa1	INV-202611-0006	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 19:17:29.61+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	2000.00	UPI	2026-11-01 19:17:29.61+05:30
aa0c0bfc-3504-47b0-bfe6-68189f8de376	23d3d8b7-d326-41cc-a749-6a8fa1d69109	7fcb3c33-454c-4e3f-8c98-77eae7068aa1	INV-202611-0007	2026-11-01	\N	150.00	18.00	\N	150.00	paid	\N	2026-11-01 19:17:29.805+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	150.00	Cash	2026-11-01 19:17:29.805+05:30
23612e4f-c570-431f-838a-b5108c21adf3	82b2c46f-f948-42a1-a74e-c715084ec5ef	ba352d61-a8a2-4878-9e76-bf82e550ac86	INV-202611-0014	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 21:12:02.252+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	Cash	2026-11-01 21:12:02.252+05:30
58106c8d-b9c4-4e45-b23d-b0734eadf9d1	531dc108-7483-4753-b2c5-f2823372344b	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	INV-202611-0015	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 21:12:02.265+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	UPI	2026-11-01 21:12:02.265+05:30
201d8698-579d-4406-a24d-6b666abefbc7	118465fc-d3a0-4aae-91bf-fd76de9bfda3	ba352d61-a8a2-4878-9e76-bf82e550ac86	INV-202611-0016	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 21:12:02.567+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	Cash	2026-11-01 21:12:02.567+05:30
12eb4e6c-2cc3-4b40-a094-55c495e7d1a6	b24bb6f0-3502-4b0e-a704-8bfecab1b305	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	INV-202611-0017	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 21:12:02.66+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	2000.00	UPI	2026-11-01 21:12:02.66+05:30
28964b6c-389e-4011-94e0-38159772ee9b	d56b73d6-60d0-4ddc-80a2-03228400e384	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	INV-202611-0018	2026-11-01	\N	18000.00	18.00	\N	18000.00	paid	\N	2026-11-01 21:12:02.758+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Year Plan	18000.00	Card	2026-11-01 21:12:02.758+05:30
6edf8c72-b77e-4a3c-9743-debaf480d8fc	de4782e7-92d8-4d2d-9263-3db1c7d52d9e	b240b856-dea9-4f0b-8d23-1c1c43d5cc56	INV-202611-0008	2026-11-01	\N	2000.00	18.00	\N	2000.00	paid	\N	2026-11-01 21:20:39.933+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	2000.00	UPI	2026-11-01 21:20:39.933+05:30
d39ec0e1-16b0-4bf1-86c0-4c6ab03cc93e	f4306c1a-020b-416a-9ae6-d808519fc298	b240b856-dea9-4f0b-8d23-1c1c43d5cc56	INV-202611-0009	2026-11-01	\N	150.00	18.00	\N	150.00	paid	\N	2026-11-01 21:20:40.092+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	150.00	Cash	2026-11-01 21:20:40.092+05:30
cd82453e-0d92-4c46-875b-d6589da55edd	bb2588d9-4f76-4f24-820d-ad95e76944bc	8bebe1af-cd3c-413d-a009-fddf98b9cedd	INV-202611-0001	2026-11-18	\N	1500.00	18.00	\N	1500.00	paid	\N	2026-11-18 23:18:48.412876+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e	Desk front collection	1500.00	Cash	2026-11-18 23:18:48.412876+05:30
167c1b9f-3ac4-4689-87aa-c3363daf2f7f	86d1c197-e87a-422d-ad9e-d9508cbe1aa1	8bebe1af-cd3c-413d-a009-fddf98b9cedd	INV-202611-0002	2026-11-18	\N	1500.00	18.00	\N	1500.00	paid	\N	2026-11-18 23:19:16.839974+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e	Desk front collection	1500.00	Cash	2026-11-18 23:19:16.839974+05:30
7d50dda0-fd4f-493f-817e-6e4507070dd3	c8c0ec00-a30d-42e6-a911-588c02380a0c	8bebe1af-cd3c-413d-a009-fddf98b9cedd	INV-202611-0003	2026-11-18	\N	1500.00	18.00	\N	1500.00	paid	\N	2026-11-18 23:40:20.891265+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e	Desk front collection	1500.00	Cash	2026-11-18 23:40:20.891265+05:30
\.


--
-- Data for Name: lead_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_interactions (id, lead_id, interaction_type, notes, done_by, interaction_date) FROM stdin;
58dde5d6-e292-40df-b365-db7c35183eca	67c29e6a-55f7-4409-bbd4-e1e2bf134659	system	Lead converted to member (Converted Member One 499523).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-16 23:38:19.862912+05:30
74b16d08-1255-489e-b7c6-f174bcf3a565	b846c42d-e892-4a6d-975d-8aa6a72889a8	system	Lead converted to member (Member From Lead Two 499523).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-16 23:38:20.064208+05:30
9b67e5c4-a8a4-411d-8dea-94d34024d277	769b86dc-3aac-46ca-a672-c357b2ffbe3a	system	Lead converted to member (Double Member Attempt).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-16 23:59:27.444205+05:30
03a3e5da-2ee1-4120-9b87-5de1346acfed	07f00b70-003a-45c2-8464-4eef2525770b	system	Lead converted to member (Member From Lead Two 767198).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-16 23:59:27.502313+05:30
d0b315c9-9e79-4641-a8cd-f063669c47b4	a56548e7-e6eb-4276-a3fc-efd084a66cbf	system	Lead converted to member (Converted Member One 886352).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-17 00:01:27.001379+05:30
aafae953-ddbb-44d7-8c1d-6cd697390ff1	e518fd19-e65f-4ccc-b7c1-f2f593fad297	system	Lead converted to member (Member From Lead Two 886352).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-17 00:01:27.148787+05:30
f8b84755-4a24-4285-b819-462d7657b1be	3a07439d-d014-452e-aa9a-4510891a9fcd	system	Lead converted to member (Converted Member One 901219).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-17 00:01:41.525135+05:30
8ff61971-c0d7-4aa6-94d2-4cc2bf30345c	43ac0c89-bc27-4a98-bb9a-379d66cc5284	system	Lead converted to member (Member From Lead Two 901219).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-17 00:01:41.631768+05:30
d2813952-30cf-45a6-96ba-66f26863b1de	64899b8d-8153-4cda-943f-3532e43bc537	system	Lead converted to member (Converted Member One 739920).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-17 08:19:00.343591+05:30
ff823b1f-717b-401d-803e-92e3ea6b311a	74115a74-9ed0-4c3a-b54a-74b9f8d21a8c	system	Lead converted to member (Member From Lead Two 739920).	0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	2026-11-17 08:19:00.536152+05:30
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leads (id, branch_id, full_name, email, phone, source, interest_in, status, assigned_to, ai_score, notes, follow_up_date, converted_member_id, created_at, updated_at) FROM stdin;
16c27aee-b547-41e5-86b3-b55630cfade5	38af11b9-0eff-41b0-9cac-a40a74fb31cf	Test			Website		New	\N	\N		\N	\N	2026-10-23 23:15:02.037491+05:30	2026-10-23 23:15:02.037491+05:30
c4909503-5437-498a-a24d-47a6ad54cef8	2b0c6048-dbf6-4dae-b831-48111246603e	Gym 2 Lead	\N	9123456780	\N	\N	new	\N	\N	\N	\N	\N	2026-10-31 23:06:52.772305+05:30	2026-10-31 23:06:52.772305+05:30
64899b8d-8153-4cda-943f-3532e43bc537	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead One 739920	convert1_739920@test.com	9873992010	\N	\N	Converted	\N	\N	Lead interested in annual plan	\N	db297645-e96e-4edb-9ef5-68da13adc058	2026-11-17 08:19:00.188113+05:30	2026-11-17 08:19:00.343591+05:30
74115a74-9ed0-4c3a-b54a-74b9f8d21a8c	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Two 739920	convert2_739920@test.com	9873992020	\N	\N	Converted	\N	\N	\N	\N	3c77d2bf-0245-43d6-89c3-ae9cab5f92d5	2026-11-17 08:19:00.501364+05:30	2026-11-17 08:19:00.53272+05:30
6f25eb1e-b685-41ee-acb8-724125030a85	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Three 739920	\N	9873992030	\N	\N	New	\N	\N	\N	\N	\N	2026-11-17 08:19:00.610112+05:30	2026-11-17 08:19:00.610112+05:30
1a81d632-244c-4a28-83ad-4c71c982d1f4	630b3844-e660-45a5-bdbc-abc8c0f19802	Test Lead Gym B	\N	9927318510	\N	\N	New	\N	\N	\N	\N	\N	2026-11-01 16:31:46.372239+05:30	2026-11-01 16:31:46.372239+05:30
ea931ad5-9db2-4923-86b9-1ebb23ae4198	2b0c6048-dbf6-4dae-b831-48111246603e	Test Lead Alpha Renamed	\N	9927318510	Walk-in	\N	New	\N	\N	\N	\N	\N	2026-11-01 16:31:46.323445+05:30	2026-11-01 16:31:46.384914+05:30
327dea04-2744-41ad-930e-c83bc1127c7b	2b0c6048-dbf6-4dae-b831-48111246603e	Walkin Lead 1795024156978	\N	9871238837	\N	\N	New	\N	\N	\N	\N	\N	2026-11-18 23:19:17.018126+05:30	2026-11-18 23:19:17.018126+05:30
4d8803e9-d389-44ac-87a6-5560a3c2839c	2b0c6048-dbf6-4dae-b831-48111246603e	Walkin Lead 1795025421079	\N	9877988102	\N	\N	New	\N	\N	\N	\N	\N	2026-11-18 23:40:21.164375+05:30	2026-11-18 23:40:21.164375+05:30
23985d99-59d7-4d7e-9760-b68fea6add15	df582d89-ffe0-49d2-ad94-bb426725bfd6	TEST Lead	\N	9090909090	Social Media	\N	New	\N	\N	\N	\N	\N	2026-11-02 23:35:09.07338+05:30	2026-11-02 23:35:09.07338+05:30
769b86dc-3aac-46ca-a672-c357b2ffbe3a	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead One 767198	convert1_767198@test.com	9876719810	\N	\N	Converted	\N	\N	Lead interested in annual plan	\N	a74e7d78-9411-4f5c-8ee9-e0fc3f436c16	2026-11-16 23:59:27.315964+05:30	2026-11-16 23:59:27.441495+05:30
07f00b70-003a-45c2-8464-4eef2525770b	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Two 767198	convert2_767198@test.com	9876719820	\N	\N	Converted	\N	\N	\N	\N	b24b1fb9-8780-4efc-915c-3314a6166bb8	2026-11-16 23:59:27.466457+05:30	2026-11-16 23:59:27.501037+05:30
0c063239-bbe4-48e8-8eeb-15598c650d3f	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Three 767198	\N	9876719830	\N	\N	New	\N	\N	\N	\N	\N	2026-11-16 23:59:27.576396+05:30	2026-11-16 23:59:27.576396+05:30
67c29e6a-55f7-4409-bbd4-e1e2bf134659	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead One 499523	convert1_499523@test.com	9849952310	\N	\N	Converted	\N	\N	Lead interested in annual plan	\N	4574f97c-7b17-4c53-aa5a-3682cdd2444a	2026-11-16 23:38:19.781451+05:30	2026-11-16 23:38:19.862912+05:30
b846c42d-e892-4a6d-975d-8aa6a72889a8	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Two 499523	convert2_499523@test.com	9849952320	\N	\N	Converted	\N	\N	\N	\N	15baaffb-e770-4e56-9056-bd82d0b67d13	2026-11-16 23:38:20.015697+05:30	2026-11-16 23:38:20.061512+05:30
fd50a284-dc93-47cc-83f9-5f575e39b8b2	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Three 499523	\N	9849952330	\N	\N	New	\N	\N	\N	\N	\N	2026-11-16 23:38:20.135484+05:30	2026-11-16 23:38:20.135484+05:30
a56548e7-e6eb-4276-a3fc-efd084a66cbf	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead One 886352	convert1_886352@test.com	9888635210	\N	\N	Converted	\N	\N	Lead interested in annual plan	\N	07c51ec8-ddd4-4914-be98-47834072fbef	2026-11-17 00:01:26.728781+05:30	2026-11-17 00:01:27.001379+05:30
e518fd19-e65f-4ccc-b7c1-f2f593fad297	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Two 886352	convert2_886352@test.com	9888635220	\N	\N	Converted	\N	\N	\N	\N	0b5eb206-427c-4d30-b726-ce1fa0f1881f	2026-11-17 00:01:27.119021+05:30	2026-11-17 00:01:27.146411+05:30
38fe5b07-2ff4-400e-9796-3af3d51313d5	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Three 886352	\N	9888635230	\N	\N	New	\N	\N	\N	\N	\N	2026-11-17 00:01:27.228181+05:30	2026-11-17 00:01:27.228181+05:30
3a07439d-d014-452e-aa9a-4510891a9fcd	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead One 901219	convert1_901219@test.com	9890121910	\N	\N	Converted	\N	\N	Lead interested in annual plan	\N	1b3b028d-2618-4209-831c-eb5de0c9ccd0	2026-11-17 00:01:41.400579+05:30	2026-11-17 00:01:41.525135+05:30
43ac0c89-bc27-4a98-bb9a-379d66cc5284	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Two 901219	convert2_901219@test.com	9890121920	\N	\N	Converted	\N	\N	\N	\N	0ee3e569-9dec-426d-be81-feb96b019c1a	2026-11-17 00:01:41.599725+05:30	2026-11-17 00:01:41.630031+05:30
7ba3f433-7eea-4342-bd2f-61d383312438	de39de91-f4e1-4ac4-b856-aa8025115452	Convert Lead Three 901219	\N	9890121930	\N	\N	New	\N	\N	\N	\N	\N	2026-11-17 00:01:41.69183+05:30	2026-11-17 00:01:41.69183+05:30
\.


--
-- Data for Name: maintenance_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_logs (id, equipment_id, maintenance_type, description, cost, serviced_by, service_date, next_service_date, created_at) FROM stdin;
\.


--
-- Data for Name: member_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_documents (id, member_id, doc_type, file_url, uploaded_at) FROM stdin;
\.


--
-- Data for Name: member_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_memberships (id, member_id, plan_id, coupon_id, start_date, end_date, freeze_start, freeze_end, status, created_at, updated_at, gym_id, branch_id) FROM stdin;
8d8d54b7-147b-4746-a7da-c82f8b313160	94f23150-931e-4c30-893f-d0e460460961	6d280421-378a-4a49-b7e8-aeb51a839565	\N	2026-04-19	2026-10-16	\N	\N	expired	2026-10-20 21:51:30.725213+05:30	2026-10-20 21:51:30.725213+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e
21e2f0ed-2b3e-494b-878b-5a01db18dd7d	94f23150-931e-4c30-893f-d0e460460961	9fa25449-d2c5-49ba-bd61-c19ca9663c8d	\N	2026-10-21	2026-11-20	\N	\N	active	2026-10-21 23:03:37.040434+05:30	2026-10-21 23:03:37.040434+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e
86afd5c8-13c1-40ac-85c2-d7b8d5bc2fd1	7fcb3c33-454c-4e3f-8c98-77eae7068aa1	982202d3-bec5-4a33-9e9b-c1bb15c05375	\N	2026-11-01	2026-12-05	2026-11-01	2026-11-06	active	2026-11-01 19:17:29.595623+05:30	2026-11-01 19:17:29.904666+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811
efbfd927-6ec3-4e24-843c-96e602a0ff9e	3be8879b-e90c-485b-b887-3593e07d5849	9fa25449-d2c5-49ba-bd61-c19ca9663c8d	\N	2026-09-25	2026-10-25	\N	\N	expired	2026-10-20 21:43:51.713321+05:30	2026-11-01 17:42:48.324603+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e
2bc920d2-4f89-487f-ae5d-0e1a6297adb5	133c9015-ef6e-4eeb-b3be-56e383f808e5	9d27f10b-9808-4b2f-af7e-6e58e8206e6a	\N	2026-11-01	2026-12-01	\N	\N	active	2026-11-01 17:45:21.954138+05:30	2026-11-01 17:45:21.954138+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e
762faf9f-b8e1-41ff-a85f-f0e6fe5744f3	348e43ea-5caf-44fa-b623-28e72db4ff7f	9d27f10b-9808-4b2f-af7e-6e58e8206e6a	\N	2026-09-01	2026-11-30	2026-09-15	2026-09-30	active	2026-11-01 17:45:21.958956+05:30	2026-11-01 17:45:21.97126+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e
711f3139-aedd-420e-8088-1efb9f6643c6	8e0f7aa4-6d34-4a69-b460-c8c82e8ec7d0	9d27f10b-9808-4b2f-af7e-6e58e8206e6a	\N	2026-08-01	2026-08-31	\N	\N	expired	2026-11-01 17:45:21.943709+05:30	2026-11-01 17:45:22.010951+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e
e037d466-9b4a-4513-bb67-3c17b988fb41	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-09-22	2026-10-22	\N	\N	expired	2026-11-01 21:12:02.263312+05:30	2026-11-01 21:12:02.263312+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
eeedc7d6-e411-4cf7-a9d5-90a348f58cdf	ba352d61-a8a2-4878-9e76-bf82e550ac86	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-10-07	2026-11-06	\N	\N	expired	2026-11-01 21:12:02.171055+05:30	2026-11-01 21:12:02.557843+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
37e6a638-3435-4a9a-b624-0b91f0dafc61	ba352d61-a8a2-4878-9e76-bf82e550ac86	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-11-07	2026-12-06	\N	\N	active	2026-11-01 21:12:02.562986+05:30	2026-11-01 21:12:02.562986+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
978a6387-37ab-466f-a81e-f1fea99667d1	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-11-01	2026-11-30	\N	\N	expired	2026-11-01 21:12:02.657329+05:30	2026-11-01 21:12:02.753823+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
40f2e6a5-39ba-4f96-af33-8e8aba9b33be	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	02c65fb2-f655-4010-9581-c1f5048e3e5b	\N	2026-12-01	2027-11-30	\N	\N	active	2026-11-01 21:12:02.755665+05:30	2026-11-01 21:12:02.755665+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
b2440e93-2d3e-4561-9bee-247b59b8b2b3	706c24cf-2b67-4a25-af5d-fdd261ff9089	f06ac522-f7d9-4117-a469-a7449f9d233b	\N	2026-11-01	2026-11-30	\N	\N	active	2026-11-01 18:05:33.70303+05:30	2026-11-01 18:05:33.70303+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811
11779802-9cd1-4f0f-9a1b-3524bd35650f	5a9fb1b0-7078-4d6a-8d06-247464e152b3	6848133e-d13d-4d35-86d5-d745551f0765	\N	2026-11-01	2026-12-05	2026-11-01	2026-11-06	active	2026-11-01 18:05:59.027041+05:30	2026-11-01 18:05:59.348175+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811
db270b18-bad4-432e-b776-f77b04ca25d0	9939e769-7d03-41d7-bbb9-49da78ff6787	54c6bd37-5765-4246-a08d-58a8cd900121	\N	2026-11-01	2026-12-05	2026-11-01	2026-11-06	active	2026-11-01 18:06:19.085614+05:30	2026-11-01 18:06:19.301907+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811
ce09e4f6-d812-4741-b508-993d56a825ac	b240b856-dea9-4f0b-8d23-1c1c43d5cc56	090ee986-ae31-4e18-8848-91d681b2f142	\N	2026-11-01	2026-12-05	2026-11-01	2026-11-06	active	2026-11-01 21:20:39.927685+05:30	2026-11-01 21:20:40.212514+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811
3468ec1f-d6de-449a-b384-db9609935f7b	26761a7b-5161-491f-a652-f17bf1c95e30	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-09-22	2026-10-22	\N	\N	expired	2026-11-01 19:16:05.649209+05:30	2026-11-01 19:16:05.649209+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
fa0530e3-dcac-40f3-85e7-5da9f563efbf	bed7778c-0c68-47d7-944e-35babc865835	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-10-07	2026-11-06	\N	\N	expired	2026-11-01 19:16:05.623985+05:30	2026-11-01 19:16:06.083524+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
5c406635-d81d-45ce-8938-41b2111caafa	bed7778c-0c68-47d7-944e-35babc865835	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-11-07	2026-12-06	\N	\N	active	2026-11-01 19:16:06.088944+05:30	2026-11-01 19:16:06.088944+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
ee82bfc4-4a0c-4cfd-b52d-330b4f731e4d	9c4d76db-3dda-410c-b46c-68deb36c0286	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-09-22	2026-10-22	\N	\N	expired	2026-11-01 19:16:54.611857+05:30	2026-11-01 19:16:54.611857+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
87d1ea6d-7449-4f62-9494-9e89d8776e91	3e311304-db12-405d-b66d-7dd4b6fdd817	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-10-07	2026-11-06	\N	\N	expired	2026-11-01 19:16:54.595135+05:30	2026-11-01 19:16:54.896989+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
722f5761-b6a7-4ac8-bbe2-ad0858eb2943	3e311304-db12-405d-b66d-7dd4b6fdd817	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-11-07	2026-12-06	\N	\N	active	2026-11-01 19:16:54.901331+05:30	2026-11-01 19:16:54.901331+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
86c92093-50b0-4e30-93c4-760088c6462b	9c4d76db-3dda-410c-b46c-68deb36c0286	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-11-01	2026-11-30	\N	\N	expired	2026-11-01 19:16:55.019644+05:30	2026-11-01 19:16:55.084161+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
a7e1b10d-b902-4de4-9978-5e15e4430347	9c4d76db-3dda-410c-b46c-68deb36c0286	02c65fb2-f655-4010-9581-c1f5048e3e5b	\N	2026-12-01	2027-11-30	\N	\N	active	2026-11-01 19:16:55.08619+05:30	2026-11-01 19:16:55.08619+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
f46e4440-a536-4850-bdfe-234e050bab20	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-09-22	2026-10-22	\N	\N	expired	2026-11-01 19:17:20.264689+05:30	2026-11-01 19:17:20.264689+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
c4b63067-c1ea-4d00-961d-d3042ed7ae5a	74416a0e-47ff-41f7-bd99-f2f8ca846b5e	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-10-07	2026-11-06	\N	\N	expired	2026-11-01 19:17:20.247557+05:30	2026-11-01 19:17:20.570038+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
c6fbac30-1077-44a6-9a79-a05ea46a5f05	74416a0e-47ff-41f7-bd99-f2f8ca846b5e	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-11-07	2026-12-06	\N	\N	active	2026-11-01 19:17:20.574949+05:30	2026-11-01 19:17:20.574949+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
4c744ef2-d3ea-4dc2-a4d0-f802cc93ea90	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	e704580e-0c55-4214-9062-bd6042dd4e29	\N	2026-11-01	2026-11-30	\N	\N	expired	2026-11-01 19:17:20.68186+05:30	2026-11-01 19:17:20.747766+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
7e195617-59c5-4ec0-9ed0-577e8ee8432e	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	02c65fb2-f655-4010-9581-c1f5048e3e5b	\N	2026-12-01	2027-11-30	\N	\N	active	2026-11-01 19:17:20.749467+05:30	2026-11-01 19:17:20.749467+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
d91a537b-e345-44c9-8431-66edc204dd1e	677f7ba7-5e7a-43e8-a2d0-aa98cf76507d	b77ff406-f4d0-4874-a4de-905a28f2c02f	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:44:35.390558+05:30	2026-11-01 21:44:35.390558+05:30	f666a106-2ccf-4682-8941-2949c3230de2	89f1214c-6ca0-4077-b2e6-ad3f53a62c0d
c803afc0-a75d-4ddf-8de2-72a939b64db8	5a6c2002-b202-4e7c-89f6-5b88667bea2a	b77ff406-f4d0-4874-a4de-905a28f2c02f	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:44:35.409863+05:30	2026-11-01 21:44:35.409863+05:30	f666a106-2ccf-4682-8941-2949c3230de2	89f1214c-6ca0-4077-b2e6-ad3f53a62c0d
a58ae28b-647c-44b9-88f7-de21b0648f90	270ce820-bfa0-4fa4-9b7e-ab917525dae6	b77ff406-f4d0-4874-a4de-905a28f2c02f	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:44:35.411608+05:30	2026-11-01 21:44:35.411608+05:30	f666a106-2ccf-4682-8941-2949c3230de2	89f1214c-6ca0-4077-b2e6-ad3f53a62c0d
9614da15-7aa4-4443-89f8-35ba7c2dd71a	451f4bb6-36bb-4c07-acf9-cb5b2681da67	255f2ce0-9981-4696-80b0-f013776c786b	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:44:55.751817+05:30	2026-11-01 21:44:55.751817+05:30	c0452148-dc36-40d0-92bb-1d9870fe0d15	0371cdb0-821d-442e-855d-cc2f814130ca
3899ed76-24c4-47de-8905-a7f259ad9835	7a0e483f-6010-44ec-8bad-c2b0c95ccdc2	255f2ce0-9981-4696-80b0-f013776c786b	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:44:55.764269+05:30	2026-11-01 21:44:55.764269+05:30	c0452148-dc36-40d0-92bb-1d9870fe0d15	0371cdb0-821d-442e-855d-cc2f814130ca
8ec7a376-f26f-444c-b5d2-5dd88532d393	75f8920f-4738-44e8-b3c2-967c64685b65	255f2ce0-9981-4696-80b0-f013776c786b	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:44:55.766695+05:30	2026-11-01 21:44:55.766695+05:30	c0452148-dc36-40d0-92bb-1d9870fe0d15	0371cdb0-821d-442e-855d-cc2f814130ca
3b44fb97-7868-4c19-a8f8-a5c7568ecdef	af29c170-4319-4099-8da5-e6c3d4285a0d	b987c5b3-1c9f-4558-8a51-c5d63d24e969	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:46:15.717325+05:30	2026-11-01 21:46:15.717325+05:30	3c5ea471-e574-4ffe-a088-437928965419	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d
e2b9f3ad-faa0-4d1f-ac72-6deea218f110	80256997-b191-41d4-b0da-aabe82109df1	b987c5b3-1c9f-4558-8a51-c5d63d24e969	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:46:15.731594+05:30	2026-11-01 21:46:15.731594+05:30	3c5ea471-e574-4ffe-a088-437928965419	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d
bc8fc451-0dad-43af-9fe7-7fec4d4bd06d	683f13bb-46a7-4d88-a7cc-9c28f514f5a4	b987c5b3-1c9f-4558-8a51-c5d63d24e969	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:46:15.733169+05:30	2026-11-01 21:46:15.733169+05:30	3c5ea471-e574-4ffe-a088-437928965419	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d
200c9e96-80fa-485d-905a-25b872cf2594	f395d9c1-2c4d-4a6f-9558-384a0c2f502e	8ed12483-4373-432a-b9f4-d72821e03003	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:48:13.223181+05:30	2026-11-01 21:48:13.223181+05:30	e008d4f0-a775-42c9-a8ca-7475c89df3b2	0520e7ac-8ac2-45f1-88f7-1027595bc2c3
773ed4ce-3ae3-4942-97e1-e33a9a5224f4	f0b3d976-2ddb-4817-b1ef-ae51abb7f133	8ed12483-4373-432a-b9f4-d72821e03003	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:48:13.23947+05:30	2026-11-01 21:48:13.23947+05:30	e008d4f0-a775-42c9-a8ca-7475c89df3b2	0520e7ac-8ac2-45f1-88f7-1027595bc2c3
90ad6cc3-a695-46aa-871e-f64c3115c04a	ce1799c1-fcfb-43e8-a06b-685bd0a39dd0	8ed12483-4373-432a-b9f4-d72821e03003	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:48:13.241177+05:30	2026-11-01 21:48:13.241177+05:30	e008d4f0-a775-42c9-a8ca-7475c89df3b2	0520e7ac-8ac2-45f1-88f7-1027595bc2c3
df519b01-1f44-4a34-8e1a-6fb5d5a5148c	faed8c47-af39-4ea8-8145-ee40cda43b0f	0ff8ce4e-b742-434a-9b1d-d1d1368d667f	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:49:25.930863+05:30	2026-11-01 21:49:25.930863+05:30	07181c9d-8f25-42c9-a2ee-8fb959a5a373	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b
cd71b990-ea21-4955-916b-e3b1fefec547	a4ee66ca-a5fe-4103-a02b-a5231fc1fd15	0ff8ce4e-b742-434a-9b1d-d1d1368d667f	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:49:25.946804+05:30	2026-11-01 21:49:25.946804+05:30	07181c9d-8f25-42c9-a2ee-8fb959a5a373	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b
c275716a-3544-4b84-9c75-9a520c98ec5e	1741dfb5-4ec3-489e-8a91-c39d64a3d7f0	0ff8ce4e-b742-434a-9b1d-d1d1368d667f	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 21:49:25.948403+05:30	2026-11-01 21:49:25.948403+05:30	07181c9d-8f25-42c9-a2ee-8fb959a5a373	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b
11be82be-1fb7-4bb9-981d-9237e506f718	147a2fb6-a81c-40c0-8cce-89e504ffaa1f	d04fc02a-35e1-4fc8-8f39-ffbbf802c3b5	\N	2026-10-27	2026-11-26	\N	\N	active	2026-11-01 22:08:02.984411+05:30	2026-11-01 22:08:02.984411+05:30	8c35c396-7f04-4802-9ed5-ecc4c12dc81b	5b667fea-b783-49d0-a8e3-e85be41f5943
2ece77b6-402d-44dc-9f98-c49e6698fe57	09660be9-8054-46e1-883f-d70cdaa5daf0	d04fc02a-35e1-4fc8-8f39-ffbbf802c3b5	\N	2026-09-22	2026-10-22	\N	\N	expired	2026-11-01 22:08:03.012309+05:30	2026-11-01 22:08:03.012309+05:30	8c35c396-7f04-4802-9ed5-ecc4c12dc81b	5b667fea-b783-49d0-a8e3-e85be41f5943
c1f7435f-4e8c-4556-9c70-3b135f77178a	36e83cee-3658-4935-bdb0-b87e92b69025	29cfbfa2-7ecf-47a1-98d9-a8ca9a42a18b	\N	2026-10-22	2026-11-21	\N	\N	active	2026-11-01 22:08:15.86835+05:30	2026-11-01 22:08:15.86835+05:30	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	e0aa422e-a36f-4dde-8b5f-3298d0ae457c
bdf2c527-3668-4d46-9ca6-3e695a068643	7c1f4539-1e36-4c84-8528-6f6a5ede7be8	29cfbfa2-7ecf-47a1-98d9-a8ca9a42a18b	\N	2026-10-22	2026-11-21	\N	\N	active	2026-11-01 22:08:15.893813+05:30	2026-11-01 22:08:15.893813+05:30	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	e0aa422e-a36f-4dde-8b5f-3298d0ae457c
2d774aea-537a-4e6e-b3c3-941229a11d0e	c67eebf9-b9f9-4675-aa45-e3a73eae914e	29cfbfa2-7ecf-47a1-98d9-a8ca9a42a18b	\N	2026-10-22	2026-11-21	\N	\N	active	2026-11-01 22:08:15.896739+05:30	2026-11-01 22:08:15.896739+05:30	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	e0aa422e-a36f-4dde-8b5f-3298d0ae457c
ac13686f-76ec-49cf-b800-10ddc4e1e0cd	dcb99703-aacb-433e-843d-766fe82b7fe2	29cfbfa2-7ecf-47a1-98d9-a8ca9a42a18b	\N	2026-09-22	2026-10-22	\N	\N	expired	2026-11-01 22:08:15.904233+05:30	2026-11-01 22:08:15.904233+05:30	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	e0aa422e-a36f-4dde-8b5f-3298d0ae457c
e4e8ad43-b7ea-486e-bc50-bce2105cdf2a	e98fd142-eae8-43a6-ba0c-8d668b89d1eb	946e57e0-93d5-430a-8007-c6512846e9a7	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 22:08:27.212159+05:30	2026-11-01 22:08:27.212159+05:30	bb849e64-96a4-4091-997d-c52fbff6ed8b	e1d06c17-154f-40dc-a736-6e5d45aff429
cf70a1a0-db3c-4672-a696-5e73ae4bc902	13fab36d-cefa-4bf9-a090-8c1277b1b200	946e57e0-93d5-430a-8007-c6512846e9a7	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 22:08:27.237179+05:30	2026-11-01 22:08:27.237179+05:30	bb849e64-96a4-4091-997d-c52fbff6ed8b	e1d06c17-154f-40dc-a736-6e5d45aff429
c9a22bca-52db-477f-8824-690bafd59eef	61ba65a8-d8ba-4894-bc1b-2b5385306b0b	946e57e0-93d5-430a-8007-c6512846e9a7	\N	2026-10-22	2027-08-28	\N	\N	active	2026-11-01 22:08:27.243514+05:30	2026-11-01 22:08:27.243514+05:30	bb849e64-96a4-4091-997d-c52fbff6ed8b	e1d06c17-154f-40dc-a736-6e5d45aff429
a84ef842-61bf-4b9e-ad64-c700fcef5982	46f1e252-804f-45fa-8317-9fce9513d392	d04fc02a-35e1-4fc8-8f39-ffbbf802c3b5	\N	2026-10-27	2026-12-03	2026-10-30	2026-11-06	active	2026-11-01 22:08:03.022686+05:30	2026-11-11 22:14:33.200631+05:30	8c35c396-7f04-4802-9ed5-ecc4c12dc81b	5b667fea-b783-49d0-a8e3-e85be41f5943
3b0ea799-45a9-48d7-b860-dcb1df6b3011	a35bda2a-8ebf-4ebd-85a7-55db7d52d15a	29cfbfa2-7ecf-47a1-98d9-a8ca9a42a18b	\N	2026-10-22	2026-11-28	2026-10-30	2026-11-06	active	2026-11-01 22:08:15.90161+05:30	2026-11-11 22:14:33.200631+05:30	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	e0aa422e-a36f-4dde-8b5f-3298d0ae457c
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, branch_id, user_id, referred_by, full_name, email, phone, date_of_birth, gender, address, profile_photo_url, emergency_contact_name, emergency_contact_phone, health_notes, is_active, created_at, updated_at, join_date) FROM stdin;
a3e83561-61e7-4044-839c-9e543a7be892	630b3844-e660-45a5-bdbc-abc8c0f19802	\N	\N	Alex Johnson	alex.johnson@example.com	9876543210	\N	\N	\N	\N	\N	\N	\N	t	2026-10-30 08:06:02.128607+05:30	2026-10-30 08:06:02.128607+05:30	2026-10-30
fc940d37-12d4-480f-8a10-e6e72abc7e30	630b3844-e660-45a5-bdbc-abc8c0f19802	\N	\N	Sarah Miller	sarah.miller@example.com	9876543211	\N	\N	\N	\N	\N	\N	\N	t	2026-10-30 08:06:02.180937+05:30	2026-10-30 08:06:02.180937+05:30	2026-10-30
e4353a9b-842c-46cf-9c80-478f24670019	630b3844-e660-45a5-bdbc-abc8c0f19802	\N	\N	David Kumar	david.kumar@example.com	9876543212	\N	\N	\N	\N	\N	\N	\N	t	2026-10-30 08:06:02.187709+05:30	2026-10-30 08:06:02.187709+05:30	2026-10-30
60745889-e140-4bcf-82f0-9f1f5c951bc0	df582d89-ffe0-49d2-ad94-bb426725bfd6	\N	\N	Test 1	test.1@example.com	8383838383	\N	Male	\N	\N	\N	\N	\N	t	2026-10-12 23:02:07.030823+05:30	2026-10-12 23:02:07.030823+05:30	2026-10-12
64a36616-38c9-4b44-a230-d599c46055ee	df582d89-ffe0-49d2-ad94-bb426725bfd6	\N	\N	Test 2	test.2@example.com	8948494494	\N	Male	\N	\N	\N	\N	\N	t	2026-10-12 23:02:33.213775+05:30	2026-10-12 23:02:33.213775+05:30	2026-10-12
c990fda2-a28d-4e5b-b905-6bef3bb0c51b	df582d89-ffe0-49d2-ad94-bb426725bfd6	\N	\N	Test 3	test.3@example.com	89494949494	\N	Male	\N	\N	\N	\N	\N	t	2026-10-12 23:02:51.721033+05:30	2026-10-12 23:02:51.721033+05:30	2026-10-12
8bebe1af-cd3c-413d-a009-fddf98b9cedd	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Test- E1	test-.e1@example.com	393939393993	\N	\N	\N	\N	\N	\N	\N	t	2026-10-12 23:03:27.76166+05:30	2026-10-12 23:03:27.76166+05:30	2026-10-12
94f23150-931e-4c30-893f-d0e460460961	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Test-E2	test-e2@example.com	93993939939	\N	\N	\N	\N	\N	\N	\N	t	2026-10-12 23:03:46.936535+05:30	2026-10-12 23:03:46.936535+05:30	2026-10-12
3be8879b-e90c-485b-b887-3593e07d5849	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Test-E33	test-e33@example.com	93993939939	\N	\N	\N	\N	\N	\N	\N	t	2026-10-18 10:36:17.751596+05:30	2026-10-18 10:36:25.594348+05:30	2026-10-10
08b00e4f-36be-485b-a8a7-f1b99a7655d6	38af11b9-0eff-41b0-9cac-a40a74fb31cf	\N	\N	Emma Watson	jpsmart27@gmail.com	9876543215	\N	\N	\N	\N	\N	\N	\N	t	2026-10-30 08:06:02.203829+05:30	2026-10-31 18:15:25.787266+05:30	2026-10-28
c6c2b664-2d81-4810-829f-c1b1ada8be57	38af11b9-0eff-41b0-9cac-a40a74fb31cf	\N	\N	Rahul Verma	jyothiprakash1812@gmail.com	9876543214	\N	\N	\N	\N	\N	\N	\N	t	2026-10-30 08:06:02.198204+05:30	2026-10-31 18:30:50.749518+05:30	2026-10-29
c51edf69-b964-462d-a713-8ba50a8f3131	38af11b9-0eff-41b0-9cac-a40a74fb31cf	\N	\N	Priya Sharma	jyothiprakash131069@gmail.com	9876543213	\N	\N	\N	\N	\N	\N	\N	t	2026-10-30 08:06:02.191931+05:30	2026-10-31 18:31:20.40868+05:30	2026-10-29
38ca4f1c-651b-4dd2-aafc-f961128c4eb1	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Member In Gym A	member_gym_a@test.com	9888888888	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 11:35:06.663952+05:30	2026-11-01 11:35:06.663952+05:30	\N
7aeaa05b-f38b-4364-bc47-7463222144a1	630b3844-e660-45a5-bdbc-abc8c0f19802	\N	\N	Member In Gym B	member_gym_b@test.com	9888888888	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 11:35:06.670309+05:30	2026-11-01 11:35:06.670309+05:30	\N
5491b892-9fc9-4048-aa1a-7a7dc80845d5	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Test Valid Phone	\N	9876543210	\N	\N	\N	\N	\N	8765432109	\N	t	2026-11-01 12:19:19.929033+05:30	2026-11-01 12:19:19.929033+05:30	2026-11-01
c66c1169-b188-42c9-a781-6e4ba82f7408	5a487df0-199b-4b34-b88e-c83dac808811	\N	\N	P4 Rahul Sharma	rahul.freeze@test.com	9876549999	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 18:04:34.689345+05:30	2026-11-01 18:04:34.689345+05:30	2026-11-01
1b731642-11a5-478d-961a-7a18bdefaf29	5a487df0-199b-4b34-b88e-c83dac808811	\N	\N	P4 Rahul Sharma	rahul.freeze@test.com	9876549999	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 18:04:49.598309+05:30	2026-11-01 18:04:49.598309+05:30	2026-11-01
d7f29027-7c85-4a36-9cc9-15024fcc34f9	5a487df0-199b-4b34-b88e-c83dac808811	\N	\N	P4 Rahul Sharma	rahul.freeze@test.com	9876549999	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 18:05:19.070325+05:30	2026-11-01 18:05:19.070325+05:30	2026-11-01
27fea95a-1433-4402-9729-ab10a7def2b5	630b3844-e660-45a5-bdbc-abc8c0f19802	\N	\N	Test Member Gym B	\N	9827318510	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 16:31:46.091479+05:30	2026-11-01 16:31:46.091479+05:30	\N
c18e3c58-438c-442e-8c60-6d3d8c4cd332	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Test Member Alpha Updated	\N	9827318510	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 16:31:45.897033+05:30	2026-11-01 16:31:46.130962+05:30	\N
706c24cf-2b67-4a25-af5d-fdd261ff9089	5a487df0-199b-4b34-b88e-c83dac808811	\N	\N	P4 Rahul Sharma	rahul.freeze@test.com	9876549999	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 18:05:33.48438+05:30	2026-11-01 18:05:33.48438+05:30	2026-11-01
fa00c607-daa8-4d4c-971b-8193ed50a0b2	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Day4 Test Member	\N	9145757636	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 17:20:33.562728+05:30	2026-11-01 17:20:33.562728+05:30	2026-11-01
32a714dc-2d18-448b-b50f-f537989ef910	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Day4 Test Member	\N	9496360735	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 17:21:30.94632+05:30	2026-11-01 17:21:30.94632+05:30	2026-11-01
81d26b75-0295-45d2-9f31-5e6460fab609	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Day4 Test Member	\N	9527088569	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 17:22:01.366008+05:30	2026-11-01 17:22:01.366008+05:30	2026-11-01
8e0f7aa4-6d34-4a69-b460-c8c82e8ec7d0	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Expired Member Test	\N	9689832531	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 17:45:21.916757+05:30	2026-11-01 17:45:21.916757+05:30	2026-08-01
133c9015-ef6e-4eeb-b3be-56e383f808e5	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Active Member Test	\N	9346587544	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 17:45:21.939615+05:30	2026-11-01 17:45:21.939615+05:30	2026-11-01
348e43ea-5caf-44fa-b623-28e72db4ff7f	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Frozen Member Test	\N	9933126312	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 17:45:21.941844+05:30	2026-11-01 17:45:21.941844+05:30	2026-11-01
5a9fb1b0-7078-4d6a-8d06-247464e152b3	5a487df0-199b-4b34-b88e-c83dac808811	\N	\N	P4 Rahul Sharma	rahul.freeze@test.com	9876549999	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 18:05:58.818852+05:30	2026-11-01 18:05:58.818852+05:30	2026-11-01
9939e769-7d03-41d7-bbb9-49da78ff6787	5a487df0-199b-4b34-b88e-c83dac808811	\N	\N	P4 Rahul Sharma	rahul.freeze@test.com	9876549999	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 18:06:18.862635+05:30	2026-11-01 18:06:18.862635+05:30	2026-11-01
bed7778c-0c68-47d7-944e-35babc865835	9bc40a4f-d182-4a9b-817b-16979b96ac1d	\N	\N	Rohan Expiring	rohan.exp@gym.com	9876541114	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 19:16:05.57129+05:30	2026-11-01 19:16:05.57129+05:30	\N
26761a7b-5161-491f-a652-f17bf1c95e30	9bc40a4f-d182-4a9b-817b-16979b96ac1d	\N	\N	Neha Expired	neha.exp@gym.com	9876541115	\N	\N	\N	\N	\N	\N	\N	f	2026-11-01 19:16:05.647473+05:30	2026-11-01 19:16:05.647473+05:30	\N
3e311304-db12-405d-b66d-7dd4b6fdd817	9bc40a4f-d182-4a9b-817b-16979b96ac1d	\N	\N	Rohan Expiring	rohan.exp@gym.com	9876541114	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 19:16:54.58772+05:30	2026-11-01 19:16:54.58772+05:30	\N
9c4d76db-3dda-410c-b46c-68deb36c0286	9bc40a4f-d182-4a9b-817b-16979b96ac1d	\N	\N	Neha Expired	neha.exp@gym.com	9876541115	\N	\N	\N	\N	\N	\N	\N	f	2026-11-01 19:16:54.609836+05:30	2026-11-01 19:16:54.609836+05:30	\N
74416a0e-47ff-41f7-bd99-f2f8ca846b5e	9bc40a4f-d182-4a9b-817b-16979b96ac1d	\N	\N	Rohan Expiring	rohan.exp@gym.com	9876541114	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 19:17:20.241797+05:30	2026-11-01 19:17:20.577456+05:30	\N
46f1e252-804f-45fa-8317-9fce9513d392	5b667fea-b783-49d0-a8e3-e85be41f5943	\N	\N	Priya Frozen	priya@test.com	9876560013	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:19:09.155672+05:30	2026-11-01 21:19:09.155672+05:30	\N
9201d753-1d6d-41f8-8a16-5304ecc0bdd2	9bc40a4f-d182-4a9b-817b-16979b96ac1d	\N	\N	Neha Expired	neha.exp@gym.com	9876541115	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 19:17:20.262581+05:30	2026-11-01 19:17:20.751393+05:30	\N
7fcb3c33-454c-4e3f-8c98-77eae7068aa1	5a487df0-199b-4b34-b88e-c83dac808811	\N	\N	P4 Rahul Sharma	rahul.freeze@test.com	9876549999	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 19:17:29.451757+05:30	2026-11-01 19:17:29.609441+05:30	2026-11-01
0d32bb44-227f-4af2-bb49-01b5dc4dfcb4	5b667fea-b783-49d0-a8e3-e85be41f5943	\N	\N	Ankit NoPlan	ankit@test.com	9876560014	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:19:09.164077+05:30	2026-11-01 21:19:09.164077+05:30	\N
35ac6c34-3fc4-4843-931b-76a89e093583	1cc93c71-1c46-490f-97a7-1a14b831df75	\N	\N	D5 Member 1A	m1a@test.com	9876550011	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:11:16.575662+05:30	2026-11-01 21:11:16.575662+05:30	\N
98bb4c45-cf11-4e40-bff5-aa8224bc99da	1cc93c71-1c46-490f-97a7-1a14b831df75	\N	\N	D5 Member 1B	m1b@test.com	9876550012	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:11:16.579033+05:30	2026-11-01 21:11:16.579033+05:30	\N
fcf44996-90e5-4781-886e-f1ed86a4e0f0	0f965952-0b37-4401-aa79-87b7e9ba982b	\N	\N	D5 Member 1C	m1c@test.com	9876550013	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:11:16.582033+05:30	2026-11-01 21:11:16.582033+05:30	\N
8eb492bf-7d7c-4a49-a2c9-e35c027518f4	1cc93c71-1c46-490f-97a7-1a14b831df75	\N	\N	D5 Member 1D	m1d@test.com	9876550014	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:11:16.584084+05:30	2026-11-01 21:11:16.584084+05:30	\N
46a50eaa-a751-4bc1-9e6f-82e45997db55	91a5f79e-a8b8-4749-b043-65533e7c8a3b	\N	\N	D5 Member 2	m2@test.com	9876550021	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:11:16.588119+05:30	2026-11-01 21:11:16.588119+05:30	\N
ba352d61-a8a2-4878-9e76-bf82e550ac86	9bc40a4f-d182-4a9b-817b-16979b96ac1d	\N	\N	Rohan Expiring	rohan.exp@gym.com	9876541114	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:12:02.163959+05:30	2026-11-01 21:12:02.565597+05:30	\N
16406994-4339-4fb4-8e62-bf26ea4b9ece	5b667fea-b783-49d0-a8e3-e85be41f5943	\N	\N	Vikas Deactivated	vikas@test.com	9876560015	\N	\N	\N	\N	\N	\N	\N	f	2026-11-01 21:19:09.168261+05:30	2026-11-01 21:19:09.168261+05:30	\N
ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	9bc40a4f-d182-4a9b-817b-16979b96ac1d	\N	\N	Neha Expired	neha.exp@gym.com	9876541115	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:12:02.261596+05:30	2026-11-01 21:12:02.757025+05:30	\N
147a2fb6-a81c-40c0-8cce-89e504ffaa1f	5b667fea-b783-49d0-a8e3-e85be41f5943	\N	\N	Karan Active	karan@test.com	9876560011	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:19:09.112127+05:30	2026-11-01 21:19:09.112127+05:30	\N
09660be9-8054-46e1-883f-d70cdaa5daf0	5b667fea-b783-49d0-a8e3-e85be41f5943	\N	\N	Suresh Expired	suresh@test.com	9876560012	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:19:09.148861+05:30	2026-11-01 21:19:09.148861+05:30	\N
b240b856-dea9-4f0b-8d23-1c1c43d5cc56	5a487df0-199b-4b34-b88e-c83dac808811	\N	\N	P4 Rahul Sharma	rahul.freeze@test.com	9876549999	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:20:39.782033+05:30	2026-11-01 21:20:39.930883+05:30	2026-11-01
36e83cee-3658-4935-bdb0-b87e92b69025	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	\N	\N	P3 Member 1	p3m1@test.com	9876570011	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:29:28.573969+05:30	2026-11-01 21:29:28.573969+05:30	\N
7c1f4539-1e36-4c84-8528-6f6a5ede7be8	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	\N	\N	P3 Member 2	p3m2@test.com	9876570012	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:29:28.64957+05:30	2026-11-01 21:29:28.64957+05:30	\N
c67eebf9-b9f9-4675-aa45-e3a73eae914e	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	\N	\N	P3 Member 3	p3m3@test.com	9876570013	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:29:28.657705+05:30	2026-11-01 21:29:28.657705+05:30	\N
a35bda2a-8ebf-4ebd-85a7-55db7d52d15a	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	\N	\N	P3 Frozen Member	p3m4@test.com	9876570014	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:29:28.666755+05:30	2026-11-01 21:29:28.666755+05:30	\N
dcb99703-aacb-433e-843d-766fe82b7fe2	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	\N	\N	P3 Expired Member	p3m5@test.com	9876570015	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:29:28.674595+05:30	2026-11-01 21:29:28.674595+05:30	\N
c62740f6-056c-4247-82dc-af43960c83dd	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	P3 Gym2 Member	other@test.com	9876570021	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:29:28.684095+05:30	2026-11-01 21:29:28.684095+05:30	\N
677f7ba7-5e7a-43e8-a2d0-aa98cf76507d	89f1214c-6ca0-4077-b2e6-ad3f53a62c0d	\N	\N	P4 Member One	p4m1_5826@gym.com	988815826	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:44:35.374805+05:30	2026-11-01 21:44:35.374805+05:30	2026-11-01
5a6c2002-b202-4e7c-89f6-5b88667bea2a	89f1214c-6ca0-4077-b2e6-ad3f53a62c0d	\N	\N	P4 Member Two	p4m2_5826@gym.com	988825826	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:44:35.385208+05:30	2026-11-01 21:44:35.385208+05:30	2026-11-01
270ce820-bfa0-4fa4-9b7e-ab917525dae6	89f1214c-6ca0-4077-b2e6-ad3f53a62c0d	\N	\N	P4 Member Three	p4m3_5826@gym.com	988835826	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:44:35.388392+05:30	2026-11-01 21:44:35.388392+05:30	2026-11-01
451f4bb6-36bb-4c07-acf9-cb5b2681da67	0371cdb0-821d-442e-855d-cc2f814130ca	\N	\N	P4 Member One	p4m1_5660@gym.com	988815660	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:44:55.720595+05:30	2026-11-01 21:44:55.720595+05:30	2026-11-01
7a0e483f-6010-44ec-8bad-c2b0c95ccdc2	0371cdb0-821d-442e-855d-cc2f814130ca	\N	\N	P4 Member Two	p4m2_5660@gym.com	988825660	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:44:55.726349+05:30	2026-11-01 21:44:55.726349+05:30	2026-11-01
75f8920f-4738-44e8-b3c2-967c64685b65	0371cdb0-821d-442e-855d-cc2f814130ca	\N	\N	P4 Member Three	p4m3_5660@gym.com	988835660	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:44:55.748102+05:30	2026-11-01 21:44:55.748102+05:30	2026-11-01
af29c170-4319-4099-8da5-e6c3d4285a0d	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	\N	\N	P4 Member One	p4m1_8509@gym.com	988818509	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:46:15.693838+05:30	2026-11-01 21:46:15.693838+05:30	2026-11-01
80256997-b191-41d4-b0da-aabe82109df1	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	\N	\N	P4 Member Two	p4m2_8509@gym.com	988828509	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:46:15.713289+05:30	2026-11-01 21:46:15.713289+05:30	2026-11-01
683f13bb-46a7-4d88-a7cc-9c28f514f5a4	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	\N	\N	P4 Member Three	p4m3_8509@gym.com	988838509	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:46:15.715648+05:30	2026-11-01 21:46:15.715648+05:30	2026-11-01
f395d9c1-2c4d-4a6f-9558-384a0c2f502e	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	\N	\N	P4 Member One	p4m1_2171@gym.com	988812171	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:48:13.212955+05:30	2026-11-01 21:48:13.212955+05:30	2026-11-01
f0b3d976-2ddb-4817-b1ef-ae51abb7f133	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	\N	\N	P4 Member Two	p4m2_2171@gym.com	988822171	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:48:13.220442+05:30	2026-11-01 21:48:13.220442+05:30	2026-11-01
ce1799c1-fcfb-43e8-a06b-685bd0a39dd0	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	\N	\N	P4 Member Three	p4m3_2171@gym.com	988832171	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:48:13.221832+05:30	2026-11-01 21:48:13.221832+05:30	2026-11-01
faed8c47-af39-4ea8-8145-ee40cda43b0f	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	\N	\N	P4 Member One	p4m1_3855@gym.com	988813855	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:49:25.92162+05:30	2026-11-01 21:49:25.92162+05:30	2026-11-01
a4ee66ca-a5fe-4103-a02b-a5231fc1fd15	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	\N	\N	P4 Member Two	p4m2_3855@gym.com	988823855	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:49:25.928014+05:30	2026-11-01 21:49:25.928014+05:30	2026-11-01
1741dfb5-4ec3-489e-8a91-c39d64a3d7f0	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	\N	\N	P4 Member Three	p4m3_3855@gym.com	988833855	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 21:49:25.929377+05:30	2026-11-01 21:49:25.929377+05:30	2026-11-01
e98fd142-eae8-43a6-ba0c-8d668b89d1eb	e1d06c17-154f-40dc-a736-6e5d45aff429	\N	\N	P4 Member One	p4m1_8852@gym.com	988818852	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 22:08:27.187163+05:30	2026-11-01 22:08:27.187163+05:30	2026-11-01
13fab36d-cefa-4bf9-a090-8c1277b1b200	e1d06c17-154f-40dc-a736-6e5d45aff429	\N	\N	P4 Member Two	p4m2_8852@gym.com	988828852	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 22:08:27.195373+05:30	2026-11-01 22:08:27.195373+05:30	2026-11-01
61ba65a8-d8ba-4894-bc1b-2b5385306b0b	e1d06c17-154f-40dc-a736-6e5d45aff429	\N	\N	P4 Member Three	p4m3_8852@gym.com	988838852	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 22:08:27.2077+05:30	2026-11-01 22:08:27.2077+05:30	2026-11-01
60872a0d-8bfb-4b5c-867d-4be00f2e3527	9a09c837-a0e5-4fa5-8c5c-1ab356d8fe7c	\N	\N	D6 Member Inv	d6invmem@test.com	9887711224	\N	\N	\N	\N	\N	\N	\N	t	2026-11-01 22:18:12.331596+05:30	2026-11-01 22:18:12.331596+05:30	2026-11-01
4574f97c-7b17-4c53-aa5a-3682cdd2444a	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Converted Member One 499523	convert1_499523@test.com	9849952310	1995-05-15	Male	123 Gym Street, Bangalore	\N	Emergency Person	9876543210	No known injuries	t	2026-11-16 23:38:19.862912+05:30	2026-11-16 23:38:19.862912+05:30	2026-11-16
15baaffb-e770-4e56-9056-bd82d0b67d13	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Member From Lead Two 499523	convert2_499523@test.com	9849952320	\N	\N	\N	\N	\N	\N	\N	t	2026-11-16 23:38:20.050449+05:30	2026-11-16 23:38:20.050449+05:30	\N
a74e7d78-9411-4f5c-8ee9-e0fc3f436c16	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Double Member Attempt	\N	9876719888	\N	\N	\N	\N	\N	\N	\N	t	2026-11-16 23:59:27.413538+05:30	2026-11-16 23:59:27.413538+05:30	\N
b24b1fb9-8780-4efc-915c-3314a6166bb8	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Member From Lead Two 767198	convert2_767198@test.com	9876719820	\N	\N	\N	\N	\N	\N	\N	t	2026-11-16 23:59:27.48827+05:30	2026-11-16 23:59:27.48827+05:30	\N
07c51ec8-ddd4-4914-be98-47834072fbef	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Converted Member One 886352	convert1_886352@test.com	9888635210	1995-05-15	Male	123 Gym Street, Bangalore	\N	Emergency Person	9876543210	No known injuries	t	2026-11-17 00:01:27.001379+05:30	2026-11-17 00:01:27.001379+05:30	2026-11-16
0b5eb206-427c-4d30-b726-ce1fa0f1881f	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Member From Lead Two 886352	convert2_886352@test.com	9888635220	\N	\N	\N	\N	\N	\N	\N	t	2026-11-17 00:01:27.139254+05:30	2026-11-17 00:01:27.139254+05:30	\N
1b3b028d-2618-4209-831c-eb5de0c9ccd0	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Converted Member One 901219	convert1_901219@test.com	9890121910	1995-05-15	Male	123 Gym Street, Bangalore	\N	Emergency Person	9876543210	No known injuries	t	2026-11-17 00:01:41.525135+05:30	2026-11-17 00:01:41.525135+05:30	2026-11-16
0ee3e569-9dec-426d-be81-feb96b019c1a	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Member From Lead Two 901219	convert2_901219@test.com	9890121920	\N	\N	\N	\N	\N	\N	\N	t	2026-11-17 00:01:41.622653+05:30	2026-11-17 00:01:41.622653+05:30	\N
db297645-e96e-4edb-9ef5-68da13adc058	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Converted Member One 739920	convert1_739920@test.com	9873992010	1995-05-15	Male	123 Gym Street, Bangalore	\N	Emergency Person	9876543210	No known injuries	t	2026-11-17 08:19:00.343591+05:30	2026-11-17 08:19:00.343591+05:30	2026-11-17
3c77d2bf-0245-43d6-89c3-ae9cab5f92d5	de39de91-f4e1-4ac4-b856-aa8025115452	\N	\N	Member From Lead Two 739920	convert2_739920@test.com	9873992020	\N	\N	\N	\N	\N	\N	\N	t	2026-11-17 08:19:00.528425+05:30	2026-11-17 08:19:00.528425+05:30	\N
82f4afe9-70e7-4081-a953-8aff4fd4b6c2	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Test Member 1795023547870	member1795023547870@test.com	9879573746	\N	\N	\N	\N	\N	\N	\N	t	2026-11-18 23:09:07.902534+05:30	2026-11-18 23:09:07.902534+05:30	2026-11-18
41811c34-55be-461e-ae29-5744da810922	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Test Member 1795025417729	member1795025417729@test.com	9873227368	\N	\N	\N	\N	\N	\N	\N	t	2026-11-18 23:40:17.791488+05:30	2026-11-18 23:40:17.791488+05:30	2026-11-18
\.


--
-- Data for Name: membership_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_plans (id, branch_id, name, description, duration_days, price, max_freeze_days, is_active, created_at, updated_at, freeze_fee) FROM stdin;
3028150f-6be8-44e1-99f5-0bf1b03d3cf8	df582d89-ffe0-49d2-ad94-bb426725bfd6	1 Year plan	\N	365	6999.00	10	t	2026-10-16 22:31:52.779143+05:30	2026-10-16 22:31:52.779143+05:30	0.00
6d280421-378a-4a49-b7e8-aeb51a839565	df582d89-ffe0-49d2-ad94-bb426725bfd6	6 Months plan	\N	180	3999.00	0	t	2026-10-16 22:32:27.799355+05:30	2026-10-16 22:32:27.799355+05:30	0.00
9fa25449-d2c5-49ba-bd61-c19ca9663c8d	df582d89-ffe0-49d2-ad94-bb426725bfd6	1 Month Plan	\N	30	1499.00	2	t	2026-10-16 22:33:11.570662+05:30	2026-10-16 22:33:11.570662+05:30	0.00
f8559a88-cd6f-4b7a-9d32-fc105a992d7f	630b3844-e660-45a5-bdbc-abc8c0f19802	Test Plan Restrictions	\N	30	1000.00	0	t	2026-11-01 11:27:03.257634+05:30	2026-11-01 11:27:03.257634+05:30	0.00
9d27f10b-9808-4b2f-af7e-6e58e8206e6a	2b0c6048-dbf6-4dae-b831-48111246603e	Plan Gym A	\N	30	1500.00	0	t	2026-11-01 11:35:06.677813+05:30	2026-11-01 11:35:06.677813+05:30	0.00
20150c64-14d6-47b5-ab2f-c4a589636ca4	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	\N	30	2000.00	15	t	2026-11-01 18:04:34.68042+05:30	2026-11-01 18:04:34.68042+05:30	150.00
e6e15910-ebc3-40e1-966e-7d5518ea0a47	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	\N	30	2000.00	15	t	2026-11-01 18:04:49.592724+05:30	2026-11-01 18:04:49.592724+05:30	150.00
a10ed66f-436a-40d7-983d-70bc50558e6b	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	\N	30	2000.00	15	t	2026-11-01 18:05:19.067051+05:30	2026-11-01 18:05:19.067051+05:30	150.00
f06ac522-f7d9-4117-a469-a7449f9d233b	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	\N	30	2000.00	15	t	2026-11-01 18:05:33.478384+05:30	2026-11-01 18:05:33.478384+05:30	150.00
6848133e-d13d-4d35-86d5-d745551f0765	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	\N	30	2000.00	15	t	2026-11-01 18:05:58.813057+05:30	2026-11-01 18:05:58.813057+05:30	150.00
54c6bd37-5765-4246-a08d-58a8cd900121	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	\N	30	2000.00	15	t	2026-11-01 18:06:18.854416+05:30	2026-11-01 18:06:18.854416+05:30	150.00
e704580e-0c55-4214-9062-bd6042dd4e29	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Month Plan	\N	30	2000.00	7	t	2026-11-01 19:15:32.670177+05:30	2026-11-01 19:15:32.670177+05:30	100.00
02c65fb2-f655-4010-9581-c1f5048e3e5b	9bc40a4f-d182-4a9b-817b-16979b96ac1d	P5 1 Year Plan	\N	365	18000.00	30	t	2026-11-01 19:15:32.679381+05:30	2026-11-01 19:15:32.679381+05:30	500.00
982202d3-bec5-4a33-9e9b-c1bb15c05375	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	\N	30	2000.00	15	t	2026-11-01 19:17:29.446326+05:30	2026-11-01 19:17:29.446326+05:30	150.00
d04fc02a-35e1-4fc8-8f39-ffbbf802c3b5	5b667fea-b783-49d0-a8e3-e85be41f5943	Standard Monthly	\N	30	2000.00	0	t	2026-11-01 21:19:09.090456+05:30	2026-11-01 21:19:09.090456+05:30	0.00
090ee986-ae31-4e18-8848-91d681b2f142	5a487df0-199b-4b34-b88e-c83dac808811	P4 Freeze Test Plan	\N	30	2000.00	15	t	2026-11-01 21:20:39.774473+05:30	2026-11-01 21:20:39.774473+05:30	150.00
29cfbfa2-7ecf-47a1-98d9-a8ca9a42a18b	e0aa422e-a36f-4dde-8b5f-3298d0ae457c	P3 Monthly Plan	\N	30	2000.00	0	t	2026-11-01 21:29:28.534311+05:30	2026-11-01 21:29:28.534311+05:30	0.00
b77ff406-f4d0-4874-a4de-905a28f2c02f	89f1214c-6ca0-4077-b2e6-ad3f53a62c0d	Annual Unlimited	\N	365	12000.00	0	t	2026-11-01 21:44:35.364535+05:30	2026-11-01 21:44:35.364535+05:30	0.00
255f2ce0-9981-4696-80b0-f013776c786b	0371cdb0-821d-442e-855d-cc2f814130ca	Annual Unlimited	\N	365	12000.00	0	t	2026-11-01 21:44:55.666907+05:30	2026-11-01 21:44:55.666907+05:30	0.00
b987c5b3-1c9f-4558-8a51-c5d63d24e969	ae95fa9b-449a-4cfb-b0ad-a7e46c2d476d	Annual Unlimited	\N	365	12000.00	0	t	2026-11-01 21:46:15.683028+05:30	2026-11-01 21:46:15.683028+05:30	0.00
8ed12483-4373-432a-b9f4-d72821e03003	0520e7ac-8ac2-45f1-88f7-1027595bc2c3	Annual Unlimited	\N	365	12000.00	0	t	2026-11-01 21:48:13.204375+05:30	2026-11-01 21:48:13.204375+05:30	0.00
0ff8ce4e-b742-434a-9b1d-d1d1368d667f	c5ee8c7b-8980-46aa-a58e-d73ffbeadf5b	Annual Unlimited	\N	365	12000.00	0	t	2026-11-01 21:49:25.912616+05:30	2026-11-01 21:49:25.912616+05:30	0.00
946e57e0-93d5-430a-8007-c6512846e9a7	e1d06c17-154f-40dc-a736-6e5d45aff429	Annual Unlimited	\N	365	12000.00	0	t	2026-11-01 22:08:27.179861+05:30	2026-11-01 22:08:27.179861+05:30	0.00
ac9f4d7f-c668-467d-9b81-6fd1aecf25e1	de39de91-f4e1-4ac4-b856-aa8025115452	Free Trial Plan 1794932146300	\N	7	0.00	0	t	2026-11-17 21:45:46.314282+05:30	2026-11-17 21:45:46.314282+05:30	0.00
57fd753e-76fa-4d30-9bfd-178c2a6db6ed	2b0c6048-dbf6-4dae-b831-48111246603e	Gold Plan 1795023547774	Quarterly Gym Access	90	4500.00	0	t	2026-11-18 23:09:07.866103+05:30	2026-11-18 23:09:07.866103+05:30	0.00
bba82de4-4485-4311-a4cf-532771de89ab	2b0c6048-dbf6-4dae-b831-48111246603e	Gold Plan 1795025417481	Quarterly Gym Access	90	4500.00	0	t	2026-11-18 23:40:17.620935+05:30	2026-11-18 23:40:17.620935+05:30	0.00
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_items (id, type, path, icon, text, plan, required_role, sort_order, is_placeholder) FROM stdin;
92a13545-d80c-4ac3-8af1-64130370d7f2	link	/face-fingerprint	ScanFace	Face & Fingerprint	Growth	\N	10	t
405902a5-a3d0-4b38-bf4d-8a62f095e268	link	/equipment	Dumbbell	Equipment	Pro	\N	14	t
5ec10669-7257-4625-8dfa-7468df4f9807	link	/reviews	Star	Reviews	Pro	\N	17	t
bdc26930-592e-4661-9e15-f10971903d82	link	/billing-invoices	FileText	Billing & invoices	Pro	\N	19	t
38260d7c-75a9-4830-8d61-428102e5deea	link	/coupons-referrals	TicketPercent	Coupons & referrals	Pro	\N	20	t
46d33efc-4ae8-48be-9d37-77b3b2a8f2ce	link	/roles-permissions	ShieldCheck	Roles & permissions	Pro	\N	21	t
45f1a383-44e2-4124-9544-4645999d0e35	link	/reports	BarChart3	Reports	Pro	\N	23	t
17a69293-5926-4eca-896f-bb0442ea1163	link	/ai-support-chatbot	Bot	AI support chatbot	Enterprise	\N	25	t
64f9dee0-b959-4328-8042-a3b1191d1cb2	link	/attendance-insights	Brain	Attendance insights	Enterprise	\N	26	t
51716dda-a093-4475-bafb-8a856208c0ee	link	/churn-prediction	TrendingDown	Churn prediction	Enterprise	\N	27	t
ed2eff50-cbfd-4548-91e4-f18ef447d91e	link	/revenue-forecast	ChartNoAxesCombined	Revenue forecast	Enterprise	\N	28	t
6048e906-1eea-41aa-b646-0d99b5b5016d	link	/workout-diet-ai	Sparkles	Workout / diet AI	Enterprise	\N	29	t
f53c6778-187c-4a3f-9daa-9341e2b456a4	link	/trainer-portal	GraduationCap	Trainer portal	Enterprise	\N	31	t
7a1b8849-5f9d-4d35-8cb6-5ee4fda8f0d6	link	/member-portal	CircleUserRound	Member portal	Enterprise	\N	32	t
e2128db3-0136-423d-a835-87624a304d0e	heading	\N	\N	Engagement	\N	\N	15	t
df572bb4-f5e4-46aa-93ef-fbb1aadf3925	heading	\N	\N	Finance & Admin	\N	\N	18	t
4581ce57-3d61-4b6e-b3bb-5436e3ccd4af	heading	\N	\N	Analytics	\N	\N	22	t
6a877d37-2636-42d1-be8d-69971808c8e3	heading	\N	\N	AI Features	\N	\N	24	t
1525f00d-1c45-404e-aa44-67d943ad1f6b	heading	\N	\N	Portals	\N	\N	30	t
56436965-8177-4657-a6cd-e17355a40260	heading	\N	\N	Core	\N	\N	0	f
e35441dc-a7d1-4c99-9bf5-cb92b4a70b92	link	/dashboard	LayoutDashboard	Dashboard	Starter	\N	1	f
42519cb8-490b-470b-b859-25d182f5c30a	link	/gyms	Building	Gym	Growth	\N	2	f
bae6fa75-8874-4e57-8c7f-4382215645f5	link	/branches	Building2	Branches	Growth	system-admin	3	f
9bd33b25-9d4c-4adc-843b-fb9c26da0885	heading	\N	\N	People	\N	\N	4	f
87ce30d9-c3cb-477c-8be6-eb307b1f1eaf	link	/members	Users	Members	Starter	\N	5	f
bd2de790-505b-4ed1-b320-3f538b84d2e0	link	/staff	BriefcaseBusiness	Staff	Growth	\N	6	f
b3f739a5-f5e2-4d78-adbe-e3b826caec53	link	/leads-crm	Target	Leads CRM	Growth	\N	7	f
9adfb725-a116-4ca7-a5f0-a0c771b4eec1	heading	\N	\N	Operations	\N	\N	8	f
b22607b9-f8d3-46e1-808b-3380550dec62	link	/attendance	CalendarCheck	Attendance	Starter	\N	9	f
c477908c-e0db-4a0d-a017-97bc60b04320	link	/membership-plans	ClipboardList	Membership Plans	Starter	\N	10	f
71782cec-d292-4721-aa42-e1105d368f93	link	/payments	CreditCard	Payments	Starter	\N	11	f
a62f7639-6ef9-424f-ac7c-830a0c8386c9	link	/expenses	ReceiptText	Expenses	Growth	\N	12	f
971c0c4e-f91c-422b-86e2-711d8631cada	heading	\N	\N	System	\N	\N	13	f
be7bad90-ff78-4cfc-b5f0-1a89ef3156a8	link	/settings	Settings	Settings	Starter	\N	14	f
a6ac77a0-0ae7-4acd-97b1-a471d5023dd6	link	/notifications	Bell	Notifications	Growth	\N	15	f
9b84a900-6a9a-4c61-b416-37c559fe9d3f	link	/users	UserCog	Manage Users	Starter	system-admin	16	f
c4f4429e-8ab6-49a9-89e8-be44aea06360	link	/billing-plans	CreditCard	Billing Plans	Starter	system-admin	17	f
c06625ab-a067-4739-89d3-3947b1f3813c	heading	\N	\N	System Administration	\N	system-admin	38	t
be4ae770-a0ea-4df5-b595-bb8061ce3a24	link	/achievements	Trophy	Achievements	Starter	\N	16	t
fdcc12dc-33dd-48e1-9bfa-5865576a027d	link	/gyms	Building	Gyms	Starter	system-admin	40	t
80f66865-cf8d-4323-b59a-2942d51c7924	link	/messages	Megaphone	Messages	Starter	\N	17	t
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, gym_id, branch_id, title, content, category, priority, start_date, end_date, is_active, created_by, created_at, updated_at, last_sent_at, sent_count) FROM stdin;
d94dac33-983c-4c74-b657-b57019397e33	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	Gym will be closed today	Attention members: The facility will be closed today for scheduled electrical and deep sanitization work. We will resume normal operational hours tomorrow at 6:00 AM.	Closure / Holiday	Urgent	2026-10-30	2026-10-30	t	\N	2026-10-30 07:41:27.157866+05:30	2026-10-30 07:41:27.157866+05:30	\N	0
2883b026-cbf3-486a-841e-2fac38363c68	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e	Steam Room & Sauna Maintenance	The steam room and sauna at Erode Branch 1 will be undergoing scheduled filter replacement today from 11:00 AM to 4:00 PM. All other workout zones remain fully open.	Maintenance	High	2026-10-30	2026-10-31	t	\N	2026-10-30 07:41:27.167246+05:30	2026-10-30 07:41:27.167246+05:30	\N	0
5e8ae69e-5881-453b-b516-84e2dbe05314	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	Upcoming Weekend HIIT Masterclass	Join our head trainer for a special 60-minute explosive HIIT Masterclass this Saturday at 8:30 AM! Open to all active membership tiers. Reserve your spot at the front desk.	Announcement	Normal	2026-10-30	2026-11-04	t	\N	2026-10-30 07:41:27.171787+05:30	2026-10-30 07:41:27.171787+05:30	\N	0
391e0c79-30d6-4772-b3ce-3c2463444350	6ecfc033-52f1-444f-a3f6-65fdd664c988	df582d89-ffe0-49d2-ad94-bb426725bfd6	New Cardio Equipment Arrival	New advanced treadmills and elliptical cross-trainers have arrived at Sankari branch. Check out the upgraded cardio deck today!	General	Normal	2026-10-29	2026-11-06	t	\N	2026-10-30 07:41:27.173601+05:30	2026-10-30 07:41:27.173601+05:30	\N	0
8f6addb3-75a6-42bf-af43-71b0aafd0e21	4e440296-d558-46e6-b0f6-5fad5910a8f3	630b3844-e660-45a5-bdbc-abc8c0f19802	Steam Room & Sauna Maintenance	The steam room and sauna at Test Gym- Branch -1 will be undergoing scheduled filter replacement today from 11:00 AM to 4:00 PM. All other workout zones remain fully open.	Maintenance	High	2026-10-30	2026-10-31	t	\N	2026-10-30 07:41:27.178876+05:30	2026-10-30 07:41:27.178876+05:30	\N	0
630ccfdf-7ab0-457a-b616-3bc5834d4c8b	4e440296-d558-46e6-b0f6-5fad5910a8f3	\N	Upcoming Weekend HIIT Masterclass	Join our head trainer for a special 60-minute explosive HIIT Masterclass this Saturday at 8:30 AM! Open to all active membership tiers. Reserve your spot at the front desk.	Announcement	Normal	2026-10-30	2026-11-04	t	\N	2026-10-30 07:41:27.180441+05:30	2026-10-30 07:41:27.180441+05:30	\N	0
e661f58e-2691-4cf9-a748-fd46349e704a	4e440296-d558-46e6-b0f6-5fad5910a8f3	38af11b9-0eff-41b0-9cac-a40a74fb31cf	New Cardio Equipment Arrival	New advanced treadmills and elliptical cross-trainers have arrived at Test Gym- Branch -2. Check out the upgraded cardio deck today!	General	Normal	2026-10-29	2026-11-06	t	\N	2026-10-30 07:41:27.181958+05:30	2026-10-30 20:32:46.54973+05:30	2026-10-30 20:32:46.54973+05:30	10
dbce6358-0ed1-4b9f-8c9e-c0dbe857f3a9	4e440296-d558-46e6-b0f6-5fad5910a8f3	38af11b9-0eff-41b0-9cac-a40a74fb31cf	Gym will be closed today	Attention members: The facility will be closed today for scheduled electrical and deep sanitization work. We will resume normal operational hours tomorrow at 6:00 AM.	Closure / Holiday	Urgent	2026-10-31	2026-10-31	t	\N	2026-10-30 07:41:27.177173+05:30	2026-10-31 18:42:45.129855+05:30	2026-10-31 18:42:45.129855+05:30	3
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, gym_id, user_id, member_id, type, channel, title, body, status, scheduled_at, sent_at, ai_generated, created_at) FROM stdin;
a4813825-501b-4b52-b4a9-6852c3d40b20	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	c18e3c58-438c-442e-8c60-6d3d8c4cd332	MEMBER_ADDED	SMS	SMS Notification	Hi Test Member Alpha, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-01 16:31:45.934301+05:30
99bbb201-cdc4-416a-8423-187d163772a8	4e440296-d558-46e6-b0f6-5fad5910a8f3	\N	27fea95a-1433-4402-9729-ab10a7def2b5	MEMBER_ADDED	SMS	SMS Notification	Hi Test Member Gym B, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-01 16:31:46.098895+05:30
64ec5f69-3a5b-4d10-841e-166f61692f09	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	82f4afe9-70e7-4081-a953-8aff4fd4b6c2	MEMBER_ADDED	SMS	SMS Notification	Hi Test Member 1795023547870, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-18 23:09:07.944924+05:30
56eb650a-636f-4282-8370-7ef39d81c40b	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	8bebe1af-cd3c-413d-a009-fddf98b9cedd	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Test- E1, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-18 23:19:16.956911+05:30
08c89913-d5dc-4ae5-8dca-7b8ee3fdc14f	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	8bebe1af-cd3c-413d-a009-fddf98b9cedd	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Test- E1, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-18 23:40:21.057897+05:30
920c3deb-045a-4fa0-a23f-e98d1b081ecf	e85928f5-e06d-4663-84ba-697347816efb	\N	706c24cf-2b67-4a25-af5d-fdd261ff9089	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi P4 Rahul Sharma, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 18:05:33.716101+05:30
693ea093-55c6-41e4-9dcd-a9e0f299204c	e85928f5-e06d-4663-84ba-697347816efb	\N	5a9fb1b0-7078-4d6a-8d06-247464e152b3	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi P4 Rahul Sharma, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 18:05:59.036508+05:30
482e3849-e444-40f1-bb12-a071e8a95624	e85928f5-e06d-4663-84ba-697347816efb	\N	9939e769-7d03-41d7-bbb9-49da78ff6787	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi P4 Rahul Sharma, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 18:06:19.094305+05:30
66c791a0-b2c4-49b8-8dcf-be7fe5943d81	59179c14-86e4-4950-8833-74c46736bbee	\N	bed7778c-0c68-47d7-944e-35babc865835	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Rohan Expiring, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 19:16:06.100669+05:30
3741ae96-1329-4851-b034-f5f9d34a27ee	59179c14-86e4-4950-8833-74c46736bbee	\N	3e311304-db12-405d-b66d-7dd4b6fdd817	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Rohan Expiring, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 19:16:54.909922+05:30
b09d8fda-922e-4845-af0c-b1a01daba91e	59179c14-86e4-4950-8833-74c46736bbee	\N	9c4d76db-3dda-410c-b46c-68deb36c0286	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Neha Expired, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 19:16:55.024328+05:30
bcc67659-2935-4aad-ba9b-24889c5018cc	59179c14-86e4-4950-8833-74c46736bbee	\N	9c4d76db-3dda-410c-b46c-68deb36c0286	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Neha Expired, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 19:16:55.090931+05:30
66e97ab1-8327-4dee-a394-886c925ab6b9	59179c14-86e4-4950-8833-74c46736bbee	\N	74416a0e-47ff-41f7-bd99-f2f8ca846b5e	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Rohan Expiring, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 19:17:20.586613+05:30
f212b719-be43-463e-9313-7eba020f59f2	59179c14-86e4-4950-8833-74c46736bbee	\N	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Neha Expired, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 19:17:20.688066+05:30
bc6f95b9-814a-45ff-b274-f5c416c749e7	59179c14-86e4-4950-8833-74c46736bbee	\N	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Neha Expired, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 19:17:20.75511+05:30
06e3ac77-342b-4041-942e-00c1dbc71d51	e85928f5-e06d-4663-84ba-697347816efb	\N	7fcb3c33-454c-4e3f-8c98-77eae7068aa1	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi P4 Rahul Sharma, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 19:17:29.613536+05:30
a4a5f194-18aa-4a8b-88a5-5f4305893790	59179c14-86e4-4950-8833-74c46736bbee	\N	ba352d61-a8a2-4878-9e76-bf82e550ac86	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Rohan Expiring, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 21:12:02.57529+05:30
d554fa67-c40c-42d6-8129-67f9f35ca747	59179c14-86e4-4950-8833-74c46736bbee	\N	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Neha Expired, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 21:12:02.664095+05:30
84a86461-8850-4c0e-aaf4-473e4dfb1771	59179c14-86e4-4950-8833-74c46736bbee	\N	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Neha Expired, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 21:12:02.760486+05:30
2e099612-3f4d-4aa3-a735-4d2c3fb4c23d	e85928f5-e06d-4663-84ba-697347816efb	\N	b240b856-dea9-4f0b-8d23-1c1c43d5cc56	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi P4 Rahul Sharma, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-01 21:20:39.93906+05:30
6a9fc8ec-0918-4a6a-a6f4-81a7a7381d19	6ecfc033-52f1-444f-a3f6-65fdd664c988	1a2c920a-fb13-46a7-8686-c0aa719159ef	3be8879b-e90c-485b-b887-3593e07d5849	expiring_membership	in_app	Test-E33	1 Month Plan expires on 25/10/2026 (Expires today)	unread	\N	\N	f	2026-10-25 19:06:12.701474+05:30
d9792f24-c267-4f6e-a5f9-04a7d16a0a04	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	4574f97c-7b17-4c53-aa5a-3682cdd2444a	MEMBER_ADDED	SMS	SMS Notification	Hi Converted Member One 499523, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-16 23:38:19.90114+05:30
d8fd22dc-0f53-43a9-91c4-6d3d316752e7	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	15baaffb-e770-4e56-9056-bd82d0b67d13	MEMBER_ADDED	SMS	SMS Notification	Hi Member From Lead Two 499523, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-16 23:38:20.057047+05:30
c976809c-36a8-46a7-850c-7f92c978e68f	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	a74e7d78-9411-4f5c-8ee9-e0fc3f436c16	MEMBER_ADDED	SMS	SMS Notification	Hi Double Member Attempt, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-16 23:59:27.433784+05:30
63c22f0c-30be-46a9-8af7-27deead7bfa7	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	b24b1fb9-8780-4efc-915c-3314a6166bb8	MEMBER_ADDED	SMS	SMS Notification	Hi Member From Lead Two 767198, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-16 23:59:27.499655+05:30
c49b8b44-8660-44e9-9671-de21ae954abc	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	07c51ec8-ddd4-4914-be98-47834072fbef	MEMBER_ADDED	SMS	SMS Notification	Hi Converted Member One 886352, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-17 00:01:27.036194+05:30
8e40203f-f5ba-413c-955a-a2f74fdf70a7	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	0b5eb206-427c-4d30-b726-ce1fa0f1881f	MEMBER_ADDED	SMS	SMS Notification	Hi Member From Lead Two 886352, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-17 00:01:27.14452+05:30
0e7acb89-9227-4852-a093-70d791ad5543	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	1b3b028d-2618-4209-831c-eb5de0c9ccd0	MEMBER_ADDED	SMS	SMS Notification	Hi Converted Member One 901219, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-17 00:01:41.530231+05:30
c5c72537-d721-46c5-a878-e65880f75d68	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	0ee3e569-9dec-426d-be81-feb96b019c1a	MEMBER_ADDED	SMS	SMS Notification	Hi Member From Lead Two 901219, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-17 00:01:41.628234+05:30
2252b126-f763-4411-80cd-de1d437552f8	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	db297645-e96e-4edb-9ef5-68da13adc058	MEMBER_ADDED	SMS	SMS Notification	Hi Converted Member One 739920, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-17 08:19:00.378832+05:30
139c5340-34d4-4358-b11d-272ca55a2cf3	1c3624e1-faa3-4de8-8244-9cc7723fe82c	\N	3c77d2bf-0245-43d6-89c3-ae9cab5f92d5	MEMBER_ADDED	SMS	SMS Notification	Hi Member From Lead Two 739920, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-17 08:19:00.530795+05:30
a54bac32-8419-4f37-ac11-1156076b6f1e	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	8bebe1af-cd3c-413d-a009-fddf98b9cedd	SUBSCRIPTION_ADDED	SMS	SMS Notification	Hi Test- E1, your PowerFit Gym subscription has been successfully activated. Thank you!	read	\N	\N	f	2026-11-18 23:18:48.745243+05:30
590e1d61-2d66-4867-b180-d2e1af064202	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N	41811c34-55be-461e-ae29-5744da810922	MEMBER_ADDED	SMS	SMS Notification	Hi Test Member 1795025417729, welcome to PowerFit Gym! Your membership profile has been successfully created.	read	\N	\N	f	2026-11-18 23:40:17.970586+05:30
411a9e5f-97f2-4bfd-b57d-ee388e103c4d	6ecfc033-52f1-444f-a3f6-65fdd664c988	7857b428-4e3f-473d-839c-79abda528973	94f23150-931e-4c30-893f-d0e460460961	expiring_membership	in_app	Test-E2	1 Month Plan expires on 20/11/2026 (Expires tomorrow)	unread	\N	\N	f	2026-11-19 21:44:46.748614+05:30
c8715029-5f7a-4ac9-a678-2654bf2fb59f	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	7857b428-4e3f-473d-839c-79abda528973	36e83cee-3658-4935-bdb0-b87e92b69025	expiring_membership	in_app	P3 Member 1	P3 Monthly Plan expires on 21/11/2026 (in 2 days)	unread	\N	\N	f	2026-11-19 21:44:46.748614+05:30
0c7ae300-887e-48a3-9939-615f7d664f5e	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	7857b428-4e3f-473d-839c-79abda528973	7c1f4539-1e36-4c84-8528-6f6a5ede7be8	expiring_membership	in_app	P3 Member 2	P3 Monthly Plan expires on 21/11/2026 (in 2 days)	unread	\N	\N	f	2026-11-19 21:44:46.748614+05:30
72b8b3f0-c275-4193-bfed-0dfc46087d81	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	7857b428-4e3f-473d-839c-79abda528973	c67eebf9-b9f9-4675-aa45-e3a73eae914e	expiring_membership	in_app	P3 Member 3	P3 Monthly Plan expires on 21/11/2026 (in 2 days)	unread	\N	\N	f	2026-11-19 21:44:46.748614+05:30
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, member_id, membership_id, branch_id, amount, payment_mode, payment_ref, payment_date, status, notes, created_by, created_at, gym_id) FROM stdin;
561d0931-3482-43b8-8da6-d8516fbe0ef1	3be8879b-e90c-485b-b887-3593e07d5849	efbfd927-6ec3-4e24-843c-96e602a0ff9e	2b0c6048-dbf6-4dae-b831-48111246603e	1499.00	cash	\N	2026-10-20 21:43:51.758667+05:30	completed	\N	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-20 21:43:51.758667+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988
8a5f690d-1776-4475-80b3-2fabc214a3a0	94f23150-931e-4c30-893f-d0e460460961	8d8d54b7-147b-4746-a7da-c82f8b313160	2b0c6048-dbf6-4dae-b831-48111246603e	3999.00	cash	\N	2026-10-20 21:51:30.762783+05:30	completed	\N	1a2c920a-fb13-46a7-8686-c0aa719159ef	2026-10-20 21:51:30.762783+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988
4bff7cb9-fb6e-47c3-b4df-e6358857be09	94f23150-931e-4c30-893f-d0e460460961	21e2f0ed-2b3e-494b-878b-5a01db18dd7d	2b0c6048-dbf6-4dae-b831-48111246603e	1499.00	cash	\N	2026-10-21 23:03:37.084033+05:30	completed	\N	7857b428-4e3f-473d-839c-79abda528973	2026-10-21 23:03:37.084033+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988
094acb95-99a8-4fa8-a285-4bfb8f7723c8	7aeaa05b-f38b-4364-bc47-7463222144a1	\N	630b3844-e660-45a5-bdbc-abc8c0f19802	1500.00	cash	\N	2026-11-01 11:36:44.833694+05:30	completed	\N	\N	2026-11-01 11:36:44.833694+05:30	4e440296-d558-46e6-b0f6-5fad5910a8f3
7e995748-1382-460d-bcd7-9718558a84bc	706c24cf-2b67-4a25-af5d-fdd261ff9089	b2440e93-2d3e-4561-9bee-247b59b8b2b3	5a487df0-199b-4b34-b88e-c83dac808811	2000.00	UPI	\N	2026-11-01 18:05:33.708785+05:30	completed	\N	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 18:05:33.708785+05:30	e85928f5-e06d-4663-84ba-697347816efb
69b1985f-9948-4888-9777-4ca54caaa1b4	5a9fb1b0-7078-4d6a-8d06-247464e152b3	11779802-9cd1-4f0f-9a1b-3524bd35650f	5a487df0-199b-4b34-b88e-c83dac808811	2000.00	UPI	\N	2026-11-01 18:05:59.031274+05:30	completed	\N	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 18:05:59.031274+05:30	e85928f5-e06d-4663-84ba-697347816efb
c3d1dd02-eb6c-493a-959f-13c686f05efb	5a9fb1b0-7078-4d6a-8d06-247464e152b3	11779802-9cd1-4f0f-9a1b-3524bd35650f	5a487df0-199b-4b34-b88e-c83dac808811	150.00	Cash	\N	2026-11-01 18:05:59.211674+05:30	completed	Membership freeze fee: Medical leave	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 18:05:59.211674+05:30	e85928f5-e06d-4663-84ba-697347816efb
2e3b08a5-758e-462e-8a8c-8fec4a13ff91	9939e769-7d03-41d7-bbb9-49da78ff6787	db270b18-bad4-432e-b776-f77b04ca25d0	5a487df0-199b-4b34-b88e-c83dac808811	2000.00	UPI	\N	2026-11-01 18:06:19.088475+05:30	completed	\N	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 18:06:19.088475+05:30	e85928f5-e06d-4663-84ba-697347816efb
7d9d94e2-4f01-4354-bc27-585cb993642d	9939e769-7d03-41d7-bbb9-49da78ff6787	db270b18-bad4-432e-b776-f77b04ca25d0	5a487df0-199b-4b34-b88e-c83dac808811	150.00	Cash	\N	2026-11-01 18:06:19.213507+05:30	completed	Membership freeze fee: Medical leave	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 18:06:19.213507+05:30	e85928f5-e06d-4663-84ba-697347816efb
57eb0029-62ec-422c-aabd-89c8acecd7c6	bed7778c-0c68-47d7-944e-35babc865835	fa0530e3-dcac-40f3-85e7-5da9f563efbf	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	cash	\N	2026-11-01 19:16:05.633589+05:30	completed	\N	\N	2026-11-01 19:16:05.633589+05:30	59179c14-86e4-4950-8833-74c46736bbee
e9361a37-89c9-4862-b574-b07dbbb64e25	26761a7b-5161-491f-a652-f17bf1c95e30	3468ec1f-d6de-449a-b384-db9609935f7b	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	upi	\N	2026-11-01 19:16:05.651096+05:30	completed	\N	\N	2026-11-01 19:16:05.651096+05:30	59179c14-86e4-4950-8833-74c46736bbee
5148227b-502e-427c-b1ef-c5a7b2d8e4c7	bed7778c-0c68-47d7-944e-35babc865835	5c406635-d81d-45ce-8938-41b2111caafa	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	cash	\N	2026-11-01 19:16:06.091915+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 19:16:06.091915+05:30	59179c14-86e4-4950-8833-74c46736bbee
519570cf-3e1d-4209-ae20-835220649cc5	3e311304-db12-405d-b66d-7dd4b6fdd817	87d1ea6d-7449-4f62-9494-9e89d8776e91	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	cash	\N	2026-11-01 19:16:54.602061+05:30	completed	\N	\N	2026-11-01 19:16:54.602061+05:30	59179c14-86e4-4950-8833-74c46736bbee
39248147-ea27-4135-8227-8003e5642f4a	9c4d76db-3dda-410c-b46c-68deb36c0286	ee82bfc4-4a0c-4cfd-b52d-330b4f731e4d	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	upi	\N	2026-11-01 19:16:54.613674+05:30	completed	\N	\N	2026-11-01 19:16:54.613674+05:30	59179c14-86e4-4950-8833-74c46736bbee
4a343ad5-7543-4125-8464-0fa7183533f7	3e311304-db12-405d-b66d-7dd4b6fdd817	722f5761-b6a7-4ac8-bbe2-ad0858eb2943	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	cash	\N	2026-11-01 19:16:54.90403+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 19:16:54.90403+05:30	59179c14-86e4-4950-8833-74c46736bbee
e9805d70-b33c-47be-940e-a46a16924cad	9c4d76db-3dda-410c-b46c-68deb36c0286	86c92093-50b0-4e30-93c4-760088c6462b	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	upi	\N	2026-11-01 19:16:55.021599+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 19:16:55.021599+05:30	59179c14-86e4-4950-8833-74c46736bbee
f7d5dc85-00d4-45ea-8d89-29441d0e2651	9c4d76db-3dda-410c-b46c-68deb36c0286	a7e1b10d-b902-4de4-9978-5e15e4430347	9bc40a4f-d182-4a9b-817b-16979b96ac1d	18000.00	card	\N	2026-11-01 19:16:55.087947+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 19:16:55.087947+05:30	59179c14-86e4-4950-8833-74c46736bbee
48ea8fc3-cc8c-460c-a579-d22733de304b	74416a0e-47ff-41f7-bd99-f2f8ca846b5e	c4b63067-c1ea-4d00-961d-d3042ed7ae5a	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	cash	\N	2026-11-01 19:17:20.254093+05:30	completed	\N	\N	2026-11-01 19:17:20.254093+05:30	59179c14-86e4-4950-8833-74c46736bbee
1e599248-3c98-4861-85c1-27cabe4bd639	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	f46e4440-a536-4850-bdfe-234e050bab20	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	upi	\N	2026-11-01 19:17:20.266559+05:30	completed	\N	\N	2026-11-01 19:17:20.266559+05:30	59179c14-86e4-4950-8833-74c46736bbee
432ab925-0e09-4607-93a7-1943857db6fb	74416a0e-47ff-41f7-bd99-f2f8ca846b5e	c6fbac30-1077-44a6-9a79-a05ea46a5f05	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	cash	\N	2026-11-01 19:17:20.579921+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 19:17:20.579921+05:30	59179c14-86e4-4950-8833-74c46736bbee
e89f0913-8722-48c5-a8cd-b5172807601a	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	4c744ef2-d3ea-4dc2-a4d0-f802cc93ea90	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	upi	\N	2026-11-01 19:17:20.685407+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 19:17:20.685407+05:30	59179c14-86e4-4950-8833-74c46736bbee
172dd49f-277b-4f27-874b-4008eb7a71d3	9201d753-1d6d-41f8-8a16-5304ecc0bdd2	7e195617-59c5-4ec0-9ed0-577e8ee8432e	9bc40a4f-d182-4a9b-817b-16979b96ac1d	18000.00	card	\N	2026-11-01 19:17:20.752508+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 19:17:20.752508+05:30	59179c14-86e4-4950-8833-74c46736bbee
b6cd06d0-bc19-4446-8521-19a2787c18e9	7fcb3c33-454c-4e3f-8c98-77eae7068aa1	86afd5c8-13c1-40ac-85c2-d7b8d5bc2fd1	5a487df0-199b-4b34-b88e-c83dac808811	2000.00	UPI	\N	2026-11-01 19:17:29.610689+05:30	completed	\N	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 19:17:29.610689+05:30	e85928f5-e06d-4663-84ba-697347816efb
23d3d8b7-d326-41cc-a749-6a8fa1d69109	7fcb3c33-454c-4e3f-8c98-77eae7068aa1	86afd5c8-13c1-40ac-85c2-d7b8d5bc2fd1	5a487df0-199b-4b34-b88e-c83dac808811	150.00	Cash	\N	2026-11-01 19:17:29.805343+05:30	completed	Membership freeze fee: Medical leave	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 19:17:29.805343+05:30	e85928f5-e06d-4663-84ba-697347816efb
82b2c46f-f948-42a1-a74e-c715084ec5ef	ba352d61-a8a2-4878-9e76-bf82e550ac86	eeedc7d6-e411-4cf7-a9d5-90a348f58cdf	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	cash	\N	2026-11-01 21:12:02.252033+05:30	completed	\N	\N	2026-11-01 21:12:02.252033+05:30	59179c14-86e4-4950-8833-74c46736bbee
531dc108-7483-4753-b2c5-f2823372344b	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	e037d466-9b4a-4513-bb67-3c17b988fb41	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	upi	\N	2026-11-01 21:12:02.265006+05:30	completed	\N	\N	2026-11-01 21:12:02.265006+05:30	59179c14-86e4-4950-8833-74c46736bbee
118465fc-d3a0-4aae-91bf-fd76de9bfda3	ba352d61-a8a2-4878-9e76-bf82e550ac86	37e6a638-3435-4a9a-b624-0b91f0dafc61	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	cash	\N	2026-11-01 21:12:02.567814+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 21:12:02.567814+05:30	59179c14-86e4-4950-8833-74c46736bbee
b24bb6f0-3502-4b0e-a704-8bfecab1b305	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	978a6387-37ab-466f-a81e-f1fea99667d1	9bc40a4f-d182-4a9b-817b-16979b96ac1d	2000.00	upi	\N	2026-11-01 21:12:02.660588+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 21:12:02.660588+05:30	59179c14-86e4-4950-8833-74c46736bbee
d56b73d6-60d0-4ddc-80a2-03228400e384	ccc9cfc3-adc9-4f3a-ada8-69f9c3bfb5f5	40f2e6a5-39ba-4f96-af33-8e8aba9b33be	9bc40a4f-d182-4a9b-817b-16979b96ac1d	18000.00	card	\N	2026-11-01 21:12:02.758115+05:30	completed	\N	855c156d-e6c2-4c28-828b-7aae706838e5	2026-11-01 21:12:02.758115+05:30	59179c14-86e4-4950-8833-74c46736bbee
de4782e7-92d8-4d2d-9263-3db1c7d52d9e	b240b856-dea9-4f0b-8d23-1c1c43d5cc56	ce09e4f6-d812-4741-b508-993d56a825ac	5a487df0-199b-4b34-b88e-c83dac808811	2000.00	UPI	\N	2026-11-01 21:20:39.933184+05:30	completed	\N	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 21:20:39.933184+05:30	e85928f5-e06d-4663-84ba-697347816efb
f4306c1a-020b-416a-9ae6-d808519fc298	b240b856-dea9-4f0b-8d23-1c1c43d5cc56	ce09e4f6-d812-4741-b508-993d56a825ac	5a487df0-199b-4b34-b88e-c83dac808811	150.00	Cash	\N	2026-11-01 21:20:40.092611+05:30	completed	Membership freeze fee: Medical leave	16b698d3-8127-48cd-aebc-5803e3d4a812	2026-11-01 21:20:40.092611+05:30	e85928f5-e06d-4663-84ba-697347816efb
bb2588d9-4f76-4f24-820d-ad95e76944bc	8bebe1af-cd3c-413d-a009-fddf98b9cedd	\N	2b0c6048-dbf6-4dae-b831-48111246603e	1500.00	Cash	\N	2026-11-18 23:18:48.412876+05:30	completed	Desk front collection	bf7e9bfe-9358-4f47-85b0-bd6c2134aa74	2026-11-18 23:18:48.412876+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988
86d1c197-e87a-422d-ad9e-d9508cbe1aa1	8bebe1af-cd3c-413d-a009-fddf98b9cedd	\N	2b0c6048-dbf6-4dae-b831-48111246603e	1500.00	Cash	\N	2026-11-18 23:19:16.839974+05:30	completed	Desk front collection	bf7e9bfe-9358-4f47-85b0-bd6c2134aa74	2026-11-18 23:19:16.839974+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988
c8c0ec00-a30d-42e6-a911-588c02380a0c	8bebe1af-cd3c-413d-a009-fddf98b9cedd	\N	2b0c6048-dbf6-4dae-b831-48111246603e	1500.00	Cash	\N	2026-11-18 23:40:20.891265+05:30	completed	Desk front collection	bf7e9bfe-9358-4f47-85b0-bd6c2134aa74	2026-11-18 23:40:20.891265+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, module, action, description) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plans (id, gym_id, name, description, duration_months, price, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: push_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_tokens (id, user_id, member_id, device_token, platform, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referrals (id, referrer_id, referred_id, reward_given, reward_amount, created_at) FROM stdin;
\.


--
-- Data for Name: refunds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refunds (id, payment_id, member_id, amount, reason, refund_mode, refund_ref, refunded_by, refunded_at, created_at) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reviews (id, branch_id, member_id, trainer_id, rating, review_text, is_public, created_at) FROM stdin;
\.


--
-- Data for Name: role_menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_menu_items (role_id, menu_item_id) FROM stdin;
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	92a13545-d80c-4ac3-8af1-64130370d7f2
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	405902a5-a3d0-4b38-bf4d-8a62f095e268
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	e2128db3-0136-423d-a835-87624a304d0e
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	be4ae770-a0ea-4df5-b595-bb8061ce3a24
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	5ec10669-7257-4625-8dfa-7468df4f9807
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	df572bb4-f5e4-46aa-93ef-fbb1aadf3925
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	bdc26930-592e-4661-9e15-f10971903d82
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	38260d7c-75a9-4830-8d61-428102e5deea
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	46d33efc-4ae8-48be-9d37-77b3b2a8f2ce
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	4581ce57-3d61-4b6e-b3bb-5436e3ccd4af
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	45f1a383-44e2-4124-9544-4645999d0e35
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	6a877d37-2636-42d1-be8d-69971808c8e3
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	17a69293-5926-4eca-896f-bb0442ea1163
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	64f9dee0-b959-4328-8042-a3b1191d1cb2
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	51716dda-a093-4475-bafb-8a856208c0ee
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	ed2eff50-cbfd-4548-91e4-f18ef447d91e
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	6048e906-1eea-41aa-b646-0d99b5b5016d
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	1525f00d-1c45-404e-aa44-67d943ad1f6b
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	f53c6778-187c-4a3f-9daa-9341e2b456a4
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	7a1b8849-5f9d-4d35-8cb6-5ee4fda8f0d6
5c16df41-3ef3-44ce-b780-6cf468514448	92a13545-d80c-4ac3-8af1-64130370d7f2
5c16df41-3ef3-44ce-b780-6cf468514448	405902a5-a3d0-4b38-bf4d-8a62f095e268
5c16df41-3ef3-44ce-b780-6cf468514448	e2128db3-0136-423d-a835-87624a304d0e
5c16df41-3ef3-44ce-b780-6cf468514448	be4ae770-a0ea-4df5-b595-bb8061ce3a24
5c16df41-3ef3-44ce-b780-6cf468514448	5ec10669-7257-4625-8dfa-7468df4f9807
5c16df41-3ef3-44ce-b780-6cf468514448	df572bb4-f5e4-46aa-93ef-fbb1aadf3925
5c16df41-3ef3-44ce-b780-6cf468514448	bdc26930-592e-4661-9e15-f10971903d82
5c16df41-3ef3-44ce-b780-6cf468514448	38260d7c-75a9-4830-8d61-428102e5deea
5c16df41-3ef3-44ce-b780-6cf468514448	46d33efc-4ae8-48be-9d37-77b3b2a8f2ce
5c16df41-3ef3-44ce-b780-6cf468514448	4581ce57-3d61-4b6e-b3bb-5436e3ccd4af
5c16df41-3ef3-44ce-b780-6cf468514448	45f1a383-44e2-4124-9544-4645999d0e35
5c16df41-3ef3-44ce-b780-6cf468514448	6a877d37-2636-42d1-be8d-69971808c8e3
5c16df41-3ef3-44ce-b780-6cf468514448	17a69293-5926-4eca-896f-bb0442ea1163
5c16df41-3ef3-44ce-b780-6cf468514448	64f9dee0-b959-4328-8042-a3b1191d1cb2
5c16df41-3ef3-44ce-b780-6cf468514448	51716dda-a093-4475-bafb-8a856208c0ee
5c16df41-3ef3-44ce-b780-6cf468514448	ed2eff50-cbfd-4548-91e4-f18ef447d91e
5c16df41-3ef3-44ce-b780-6cf468514448	6048e906-1eea-41aa-b646-0d99b5b5016d
5c16df41-3ef3-44ce-b780-6cf468514448	1525f00d-1c45-404e-aa44-67d943ad1f6b
5c16df41-3ef3-44ce-b780-6cf468514448	f53c6778-187c-4a3f-9daa-9341e2b456a4
5c16df41-3ef3-44ce-b780-6cf468514448	7a1b8849-5f9d-4d35-8cb6-5ee4fda8f0d6
03a28f49-3cdd-4d5a-a246-71996a171f43	92a13545-d80c-4ac3-8af1-64130370d7f2
03a28f49-3cdd-4d5a-a246-71996a171f43	405902a5-a3d0-4b38-bf4d-8a62f095e268
03a28f49-3cdd-4d5a-a246-71996a171f43	e2128db3-0136-423d-a835-87624a304d0e
03a28f49-3cdd-4d5a-a246-71996a171f43	be4ae770-a0ea-4df5-b595-bb8061ce3a24
03a28f49-3cdd-4d5a-a246-71996a171f43	5ec10669-7257-4625-8dfa-7468df4f9807
03a28f49-3cdd-4d5a-a246-71996a171f43	df572bb4-f5e4-46aa-93ef-fbb1aadf3925
03a28f49-3cdd-4d5a-a246-71996a171f43	bdc26930-592e-4661-9e15-f10971903d82
03a28f49-3cdd-4d5a-a246-71996a171f43	38260d7c-75a9-4830-8d61-428102e5deea
03a28f49-3cdd-4d5a-a246-71996a171f43	46d33efc-4ae8-48be-9d37-77b3b2a8f2ce
03a28f49-3cdd-4d5a-a246-71996a171f43	4581ce57-3d61-4b6e-b3bb-5436e3ccd4af
03a28f49-3cdd-4d5a-a246-71996a171f43	45f1a383-44e2-4124-9544-4645999d0e35
03a28f49-3cdd-4d5a-a246-71996a171f43	6a877d37-2636-42d1-be8d-69971808c8e3
03a28f49-3cdd-4d5a-a246-71996a171f43	17a69293-5926-4eca-896f-bb0442ea1163
03a28f49-3cdd-4d5a-a246-71996a171f43	64f9dee0-b959-4328-8042-a3b1191d1cb2
03a28f49-3cdd-4d5a-a246-71996a171f43	51716dda-a093-4475-bafb-8a856208c0ee
03a28f49-3cdd-4d5a-a246-71996a171f43	ed2eff50-cbfd-4548-91e4-f18ef447d91e
03a28f49-3cdd-4d5a-a246-71996a171f43	6048e906-1eea-41aa-b646-0d99b5b5016d
03a28f49-3cdd-4d5a-a246-71996a171f43	1525f00d-1c45-404e-aa44-67d943ad1f6b
03a28f49-3cdd-4d5a-a246-71996a171f43	f53c6778-187c-4a3f-9daa-9341e2b456a4
03a28f49-3cdd-4d5a-a246-71996a171f43	7a1b8849-5f9d-4d35-8cb6-5ee4fda8f0d6
771df88d-b94e-4174-b5a1-2ceccf1c9b05	92a13545-d80c-4ac3-8af1-64130370d7f2
771df88d-b94e-4174-b5a1-2ceccf1c9b05	405902a5-a3d0-4b38-bf4d-8a62f095e268
771df88d-b94e-4174-b5a1-2ceccf1c9b05	e2128db3-0136-423d-a835-87624a304d0e
771df88d-b94e-4174-b5a1-2ceccf1c9b05	be4ae770-a0ea-4df5-b595-bb8061ce3a24
771df88d-b94e-4174-b5a1-2ceccf1c9b05	5ec10669-7257-4625-8dfa-7468df4f9807
771df88d-b94e-4174-b5a1-2ceccf1c9b05	df572bb4-f5e4-46aa-93ef-fbb1aadf3925
771df88d-b94e-4174-b5a1-2ceccf1c9b05	bdc26930-592e-4661-9e15-f10971903d82
771df88d-b94e-4174-b5a1-2ceccf1c9b05	38260d7c-75a9-4830-8d61-428102e5deea
771df88d-b94e-4174-b5a1-2ceccf1c9b05	46d33efc-4ae8-48be-9d37-77b3b2a8f2ce
771df88d-b94e-4174-b5a1-2ceccf1c9b05	4581ce57-3d61-4b6e-b3bb-5436e3ccd4af
771df88d-b94e-4174-b5a1-2ceccf1c9b05	45f1a383-44e2-4124-9544-4645999d0e35
771df88d-b94e-4174-b5a1-2ceccf1c9b05	6a877d37-2636-42d1-be8d-69971808c8e3
771df88d-b94e-4174-b5a1-2ceccf1c9b05	17a69293-5926-4eca-896f-bb0442ea1163
771df88d-b94e-4174-b5a1-2ceccf1c9b05	64f9dee0-b959-4328-8042-a3b1191d1cb2
771df88d-b94e-4174-b5a1-2ceccf1c9b05	51716dda-a093-4475-bafb-8a856208c0ee
771df88d-b94e-4174-b5a1-2ceccf1c9b05	ed2eff50-cbfd-4548-91e4-f18ef447d91e
771df88d-b94e-4174-b5a1-2ceccf1c9b05	6048e906-1eea-41aa-b646-0d99b5b5016d
771df88d-b94e-4174-b5a1-2ceccf1c9b05	1525f00d-1c45-404e-aa44-67d943ad1f6b
771df88d-b94e-4174-b5a1-2ceccf1c9b05	f53c6778-187c-4a3f-9daa-9341e2b456a4
771df88d-b94e-4174-b5a1-2ceccf1c9b05	7a1b8849-5f9d-4d35-8cb6-5ee4fda8f0d6
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	92a13545-d80c-4ac3-8af1-64130370d7f2
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	405902a5-a3d0-4b38-bf4d-8a62f095e268
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	e2128db3-0136-423d-a835-87624a304d0e
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	be4ae770-a0ea-4df5-b595-bb8061ce3a24
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	5ec10669-7257-4625-8dfa-7468df4f9807
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	df572bb4-f5e4-46aa-93ef-fbb1aadf3925
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	bdc26930-592e-4661-9e15-f10971903d82
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	38260d7c-75a9-4830-8d61-428102e5deea
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	46d33efc-4ae8-48be-9d37-77b3b2a8f2ce
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	4581ce57-3d61-4b6e-b3bb-5436e3ccd4af
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	45f1a383-44e2-4124-9544-4645999d0e35
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	6a877d37-2636-42d1-be8d-69971808c8e3
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	17a69293-5926-4eca-896f-bb0442ea1163
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	64f9dee0-b959-4328-8042-a3b1191d1cb2
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	51716dda-a093-4475-bafb-8a856208c0ee
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	ed2eff50-cbfd-4548-91e4-f18ef447d91e
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	6048e906-1eea-41aa-b646-0d99b5b5016d
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	1525f00d-1c45-404e-aa44-67d943ad1f6b
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	f53c6778-187c-4a3f-9daa-9341e2b456a4
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	7a1b8849-5f9d-4d35-8cb6-5ee4fda8f0d6
570fec18-81bc-4524-80f5-79a4602aad34	92a13545-d80c-4ac3-8af1-64130370d7f2
570fec18-81bc-4524-80f5-79a4602aad34	405902a5-a3d0-4b38-bf4d-8a62f095e268
570fec18-81bc-4524-80f5-79a4602aad34	e2128db3-0136-423d-a835-87624a304d0e
570fec18-81bc-4524-80f5-79a4602aad34	be4ae770-a0ea-4df5-b595-bb8061ce3a24
570fec18-81bc-4524-80f5-79a4602aad34	5ec10669-7257-4625-8dfa-7468df4f9807
570fec18-81bc-4524-80f5-79a4602aad34	df572bb4-f5e4-46aa-93ef-fbb1aadf3925
570fec18-81bc-4524-80f5-79a4602aad34	bdc26930-592e-4661-9e15-f10971903d82
570fec18-81bc-4524-80f5-79a4602aad34	38260d7c-75a9-4830-8d61-428102e5deea
570fec18-81bc-4524-80f5-79a4602aad34	46d33efc-4ae8-48be-9d37-77b3b2a8f2ce
570fec18-81bc-4524-80f5-79a4602aad34	4581ce57-3d61-4b6e-b3bb-5436e3ccd4af
570fec18-81bc-4524-80f5-79a4602aad34	45f1a383-44e2-4124-9544-4645999d0e35
570fec18-81bc-4524-80f5-79a4602aad34	6a877d37-2636-42d1-be8d-69971808c8e3
570fec18-81bc-4524-80f5-79a4602aad34	17a69293-5926-4eca-896f-bb0442ea1163
570fec18-81bc-4524-80f5-79a4602aad34	64f9dee0-b959-4328-8042-a3b1191d1cb2
570fec18-81bc-4524-80f5-79a4602aad34	51716dda-a093-4475-bafb-8a856208c0ee
570fec18-81bc-4524-80f5-79a4602aad34	ed2eff50-cbfd-4548-91e4-f18ef447d91e
570fec18-81bc-4524-80f5-79a4602aad34	6048e906-1eea-41aa-b646-0d99b5b5016d
570fec18-81bc-4524-80f5-79a4602aad34	1525f00d-1c45-404e-aa44-67d943ad1f6b
570fec18-81bc-4524-80f5-79a4602aad34	f53c6778-187c-4a3f-9daa-9341e2b456a4
570fec18-81bc-4524-80f5-79a4602aad34	7a1b8849-5f9d-4d35-8cb6-5ee4fda8f0d6
570fec18-81bc-4524-80f5-79a4602aad34	c06625ab-a067-4739-89d3-3947b1f3813c
570fec18-81bc-4524-80f5-79a4602aad34	fdcc12dc-33dd-48e1-9bfa-5865576a027d
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	80f66865-cf8d-4323-b59a-2942d51c7924
5c16df41-3ef3-44ce-b780-6cf468514448	80f66865-cf8d-4323-b59a-2942d51c7924
03a28f49-3cdd-4d5a-a246-71996a171f43	80f66865-cf8d-4323-b59a-2942d51c7924
771df88d-b94e-4174-b5a1-2ceccf1c9b05	80f66865-cf8d-4323-b59a-2942d51c7924
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	80f66865-cf8d-4323-b59a-2942d51c7924
570fec18-81bc-4524-80f5-79a4602aad34	80f66865-cf8d-4323-b59a-2942d51c7924
570fec18-81bc-4524-80f5-79a4602aad34	56436965-8177-4657-a6cd-e17355a40260
570fec18-81bc-4524-80f5-79a4602aad34	e35441dc-a7d1-4c99-9bf5-cb92b4a70b92
570fec18-81bc-4524-80f5-79a4602aad34	42519cb8-490b-470b-b859-25d182f5c30a
570fec18-81bc-4524-80f5-79a4602aad34	bae6fa75-8874-4e57-8c7f-4382215645f5
570fec18-81bc-4524-80f5-79a4602aad34	9bd33b25-9d4c-4adc-843b-fb9c26da0885
570fec18-81bc-4524-80f5-79a4602aad34	87ce30d9-c3cb-477c-8be6-eb307b1f1eaf
570fec18-81bc-4524-80f5-79a4602aad34	bd2de790-505b-4ed1-b320-3f538b84d2e0
570fec18-81bc-4524-80f5-79a4602aad34	b3f739a5-f5e2-4d78-adbe-e3b826caec53
570fec18-81bc-4524-80f5-79a4602aad34	9adfb725-a116-4ca7-a5f0-a0c771b4eec1
570fec18-81bc-4524-80f5-79a4602aad34	b22607b9-f8d3-46e1-808b-3380550dec62
570fec18-81bc-4524-80f5-79a4602aad34	c477908c-e0db-4a0d-a017-97bc60b04320
570fec18-81bc-4524-80f5-79a4602aad34	71782cec-d292-4721-aa42-e1105d368f93
570fec18-81bc-4524-80f5-79a4602aad34	a62f7639-6ef9-424f-ac7c-830a0c8386c9
570fec18-81bc-4524-80f5-79a4602aad34	971c0c4e-f91c-422b-86e2-711d8631cada
570fec18-81bc-4524-80f5-79a4602aad34	be7bad90-ff78-4cfc-b5f0-1a89ef3156a8
570fec18-81bc-4524-80f5-79a4602aad34	a6ac77a0-0ae7-4acd-97b1-a471d5023dd6
570fec18-81bc-4524-80f5-79a4602aad34	9b84a900-6a9a-4c61-b416-37c559fe9d3f
570fec18-81bc-4524-80f5-79a4602aad34	c4f4429e-8ab6-49a9-89e8-be44aea06360
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	56436965-8177-4657-a6cd-e17355a40260
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	e35441dc-a7d1-4c99-9bf5-cb92b4a70b92
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	42519cb8-490b-470b-b859-25d182f5c30a
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	bae6fa75-8874-4e57-8c7f-4382215645f5
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	9bd33b25-9d4c-4adc-843b-fb9c26da0885
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	87ce30d9-c3cb-477c-8be6-eb307b1f1eaf
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	bd2de790-505b-4ed1-b320-3f538b84d2e0
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	b3f739a5-f5e2-4d78-adbe-e3b826caec53
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	9adfb725-a116-4ca7-a5f0-a0c771b4eec1
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	b22607b9-f8d3-46e1-808b-3380550dec62
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	c477908c-e0db-4a0d-a017-97bc60b04320
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	71782cec-d292-4721-aa42-e1105d368f93
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	a62f7639-6ef9-424f-ac7c-830a0c8386c9
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	971c0c4e-f91c-422b-86e2-711d8631cada
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	be7bad90-ff78-4cfc-b5f0-1a89ef3156a8
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	a6ac77a0-0ae7-4acd-97b1-a471d5023dd6
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	56436965-8177-4657-a6cd-e17355a40260
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	e35441dc-a7d1-4c99-9bf5-cb92b4a70b92
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	9bd33b25-9d4c-4adc-843b-fb9c26da0885
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	87ce30d9-c3cb-477c-8be6-eb307b1f1eaf
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	bd2de790-505b-4ed1-b320-3f538b84d2e0
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	b3f739a5-f5e2-4d78-adbe-e3b826caec53
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	9adfb725-a116-4ca7-a5f0-a0c771b4eec1
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	b22607b9-f8d3-46e1-808b-3380550dec62
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	c477908c-e0db-4a0d-a017-97bc60b04320
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	71782cec-d292-4721-aa42-e1105d368f93
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	a62f7639-6ef9-424f-ac7c-830a0c8386c9
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	971c0c4e-f91c-422b-86e2-711d8631cada
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	a6ac77a0-0ae7-4acd-97b1-a471d5023dd6
03a28f49-3cdd-4d5a-a246-71996a171f43	56436965-8177-4657-a6cd-e17355a40260
03a28f49-3cdd-4d5a-a246-71996a171f43	e35441dc-a7d1-4c99-9bf5-cb92b4a70b92
03a28f49-3cdd-4d5a-a246-71996a171f43	9bd33b25-9d4c-4adc-843b-fb9c26da0885
03a28f49-3cdd-4d5a-a246-71996a171f43	87ce30d9-c3cb-477c-8be6-eb307b1f1eaf
03a28f49-3cdd-4d5a-a246-71996a171f43	b3f739a5-f5e2-4d78-adbe-e3b826caec53
03a28f49-3cdd-4d5a-a246-71996a171f43	9adfb725-a116-4ca7-a5f0-a0c771b4eec1
03a28f49-3cdd-4d5a-a246-71996a171f43	b22607b9-f8d3-46e1-808b-3380550dec62
03a28f49-3cdd-4d5a-a246-71996a171f43	71782cec-d292-4721-aa42-e1105d368f93
03a28f49-3cdd-4d5a-a246-71996a171f43	971c0c4e-f91c-422b-86e2-711d8631cada
03a28f49-3cdd-4d5a-a246-71996a171f43	a6ac77a0-0ae7-4acd-97b1-a471d5023dd6
5c16df41-3ef3-44ce-b780-6cf468514448	56436965-8177-4657-a6cd-e17355a40260
5c16df41-3ef3-44ce-b780-6cf468514448	e35441dc-a7d1-4c99-9bf5-cb92b4a70b92
5c16df41-3ef3-44ce-b780-6cf468514448	9bd33b25-9d4c-4adc-843b-fb9c26da0885
5c16df41-3ef3-44ce-b780-6cf468514448	87ce30d9-c3cb-477c-8be6-eb307b1f1eaf
5c16df41-3ef3-44ce-b780-6cf468514448	9adfb725-a116-4ca7-a5f0-a0c771b4eec1
5c16df41-3ef3-44ce-b780-6cf468514448	b22607b9-f8d3-46e1-808b-3380550dec62
5c16df41-3ef3-44ce-b780-6cf468514448	971c0c4e-f91c-422b-86e2-711d8631cada
5c16df41-3ef3-44ce-b780-6cf468514448	a6ac77a0-0ae7-4acd-97b1-a471d5023dd6
771df88d-b94e-4174-b5a1-2ceccf1c9b05	56436965-8177-4657-a6cd-e17355a40260
771df88d-b94e-4174-b5a1-2ceccf1c9b05	e35441dc-a7d1-4c99-9bf5-cb92b4a70b92
771df88d-b94e-4174-b5a1-2ceccf1c9b05	9bd33b25-9d4c-4adc-843b-fb9c26da0885
771df88d-b94e-4174-b5a1-2ceccf1c9b05	87ce30d9-c3cb-477c-8be6-eb307b1f1eaf
771df88d-b94e-4174-b5a1-2ceccf1c9b05	9adfb725-a116-4ca7-a5f0-a0c771b4eec1
771df88d-b94e-4174-b5a1-2ceccf1c9b05	71782cec-d292-4721-aa42-e1105d368f93
771df88d-b94e-4174-b5a1-2ceccf1c9b05	a62f7639-6ef9-424f-ac7c-830a0c8386c9
771df88d-b94e-4174-b5a1-2ceccf1c9b05	971c0c4e-f91c-422b-86e2-711d8631cada
771df88d-b94e-4174-b5a1-2ceccf1c9b05	a6ac77a0-0ae7-4acd-97b1-a471d5023dd6
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, created_at, is_accountant, is_default) FROM stdin;
ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	admin	Gym administrator	2026-08-15 18:56:56.31849+05:30	f	f
5c16df41-3ef3-44ce-b780-6cf468514448	trainer	Gym trainer	2026-08-15 18:56:56.31849+05:30	f	f
03a28f49-3cdd-4d5a-a246-71996a171f43	front-desk	Front desk staff	2026-08-15 18:56:56.31849+05:30	f	f
771df88d-b94e-4174-b5a1-2ceccf1c9b05	accountant	Gym accountant	2026-08-15 18:56:56.31849+05:30	f	f
7c1df70d-e7c7-4723-a0a7-c6296ceb7366	super-admin	System administrator	2026-08-15 18:56:56.31849+05:30	f	f
570fec18-81bc-4524-80f5-79a4602aad34	system-admin	System Admin (Jp)	2026-09-07 20:45:03.538195+05:30	f	f
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, gym_id, key, value, updated_at) FROM stdin;
b808b91b-c999-47b4-b39f-7750e7c29fe4	\N	role_granular_permissions	{"admin":{"members:view":true,"members:add":true,"members:edit":true,"members:delete":true,"members:duplicate":true,"members:import":true,"members:export":true,"members:hold_fees":true,"staff:view":true,"staff:add":true,"staff:edit":true,"staff:delete":true,"staff:assign":true,"attendance:view":true,"attendance:checkin":true,"attendance:bulk":true,"attendance:biometric":true,"payments:view":true,"payments:collect":true,"payments:discount":true,"payments:refund":true,"payments:delete":true,"plans:view":true,"plans:create":true,"plans:edit":true,"plans:delete":true,"leads:view":true,"leads:add":true,"leads:edit":true,"leads:convert":true,"leads:delete":true,"ai:view":true,"ai:generate_workout":true,"ai:generate_diet":true,"ai:edit":true,"settings:general":true,"settings:modules":true,"settings:permissions":true},"front-desk":{"members:view":true,"members:add":true,"members:edit":true,"members:delete":false,"members:duplicate":true,"members:import":false,"members:export":true,"members:hold_fees":true,"staff:view":true,"staff:add":false,"staff:edit":false,"staff:delete":false,"staff:assign":false,"attendance:view":true,"attendance:checkin":true,"attendance:bulk":true,"attendance:biometric":false,"payments:view":true,"payments:collect":true,"payments:discount":false,"payments:refund":false,"payments:delete":false,"plans:view":true,"plans:create":false,"plans:edit":false,"plans:delete":false,"leads:view":true,"leads:add":true,"leads:edit":true,"leads:convert":true,"leads:delete":false,"ai:view":false,"ai:generate_workout":false,"ai:generate_diet":false,"ai:edit":false,"settings:general":false,"settings:modules":false,"settings:permissions":false},"trainer":{"members:view":true,"members:add":false,"members:edit":false,"members:delete":false,"members:duplicate":false,"members:import":false,"members:export":false,"members:hold_fees":false,"staff:view":true,"staff:add":false,"staff:edit":false,"staff:delete":false,"staff:assign":false,"attendance:view":true,"attendance:checkin":true,"attendance:bulk":false,"attendance:biometric":false,"payments:view":false,"payments:collect":false,"payments:discount":false,"payments:refund":false,"payments:delete":false,"plans:view":true,"plans:create":false,"plans:edit":false,"plans:delete":false,"leads:view":false,"leads:add":false,"leads:edit":false,"leads:convert":false,"leads:delete":false,"ai:view":true,"ai:generate_workout":true,"ai:generate_diet":true,"ai:edit":true,"settings:general":false,"settings:modules":false,"settings:permissions":false},"accountant":{"members:view":true,"members:add":false,"members:edit":false,"members:delete":false,"members:duplicate":false,"members:import":false,"members:export":true,"members:hold_fees":true,"staff:view":true,"staff:add":false,"staff:edit":false,"staff:delete":false,"staff:assign":false,"attendance:view":false,"attendance:checkin":false,"attendance:bulk":false,"attendance:biometric":false,"payments:view":true,"payments:collect":true,"payments:discount":true,"payments:refund":true,"payments:delete":true,"plans:view":true,"plans:create":false,"plans:edit":false,"plans:delete":false,"leads:view":false,"leads:add":false,"leads:edit":false,"leads:convert":false,"leads:delete":false,"ai:view":false,"ai:generate_workout":false,"ai:generate_diet":false,"ai:edit":false,"settings:general":false,"settings:modules":false,"settings:permissions":false},"super-admin":{"members:view":true,"members:add":true,"members:edit":true,"members:delete":true,"members:duplicate":true,"members:import":true,"members:export":true,"members:hold_fees":true,"staff:view":true,"staff:add":true,"staff:edit":true,"staff:delete":true,"staff:assign":true,"attendance:view":true,"attendance:checkin":true,"attendance:bulk":true,"attendance:biometric":true,"payments:view":true,"payments:collect":true,"payments:discount":true,"payments:refund":true,"payments:delete":true,"plans:view":true,"plans:create":true,"plans:edit":true,"plans:delete":true,"leads:view":true,"leads:add":true,"leads:edit":true,"leads:convert":true,"leads:delete":true,"ai:view":true,"ai:generate_workout":true,"ai:generate_diet":true,"ai:edit":true,"settings:general":true,"settings:modules":true,"settings:permissions":true},"system-admin":{"members:view":true,"members:add":true,"members:edit":true,"members:delete":true,"members:duplicate":true,"members:import":true,"members:export":true,"members:hold_fees":true,"staff:view":true,"staff:add":true,"staff:edit":true,"staff:delete":true,"staff:assign":true,"attendance:view":true,"attendance:checkin":true,"attendance:bulk":true,"attendance:biometric":true,"payments:view":true,"payments:collect":true,"payments:discount":true,"payments:refund":true,"payments:delete":true,"plans:view":true,"plans:create":true,"plans:edit":true,"plans:delete":true,"leads:view":true,"leads:add":true,"leads:edit":true,"leads:convert":true,"leads:delete":true,"ai:view":true,"ai:generate_workout":true,"ai:generate_diet":true,"ai:edit":true,"settings:general":true,"settings:modules":true,"settings:permissions":true}}	2026-10-25 11:40:42.441071+05:30
0cec4370-12d2-4a0f-8483-10cad89d786d	\N	gym_modules_config	[{"id":"members","name":"Members","path":"/members","category":"MODULE SETTINGS","description":"Member registration, profile details, memberships & status","is_enabled":true},{"id":"staff","name":"Staff & Trainers","path":"/staff","category":"MODULE SETTINGS","description":"Employee directory, trainers, designations & roles","is_enabled":true},{"id":"attendance","name":"Attendance & Access","path":"/attendance","category":"MODULE SETTINGS","description":"Check-in logs, biometric turnstiles, QR scans & bulk attendance","is_enabled":true},{"id":"payments","name":"Payments & Billing","path":"/payments","category":"MODULE SETTINGS","description":"Fee collections, receipts, invoice generation & refunds","is_enabled":true},{"id":"membership_plans","name":"Membership Plans","path":"/membership-plans","category":"MODULE SETTINGS","description":"Packages, tiers, validity duration, pricing & renewal policies","is_enabled":true},{"id":"leads_crm","name":"Leads / CRM","path":"/leads-crm","category":"MODULE SETTINGS","description":"Visitor inquiries, prospect pipeline & follow-up calls","is_enabled":true},{"id":"workout_diet_ai","name":"Workout / Diet AI","path":"/workout-diet_ai","category":"MODULE SETTINGS","description":"AI generated workout splits & customized diet plans","is_enabled":true},{"id":"equipment","name":"Equipment & Maintenance","path":"/equipment","category":"MODULE SETTINGS","description":"Gym machine assets, warranty & maintenance records","is_enabled":true},{"id":"expenses","name":"Expenses Tracker","path":"/expenses","category":"MODULE SETTINGS","description":"Gym overheads, utility bills, rent & inventory expenses","is_enabled":true}]	2026-10-25 11:40:42.457363+05:30
71a5c1ca-6065-42df-8ee8-260c0b175a1f	\N	master_plan_sidebar_visibility	true	2026-10-27 23:06:00.664085+05:30
5c2668f7-fe5a-4873-af37-4f86a19d4402	\N	master_quick_navigation	true	2026-10-27 23:06:00.718928+05:30
3859330b-db4c-4951-896b-c4e367bfdbc8	\N	master_dark_theme	true	2026-10-27 23:06:00.727585+05:30
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff (id, branch_id, user_id, role_id, full_name, email, phone, designation, salary, joining_date, is_active, created_at, updated_at) FROM stdin;
5092945f-b4a0-4535-acb0-62ad83498f95	38af11b9-0eff-41b0-9cac-a40a74fb31cf	\N	\N	TEST	\N	8989898989	\N	200000.00	2026-10-08	t	2026-10-23 23:16:21.347913+05:30	2026-10-23 23:16:21.347913+05:30
fa9d7b70-4277-4ae9-ac74-49231ae876c0	630b3844-e660-45a5-bdbc-abc8c0f19802	\N	\N	Test Trainer Gym B	\N	9127318510	Trainer	\N	\N	t	2026-11-01 16:31:46.255869+05:30	2026-11-01 16:31:46.255869+05:30
3cf8ab7a-cfae-44a9-bdf6-fb6ff14f99d7	2b0c6048-dbf6-4dae-b831-48111246603e	\N	\N	Test Trainer Alpha Renamed	\N	9127318510	Fitness Trainer	\N	\N	t	2026-11-01 16:31:46.220896+05:30	2026-11-01 16:31:46.271642+05:30
cead16e9-1ecb-44e3-bcc3-c010659c5bc1	de39de91-f4e1-4ac4-b856-aa8025115452	931ebcb7-60e6-4e1e-9a7b-3113bd1cce5a	5c16df41-3ef3-44ce-b780-6cf468514448	Test Trainer 754135	trainer_754135@test.com	9875413510	Certified Personal Trainer	35000.00	2026-01-15	t	2026-11-16 23:59:14.595563+05:30	2026-11-16 23:59:14.595563+05:30
c4b9cec5-6ebf-4800-b746-ea2f0f2b619c	de39de91-f4e1-4ac4-b856-aa8025115452	69aa7e5b-de7f-41c2-b2d9-d8f23811d5dd	03a28f49-3cdd-4d5a-a246-71996a171f43	Test FrontDesk 754135	frontdesk_754135@test.com	9875413520	Front Desk Executive	25000.00	\N	t	2026-11-16 23:59:15.244695+05:30	2026-11-16 23:59:15.244695+05:30
d6579c6b-bde7-47ab-9be0-1d298120e3d6	de39de91-f4e1-4ac4-b856-aa8025115452	3f4b4460-9999-4110-9249-a7dec2c8b592	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	Test Admin 754135	adminstaff_754135@test.com	9875413530	Branch Manager	50000.00	\N	t	2026-11-16 23:59:15.609212+05:30	2026-11-16 23:59:15.609212+05:30
e18d368d-d42b-462d-b648-f46554a80291	de39de91-f4e1-4ac4-b856-aa8025115452	7161afd7-861b-4c96-a6d5-09986bd831d3	5c16df41-3ef3-44ce-b780-6cf468514448	Test Trainer 888549	trainer_888549@test.com	9888854910	Certified Personal Trainer	35000.00	2026-01-15	t	2026-11-17 00:01:28.983425+05:30	2026-11-17 00:01:28.983425+05:30
8c552d2f-1bbc-471d-ae1b-2a45cfc80e85	de39de91-f4e1-4ac4-b856-aa8025115452	bfff80aa-0ce9-48a6-b4a3-fcdd78741507	03a28f49-3cdd-4d5a-a246-71996a171f43	Test FrontDesk 888549	frontdesk_888549@test.com	9888854920	Front Desk Executive	25000.00	\N	t	2026-11-17 00:01:29.613924+05:30	2026-11-17 00:01:29.613924+05:30
cc117cca-1363-4aaf-80e4-0e43524a4758	de39de91-f4e1-4ac4-b856-aa8025115452	752028ab-ec9f-4376-94eb-b3bc8348eff7	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	Test Admin 888549	adminstaff_888549@test.com	9888854930	Branch Manager	50000.00	\N	t	2026-11-17 00:01:29.959361+05:30	2026-11-17 00:01:29.959361+05:30
f1fc3504-8176-4a4d-b9a8-d19c2220a49a	de39de91-f4e1-4ac4-b856-aa8025115452	d502ffff-10d9-4402-a660-fe0e30f034fc	5c16df41-3ef3-44ce-b780-6cf468514448	Test Trainer 902455	trainer_902455@test.com	9890245510	Certified Personal Trainer	35000.00	2026-01-15	t	2026-11-17 00:01:42.776962+05:30	2026-11-17 00:01:42.776962+05:30
9911c2ed-5071-4d24-b475-7f282010f9d3	de39de91-f4e1-4ac4-b856-aa8025115452	946a2d3e-351c-4834-acb3-e92dcf8ab84f	03a28f49-3cdd-4d5a-a246-71996a171f43	Test FrontDesk 902455	frontdesk_902455@test.com	9890245520	Front Desk Executive	25000.00	\N	t	2026-11-17 00:01:43.323069+05:30	2026-11-17 00:01:43.323069+05:30
939957ac-cf3e-4bba-8678-2fd149aefa45	de39de91-f4e1-4ac4-b856-aa8025115452	a6310a0f-5c7c-4474-89ea-58b07556858f	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	Test Admin 902455	adminstaff_902455@test.com	9890245530	Branch Manager	50000.00	\N	t	2026-11-17 00:01:43.659217+05:30	2026-11-17 00:01:43.659217+05:30
590c8d1a-f860-4e70-b62c-a65bfe26b43e	de39de91-f4e1-4ac4-b856-aa8025115452	517629c8-4948-47c2-a999-4fd37798f842	5c16df41-3ef3-44ce-b780-6cf468514448	Test Trainer 746994	trainer_746994@test.com	9874699410	Certified Personal Trainer	35000.00	2026-01-15	t	2026-11-17 08:19:07.643954+05:30	2026-11-17 08:19:07.643954+05:30
68b0a49d-9149-45cc-96c3-73281b36efc5	de39de91-f4e1-4ac4-b856-aa8025115452	26309d4c-a1a8-49be-8524-945a89a6dcf1	03a28f49-3cdd-4d5a-a246-71996a171f43	Test FrontDesk 746994	frontdesk_746994@test.com	9874699420	Front Desk Executive	25000.00	\N	t	2026-11-17 08:19:08.603135+05:30	2026-11-17 08:19:08.603135+05:30
74a5ebbd-2b4f-46f4-87c3-0201e3ee2ebe	de39de91-f4e1-4ac4-b856-aa8025115452	5081816c-56c1-4455-ba0b-d2f31ed580e5	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	Test Admin 746994	adminstaff_746994@test.com	9874699430	Branch Manager	50000.00	\N	t	2026-11-17 08:19:08.946912+05:30	2026-11-17 08:19:08.946912+05:30
\.


--
-- Data for Name: staff_attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_attendance (id, staff_id, branch_id, check_in, check_out, marked_by, created_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, gym_id, billing_plan_id, status, trial_ends_at, current_period_start, current_period_end, cancelled_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, role_id, email, password_hash, full_name, phone, is_active, refresh_token, last_login, created_at, updated_at, gym_id, branch_id) FROM stdin;
517629c8-4948-47c2-a999-4fd37798f842	5c16df41-3ef3-44ce-b780-6cf468514448	trainer_746994@test.com	$2b$10$IGlQH5SDmQTYxH2qM74foetkof/wKCSYzOrOZbu51.46rviu.oZNu	Test Trainer 746994	9874699410	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI1MTc2MjljOC00OTQ4LTQ3YzItYTk5OS00ZmQzNzc5OGY4NDIiLCJqdGkiOiJmNzU5MjZmMS1iMmRiLTQwOTktODg5MC0wMWI0YzRlY2QxZmEiLCJpYXQiOjE3OTQ4ODM3NDgsImV4cCI6MTc5NTQ4ODU0OH0.yAgWzIauK_81K7rTqAF_8eWak-K6DYSAsHhFG8AgaPU	2026-11-17 08:19:08.577839+05:30	2026-11-17 08:19:07.643954+05:30	2026-11-17 08:19:08.577839+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
26309d4c-a1a8-49be-8524-945a89a6dcf1	03a28f49-3cdd-4d5a-a246-71996a171f43	frontdesk_746994@test.com	$2b$10$BDRV08.BDswDo29BZlujQejUCT.xB1iF.2BIfhAUyrbz/4cyyW9hC	Test FrontDesk 746994	9874699420	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIyNjMwOWQ0Yy1hMWE4LTQ5YmUtODUyNC05NDVhODlhNmRjZjEiLCJqdGkiOiI2YWQ3Njc3NS04YmM4LTQ2YWMtODI5Mi0wM2I3N2E2Yzg4NjciLCJpYXQiOjE3OTQ4ODM3NDgsImV4cCI6MTc5NTQ4ODU0OH0.nBKD6m_dLfsstuSG1YAt5G7zjCyziuXYzfLjV637oks	2026-11-17 08:19:08.928364+05:30	2026-11-17 08:19:08.603135+05:30	2026-11-17 08:19:08.928364+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
5081816c-56c1-4455-ba0b-d2f31ed580e5	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	adminstaff_746994@test.com	$2b$10$VjxnzRJWaf6G1xfrHfH74O9K5zgcA/F1yeMpQ.vAHBLUYi8p4zNc.	Test Admin 746994	9874699430	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI1MDgxODE2Yy01NmMxLTQ0NTUtYmEwYi1kMmYzMWVkNTgwZTUiLCJqdGkiOiIwOTNiYzMyZS0zYzYwLTQ4ZDktOTc1OC01Mjc5YjVjZDlkMDUiLCJpYXQiOjE3OTQ4ODM3NDksImV4cCI6MTc5NTQ4ODU0OX0.LpHs7XjrV3O3BXnPaWImvJANfqFpyfx1YrboBJCvIEM	2026-11-17 08:19:09.27338+05:30	2026-11-17 08:19:08.946912+05:30	2026-11-17 08:19:09.27338+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
8efaa0ca-53ad-4c87-b8cb-58a7f42d520e	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	prompt4_sa_b@fitzone.com	dummyhash	Super Admin Gym B	9999999999	t	\N	\N	2026-11-01 16:28:41.275623+05:30	2026-11-01 16:28:41.275623+05:30	4e440296-d558-46e6-b0f6-5fad5910a8f3	\N
ae62c035-cc87-4398-b1bf-aab6a6aecd2c	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5admin1b@test.com	dummyhash	D5 Branch Admin 1B	9876550008	t	\N	\N	2026-11-01 21:11:53.606797+05:30	2026-11-01 21:11:53.606797+05:30	2a5efdd1-aebf-4f3a-93de-fe673d727a55	0f965952-0b37-4401-aa79-87b7e9ba982b
31b9d813-23a0-4772-b379-649a72485fa9	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5owner_7211@gym.com	mockhash	D5 Bulk Owner	988867211	t	\N	\N	2026-11-01 21:43:55.49008+05:30	2026-11-01 21:43:55.49008+05:30	a7210f47-0738-4176-981e-d1c2a50d4438	\N
6f722507-98f3-4df9-b4ad-974a39c5224f	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5owner_3855@gym.com	mockhash	D5 Bulk Owner	988863855	t	\N	\N	2026-11-01 21:49:25.907107+05:30	2026-11-01 21:49:25.907107+05:30	07181c9d-8f25-42c9-a2ee-8fb959a5a373	\N
50190e32-106f-46ce-946d-99e61710ecb9	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	admin_3064@test.com	hash	Admin User 3064	\N	t	\N	\N	2026-11-01 22:31:09.560993+05:30	2026-11-01 22:31:09.560993+05:30	6d71e87e-fe3b-40fd-b188-f21940823d36	a42dc809-9669-4543-9208-6b4f4b1fd9b2
fd1e2eba-8f12-4eb9-a8a3-ff37f9f200da	03a28f49-3cdd-4d5a-a246-71996a171f43	fd_3064@test.com	hash	Front Desk 3064	\N	t	\N	\N	2026-11-01 22:31:09.575605+05:30	2026-11-01 22:31:09.575605+05:30	6d71e87e-fe3b-40fd-b188-f21940823d36	a42dc809-9669-4543-9208-6b4f4b1fd9b2
6409f72b-35a2-4502-96f7-1a04672e04ca	5c16df41-3ef3-44ce-b780-6cf468514448	trainer_3064@test.com	hash	Trainer 3064	\N	t	\N	\N	2026-11-01 22:31:09.578745+05:30	2026-11-01 22:31:09.578745+05:30	6d71e87e-fe3b-40fd-b188-f21940823d36	a42dc809-9669-4543-9208-6b4f4b1fd9b2
4f8e7551-283c-473a-b207-7dff7bd9f6a3	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	prompt4_sa_a@fitzone.com	$2b$10$BEqX2qDY.coWhtK5YJgHrOI.U1ENpXMCwZCYSCFKcRUfJSYiF9osC	Super Admin Gym A	9999999999	t	\N	\N	2026-11-01 16:28:41.225795+05:30	2026-11-01 16:28:41.225795+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N
a5a965ea-ea9d-4752-8882-7385b61f1dbc	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	prompt5_sa@fitzone.com	dummyhash	Super Admin Prompt 5	9999999999	t	\N	\N	2026-11-01 17:02:29.181502+05:30	2026-11-01 17:02:29.181502+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N
c979ce6f-4e70-4d21-8cd8-f3863fb7c25e	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5p2admin1@test.com	dummyhash	D5 P2 Admin	9876560005	t	\N	\N	2026-11-01 21:19:09.01765+05:30	2026-11-01 21:19:09.01765+05:30	8c35c396-7f04-4802-9ed5-ecc4c12dc81b	5b667fea-b783-49d0-a8e3-e85be41f5943
0290b0c4-be9b-4a04-ab54-287e827d8716	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5p2admin2@test.com	dummyhash	D5 P2 Other Admin	9876560006	t	\N	\N	2026-11-01 21:19:09.06888+05:30	2026-11-01 21:19:09.06888+05:30	35fc5264-607e-4663-a79b-03a756984e78	dacc9432-e01e-4120-8f8a-780741558570
8ab10f2e-73aa-4ab6-9752-661397527f20	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5owner_5826@gym.com	mockhash	D5 Bulk Owner	988865826	t	\N	\N	2026-11-01 21:44:35.35925+05:30	2026-11-01 21:44:35.35925+05:30	f666a106-2ccf-4682-8941-2949c3230de2	\N
effce214-fa1d-441c-a8f1-854cf73e0e28	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5owner_8852@gym.com	mockhash	D5 Bulk Owner	988868852	t	\N	\N	2026-11-01 22:08:27.13609+05:30	2026-11-01 22:08:27.13609+05:30	bb849e64-96a4-4091-997d-c52fbff6ed8b	\N
50f42085-e15d-4d84-a5a3-df250e7f21a1	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	admin_5823@test.com	hash	Admin User 5823	\N	t	\N	\N	2026-11-01 22:32:09.961018+05:30	2026-11-01 22:32:09.961018+05:30	387c4c43-b141-42f8-a901-3ae257c169d0	16267042-be5e-4cce-be54-53001b0cefdf
c0110ee1-d5ae-4589-b273-d5528c61eaf3	03a28f49-3cdd-4d5a-a246-71996a171f43	fd_5823@test.com	hash	Front Desk 5823	\N	t	\N	\N	2026-11-01 22:32:09.975356+05:30	2026-11-01 22:32:09.975356+05:30	387c4c43-b141-42f8-a901-3ae257c169d0	16267042-be5e-4cce-be54-53001b0cefdf
9680cc2a-8549-4f01-b23a-13f7e3d633e4	5c16df41-3ef3-44ce-b780-6cf468514448	trainer_5823@test.com	hash	Trainer 5823	\N	t	\N	\N	2026-11-01 22:32:09.97804+05:30	2026-11-01 22:32:09.97804+05:30	387c4c43-b141-42f8-a901-3ae257c169d0	16267042-be5e-4cce-be54-53001b0cefdf
816b5b3c-88bc-427a-a405-44b2770a6bc7	771df88d-b94e-4174-b5a1-2ceccf1c9b05	test.acc.1794884810147@fitzone.com	hash	Test Accountant	\N	t	\N	\N	2026-11-17 08:36:50.148791+05:30	2026-11-17 08:36:50.148791+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
16b698d3-8127-48cd-aebc-5803e3d4a812	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	p4user1@test.com	dummyhash	P4 SuperAdmin 1	\N	t	\N	\N	2026-11-01 18:05:19.032019+05:30	2026-11-01 18:05:19.032019+05:30	e85928f5-e06d-4663-84ba-697347816efb	5a487df0-199b-4b34-b88e-c83dac808811
43f1dfa9-e1a0-4a2f-b1f7-357a1c50baf5	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	p4user2@test.com	dummyhash	P4 SuperAdmin 2	\N	t	\N	\N	2026-11-01 18:05:19.064213+05:30	2026-11-01 18:05:19.064213+05:30	e52d93f7-cb46-4285-bec1-ff2016ccc39c	74582c4a-396e-4b56-8b86-b382d6769c85
0179ffe6-1dd0-4e6e-8108-1ddaf4c72177	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5p3admin2@test.com	dummyhash	D5 P3 Admin 2	9876570007	t	\N	\N	2026-11-01 21:29:28.475859+05:30	2026-11-01 21:29:28.475859+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
8bf7fc70-da59-4839-85a0-661bf6c95431	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5owner_5660@gym.com	mockhash	D5 Bulk Owner	988865660	t	\N	\N	2026-11-01 21:44:55.647197+05:30	2026-11-01 21:44:55.647197+05:30	c0452148-dc36-40d0-92bb-1d9870fe0d15	\N
6168be6b-2f29-4cd3-b99c-c4b5dcea828c	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5p3admin1@test.com	dummyhash	D5 P3 Admin 1	9876570006	t	\N	\N	2026-11-01 21:29:28.315098+05:30	2026-11-01 21:29:28.315098+05:30	04bb63ce-3328-4b25-bc4e-8ad57614e2f8	\N
4fff2db5-5363-43f2-9b02-79af9cb3daca	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	naveenprakash178@gmail.com	$2b$10$4eN9nE2vQsfKpZjnIC0eW.OXi9ieez4oZu5YYlwFF9RxSC/D7wx.S	Naveen	9500977245	t	\N	2026-10-31 23:22:51.605661+05:30	2026-10-11 11:28:23.301537+05:30	2026-10-31 23:57:49.704642+05:30	4e440296-d558-46e6-b0f6-5fad5910a8f3	\N
855c156d-e6c2-4c28-828b-7aae706838e5	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	p5admin@gym.com	dummyhash	P5 Admin	9876541113	t	\N	\N	2026-11-01 19:14:38.714656+05:30	2026-11-01 19:14:38.714656+05:30	59179c14-86e4-4950-8833-74c46736bbee	9bc40a4f-d182-4a9b-817b-16979b96ac1d
c4d66014-2453-443f-8612-dd4b1edabb91	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	p5otheradmin@gym.com	dummyhash	P5 Other Admin	9876542223	t	\N	\N	2026-11-01 19:14:38.767843+05:30	2026-11-01 19:14:38.767843+05:30	b2bcd449-334f-482e-8f90-d1e731ac6ca9	bef3c9f9-e15c-435d-8615-3419ca30d617
1dfd5caa-5280-48b5-b195-d8ad1d7722f3	\N	d5owner@gym.com	mockhash	D5 Bulk Owner	9888877702	t	\N	\N	2026-11-01 21:42:20.632221+05:30	2026-11-01 21:42:20.632221+05:30	e93d6a19-7d4a-4032-956b-3b5a0936bc2c	\N
5f1e873a-b483-484a-ad12-b3749f16d61b	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5owner_8509@gym.com	mockhash	D5 Bulk Owner	988868509	t	\N	\N	2026-11-01 21:46:15.675569+05:30	2026-11-01 21:46:15.675569+05:30	3c5ea471-e574-4ffe-a088-437928965419	\N
d46825ad-0569-40c9-b3d0-ea037acd4b1e	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	admin_4971@test.com	hash	Admin User 4971	\N	t	\N	\N	2026-11-01 22:28:43.181002+05:30	2026-11-01 22:28:43.181002+05:30	9ea6c77d-0047-4d66-813e-b82e289f5dbb	86325440-5a8d-4a94-ba84-402b8e1b70c5
2d4d33e3-74e3-4094-b434-79fa55900e6e	03a28f49-3cdd-4d5a-a246-71996a171f43	fd_4971@test.com	hash	Front Desk 4971	\N	t	\N	\N	2026-11-01 22:28:43.209301+05:30	2026-11-01 22:28:43.209301+05:30	9ea6c77d-0047-4d66-813e-b82e289f5dbb	86325440-5a8d-4a94-ba84-402b8e1b70c5
ffb4b32c-fdcc-4f64-b993-6b1cd8198a3f	5c16df41-3ef3-44ce-b780-6cf468514448	trainer_4971@test.com	hash	Trainer 4971	\N	t	\N	\N	2026-11-01 22:28:43.211871+05:30	2026-11-01 22:28:43.211871+05:30	9ea6c77d-0047-4d66-813e-b82e289f5dbb	86325440-5a8d-4a94-ba84-402b8e1b70c5
bf7e9bfe-9358-4f47-85b0-bd6c2134aa74	03a28f49-3cdd-4d5a-a246-71996a171f43	frontdesk@testgym1.com	$2b$10$Qqq9ML0gUTEjNl6rt9FNzOESukarnWzUsOqzG5cj.plgu2igYlKti	Sneha Sharma	9876543220	t	\N	\N	2026-11-18 23:17:33.440854+05:30	2026-11-18 23:17:33.440854+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	2b0c6048-dbf6-4dae-b831-48111246603e
931ebcb7-60e6-4e1e-9a7b-3113bd1cce5a	5c16df41-3ef3-44ce-b780-6cf468514448	trainer_754135@test.com	$2b$10$Auf3oDkUDh4ekHkY26o9EuqmCDx.7Cqn0/1s8cfr1SpQXYUKyhC/i	Test Trainer 754135	9875413510	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI5MzFlYmNiNy02MGU2LTRlMWUtOWE3Yi0zMTEzYmQxY2NlNWEiLCJqdGkiOiJlMjkxMzM2NC02Zjg3LTQ0YTUtYjczYS04YWIyYjFhMjgyMWQiLCJpYXQiOjE3OTQ4NTM3NTUsImV4cCI6MTc5NTQ1ODU1NX0.S8Uztw2OcrGVNXMz6ujKqy4v7UHv36G7jxwUVEgOGOE	2026-11-16 23:59:15.218589+05:30	2026-11-16 23:59:14.595563+05:30	2026-11-16 23:59:15.218589+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
69aa7e5b-de7f-41c2-b2d9-d8f23811d5dd	03a28f49-3cdd-4d5a-a246-71996a171f43	frontdesk_754135@test.com	$2b$10$0SEcqJDDNBcsqIR/N4YpBeG6zlwsXs7ls.toETNv5vzV3qTuX/gAS	Test FrontDesk 754135	9875413520	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2OWFhN2U1Yi1kZTdmLTQxYzItYjJkOS1kOGYyMzgxMWQ1ZGQiLCJqdGkiOiJhMGRkYThkOC05OWJjLTQ4OWItOWY0ZC00MzgwYWI3MmI0M2IiLCJpYXQiOjE3OTQ4NTM3NTUsImV4cCI6MTc5NTQ1ODU1NX0.n3ev4Kk2kvykxPTo0M5wlJuArUg1QdKQgQf7SJWogms	2026-11-16 23:59:15.591718+05:30	2026-11-16 23:59:15.244695+05:30	2026-11-16 23:59:15.591718+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
3f4b4460-9999-4110-9249-a7dec2c8b592	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	adminstaff_754135@test.com	$2b$10$h8Wtpwo0Mt0w.5RrTfQTQerdgSHo68tHL3OW3eeXNX3tomToW.K5C	Test Admin 754135	9875413530	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzZjRiNDQ2MC05OTk5LTQxMTAtOTI0OS1hN2RlYzJjOGI1OTIiLCJqdGkiOiI2MDZkNDAwOC1kNjA4LTRjZTEtYTM5Yy03YzBmNTk3NjBlOGUiLCJpYXQiOjE3OTQ4NTM3NTUsImV4cCI6MTc5NTQ1ODU1NX0.SW6LczusuKZJjx4iUoWbakch64NB4zI4LeBrLew5Wy8	2026-11-16 23:59:15.947815+05:30	2026-11-16 23:59:15.609212+05:30	2026-11-16 23:59:15.947815+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
a01f4be1-1d3a-424e-8561-46a836a99c1b	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5owner_2171@gym.com	mockhash	D5 Bulk Owner	988862171	t	\N	\N	2026-11-01 21:48:13.197773+05:30	2026-11-01 21:48:13.197773+05:30	e008d4f0-a775-42c9-a8ca-7475c89df3b2	\N
7161afd7-861b-4c96-a6d5-09986bd831d3	5c16df41-3ef3-44ce-b780-6cf468514448	trainer_888549@test.com	$2b$10$BNURF1KC5C57JRHonX90Futf57Jyv/cP8/OTJ4M08rctriBxWm7h2	Test Trainer 888549	9888854910	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3MTYxYWZkNy04NjFiLTRjOTYtYTZkNS0wOTk4NmJkODMxZDMiLCJqdGkiOiIzNmNhY2JkMC02MDMyLTQ0ZmEtOGVmOC01NjZhNDI5OTBhYzIiLCJpYXQiOjE3OTQ4NTM4ODksImV4cCI6MTc5NTQ1ODY4OX0.B2RS8UYQDa6gE67ftSyLoM9Uc4F1P8zY6ksnM3b-JQU	2026-11-17 00:01:29.593995+05:30	2026-11-17 00:01:28.983425+05:30	2026-11-17 00:01:29.593995+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
bfff80aa-0ce9-48a6-b4a3-fcdd78741507	03a28f49-3cdd-4d5a-a246-71996a171f43	frontdesk_888549@test.com	$2b$10$OMXaIf28Bb3yqnTC7e6ZyOVED/FmA4JiSgdD681YI1QX0f5FiXR3y	Test FrontDesk 888549	9888854920	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJiZmZmODBhYS0wY2U5LTQ4YTYtYjRhMy1mY2RkNzg3NDE1MDciLCJqdGkiOiI1MWEyYzlmYy00ZjRkLTQ2YzUtOGFlOC04ZGUwYWFiN2JkM2MiLCJpYXQiOjE3OTQ4NTM4ODksImV4cCI6MTc5NTQ1ODY4OX0.x3nKTonzHB10GEHSI_G0KSSEtgaUwhPNHa1tr-5CFOM	2026-11-17 00:01:29.94344+05:30	2026-11-17 00:01:29.613924+05:30	2026-11-17 00:01:29.94344+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
1a2c920a-fb13-46a7-8686-c0aa719159ef	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	jpsmart27@gmail.com	$2b$10$JPbDNU/cRRGK2288aGNqaeHHsB6BTGOTIfW.uUYYOMZWzWFjp9QxC	Emma Watson	9876543215	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxYTJjOTIwYS1mYjEzLTQ2YTctODY4Ni1jMGFhNzE5MTU5ZWYiLCJpYXQiOjE3OTI5MzU2NzksImV4cCI6MTc5MzU0MDQ3OX0.YCdd2C-ad9BSDywgGjFaRdaUd0rUGKGa0ynI0C7d220	2026-10-25 13:08:41.620991+05:30	2026-10-11 11:27:28.584969+05:30	2026-10-31 18:15:25.802302+05:30	6ecfc033-52f1-444f-a3f6-65fdd664c988	\N
bf7bb5a0-f8f8-4b1b-8436-f2529f6e7948	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	admin_2536@test.com	hash	Admin User 2536	\N	t	\N	\N	2026-11-01 22:30:08.357865+05:30	2026-11-01 22:30:08.357865+05:30	3b2016b6-941b-4db1-a02d-507097e99e01	d9d3e18b-44fe-4c96-ac2c-c3e174bc8075
ae96fb86-17cf-4190-aec5-442f0adeece2	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	test@gym.com	$2b$10$OVptQomz2Z4l4bKJRLHnD.cMVZO0/3Jo3P8la3B336twyj7eKe69q	TESTING GYM-3	\N	t	\N	2026-11-01 00:02:34.147099+05:30	2026-11-01 00:01:56.404787+05:30	2026-11-01 11:01:00.68563+05:30	1d993780-4a56-4c02-8b31-c8af71c86ff7	\N
a7842488-a398-4478-8cd4-c4a64eb3bb22	03a28f49-3cdd-4d5a-a246-71996a171f43	fd_2536@test.com	hash	Front Desk 2536	\N	t	\N	\N	2026-11-01 22:30:08.371491+05:30	2026-11-01 22:30:08.371491+05:30	3b2016b6-941b-4db1-a02d-507097e99e01	d9d3e18b-44fe-4c96-ac2c-c3e174bc8075
92af5144-5446-4f37-aae7-406d87a56350	5c16df41-3ef3-44ce-b780-6cf468514448	trainer_2536@test.com	hash	Trainer 2536	\N	t	\N	\N	2026-11-01 22:30:08.374753+05:30	2026-11-01 22:30:08.374753+05:30	3b2016b6-941b-4db1-a02d-507097e99e01	d9d3e18b-44fe-4c96-ac2c-c3e174bc8075
752028ab-ec9f-4376-94eb-b3bc8348eff7	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	adminstaff_888549@test.com	$2b$10$3g.EfYoKcLRg7TCgKevAS.SoO1qPeIY7ooN4LSdq.SXOo2dWbpYla	Test Admin 888549	9888854930	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI3NTIwMjhhYi1lYzlmLTQzNzYtOTRlYi1iM2JjODM0OGVmZjciLCJqdGkiOiI0OTM0Mzk5NC1jODdmLTRlNzYtYmE3ZS1mZDZmMTE4NzA2Y2EiLCJpYXQiOjE3OTQ4NTM4OTAsImV4cCI6MTc5NTQ1ODY5MH0.i9Ber3r5zqx6qzvp_jV70Yp9qF0pGPf4m_NKH7FTzcQ	2026-11-17 00:01:30.29834+05:30	2026-11-17 00:01:29.959361+05:30	2026-11-17 00:01:30.29834+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
d502ffff-10d9-4402-a660-fe0e30f034fc	5c16df41-3ef3-44ce-b780-6cf468514448	trainer_902455@test.com	$2b$10$lTmGFgnKsqO2hDf4oJWOTuT16gfatzxJkWKna08Ud7y7JHFuQ7ALK	Test Trainer 902455	9890245510	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJkNTAyZmZmZi0xMGQ5LTQ0MDItYTY2MC1mZTBlMzBmMDM0ZmMiLCJqdGkiOiJmZjllZmY1OS1mMmMzLTRiYjgtODhhNS0yYTczNGM0N2NjYTEiLCJpYXQiOjE3OTQ4NTM5MDMsImV4cCI6MTc5NTQ1ODcwM30.4onAph9v0AE7tqwOVxZxxJXowWRNUgBSLzpOTIHzuNQ	2026-11-17 00:01:43.298877+05:30	2026-11-17 00:01:42.776962+05:30	2026-11-17 00:01:43.298877+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
92179506-658c-4a50-92e1-13e71664f688	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5admin1@test.com	dummyhash	D5 Admin 1	9876550006	t	\N	\N	2026-11-01 21:11:16.510303+05:30	2026-11-01 21:11:16.510303+05:30	2a5efdd1-aebf-4f3a-93de-fe673d727a55	\N
50dfe97d-1c7d-4ad6-8852-71eb85899df9	7c1df70d-e7c7-4723-a0a7-c6296ceb7366	d5admin2@test.com	dummyhash	D5 Admin 2	9876550007	t	\N	\N	2026-11-01 21:11:16.55934+05:30	2026-11-01 21:11:16.55934+05:30	46e49c9f-3bea-4b93-a86f-40b886ecdb60	\N
946a2d3e-351c-4834-acb3-e92dcf8ab84f	03a28f49-3cdd-4d5a-a246-71996a171f43	frontdesk_902455@test.com	$2b$10$79xZJU34IOI.zeItlYGXv.ShM0inpQW69K8oub4H34dGR221xC1Ti	Test FrontDesk 902455	9890245520	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI5NDZhMmQzZS0zNTFjLTQ4MzQtYWNiMy1lOTJkY2Y4YWI4NGYiLCJqdGkiOiI1MTNlYjg3Yi0xMzMxLTQxM2YtODAxYS1lODM0YmFjZTAyMjkiLCJpYXQiOjE3OTQ4NTM5MDMsImV4cCI6MTc5NTQ1ODcwM30.vfq-v547g0Upr892HVRAVeBGctyQZ2ji-oxycdDvoGU	2026-11-17 00:01:43.644676+05:30	2026-11-17 00:01:43.323069+05:30	2026-11-17 00:01:43.644676+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
7857b428-4e3f-473d-839c-79abda528973	570fec18-81bc-4524-80f5-79a4602aad34	admin@gym.com	$2b$12$5pTbqoOIXMPcv.PvDqMvtO0ffDvRDeTtxpHkZOVnqiX7X5ccin4VW	Jyothi Prakash	9629017245	t	\N	2026-11-19 23:11:43.206072+05:30	2026-08-15 22:29:32.240874+05:30	2026-11-19 23:11:43.344535+05:30	\N	\N
a6310a0f-5c7c-4474-89ea-58b07556858f	ce9ecddc-8832-4b1c-8b63-4081b9bb6d8d	adminstaff_902455@test.com	$2b$10$aiXknpSj0Bh3qTbuUjLaq.LCzZph1rxLJRKFEMp7dpr2Qrfe3DSWq	Test Admin 902455	9890245530	t	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJhNjMxMGEwZi01YzdjLTQ0NzQtODllYS01OGIwNzU1Njg1OGYiLCJqdGkiOiI4ZDFlZGM1Mi0zMjMxLTQ2MzItYTk2Mi0wZjRlYjYwNzA1MjciLCJpYXQiOjE3OTQ4NTM5MDQsImV4cCI6MTc5NTQ1ODcwNH0.6mv8zFPCs__PgQBejfVZ8xKwdZfw0jWP35CI7Oco6EM	2026-11-17 00:01:44.002084+05:30	2026-11-17 00:01:43.659217+05:30	2026-11-17 00:01:44.002084+05:30	1c3624e1-faa3-4de8-8244-9cc7723fe82c	de39de91-f4e1-4ac4-b856-aa8025115452
\.


--
-- Data for Name: workout_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workout_plans (id, member_id, trainer_id, title, goal, plan_details, ai_generated, valid_from, valid_until, notes, created_at, updated_at) FROM stdin;
\.


--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (id);


--
-- Name: ai_logs ai_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_logs
    ADD CONSTRAINT ai_logs_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: billing_plans billing_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_plans
    ADD CONSTRAINT billing_plans_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_code_key UNIQUE (code);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: diet_plans diet_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_pkey PRIMARY KEY (id);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: gym_module_configs gym_module_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gym_module_configs
    ADD CONSTRAINT gym_module_configs_pkey PRIMARY KEY (id);


--
-- Name: gym_role_permissions gym_role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gym_role_permissions
    ADD CONSTRAINT gym_role_permissions_pkey PRIMARY KEY (id);


--
-- Name: gyms gyms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gyms
    ADD CONSTRAINT gyms_pkey PRIMARY KEY (id);


--
-- Name: invoice_sequences invoice_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_sequences
    ADD CONSTRAINT invoice_sequences_pkey PRIMARY KEY (gym_id, year_month);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: lead_interactions lead_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_interactions
    ADD CONSTRAINT lead_interactions_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: maintenance_logs maintenance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_logs
    ADD CONSTRAINT maintenance_logs_pkey PRIMARY KEY (id);


--
-- Name: member_documents member_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents
    ADD CONSTRAINT member_documents_pkey PRIMARY KEY (id);


--
-- Name: member_memberships member_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_memberships
    ADD CONSTRAINT member_memberships_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: membership_plans membership_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_plans
    ADD CONSTRAINT membership_plans_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_module_action_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_module_action_key UNIQUE (module, action);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: push_tokens push_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: refunds refunds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: role_menu_items role_menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_menu_items
    ADD CONSTRAINT role_menu_items_pkey PRIMARY KEY (role_id, menu_item_id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: settings settings_gym_id_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_gym_id_key_key UNIQUE (gym_id, key);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance staff_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance
    ADD CONSTRAINT staff_attendance_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: invoices uq_invoices_gym_invoice_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT uq_invoices_gym_invoice_number UNIQUE (gym_id, invoice_number);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workout_plans workout_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plans
    ADD CONSTRAINT workout_plans_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_logs_feature; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_logs_feature ON public.ai_logs USING btree (feature);


--
-- Name: idx_attendance_branch_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_branch_date ON public.attendance USING btree (branch_id, attendance_date);


--
-- Name: idx_attendance_branch_date_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_branch_date_status ON public.attendance USING btree (branch_id, attendance_date, status);


--
-- Name: idx_attendance_checkin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_checkin ON public.attendance USING btree (check_in);


--
-- Name: idx_attendance_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_member ON public.attendance USING btree (member_id);


--
-- Name: idx_audit_logs_table; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_table ON public.audit_logs USING btree (table_name, record_id);


--
-- Name: idx_branches_gym_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_branches_gym_active ON public.branches USING btree (gym_id, is_active);


--
-- Name: idx_expenses_branch_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_expenses_branch_date ON public.expenses USING btree (branch_id, expense_date DESC);


--
-- Name: idx_invoices_branch_issued; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_branch_issued ON public.invoices USING btree (branch_id, issued_at DESC);


--
-- Name: idx_invoices_gym_issued; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_gym_issued ON public.invoices USING btree (gym_id, issued_at DESC);


--
-- Name: idx_invoices_gym_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_gym_number ON public.invoices USING btree (gym_id, invoice_number);


--
-- Name: idx_invoices_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_member ON public.invoices USING btree (member_id);


--
-- Name: idx_invoices_payment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_payment ON public.invoices USING btree (payment_id);


--
-- Name: idx_leads_branch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leads_branch ON public.leads USING btree (branch_id);


--
-- Name: idx_leads_branch_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leads_branch_status ON public.leads USING btree (branch_id, status);


--
-- Name: idx_leads_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leads_status ON public.leads USING btree (status);


--
-- Name: idx_member_memberships_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_member_memberships_composite ON public.member_memberships USING btree (member_id, status, end_date);


--
-- Name: idx_member_memberships_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_member_memberships_member ON public.member_memberships USING btree (member_id);


--
-- Name: idx_member_memberships_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_member_memberships_status ON public.member_memberships USING btree (status);


--
-- Name: idx_members_branch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_branch ON public.members USING btree (branch_id);


--
-- Name: idx_members_branch_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_branch_active ON public.members USING btree (branch_id, is_active);


--
-- Name: idx_membership_plans_branch_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_membership_plans_branch_active ON public.membership_plans USING btree (branch_id, is_active);


--
-- Name: idx_messages_gym_branch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_gym_branch ON public.messages USING btree (gym_id, branch_id);


--
-- Name: idx_messages_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_is_active ON public.messages USING btree (is_active);


--
-- Name: idx_notifications_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_status ON public.notifications USING btree (status);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id);


--
-- Name: idx_payments_branch_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_branch_date ON public.payments USING btree (branch_id, payment_date DESC);


--
-- Name: idx_payments_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_date ON public.payments USING btree (payment_date);


--
-- Name: idx_payments_member; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_member ON public.payments USING btree (member_id);


--
-- Name: idx_users_branch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_branch ON public.users USING btree (branch_id) WHERE (branch_id IS NOT NULL);


--
-- Name: idx_users_gym_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_gym_role ON public.users USING btree (gym_id, role_id);


--
-- Name: uq_attendance_member_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_attendance_member_date ON public.attendance USING btree (member_id, attendance_date);


--
-- Name: uq_gym_module_configs; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_gym_module_configs ON public.gym_module_configs USING btree (COALESCE(gym_id, '00000000-0000-0000-0000-000000000000'::uuid), module_id);


--
-- Name: uq_gym_role_permissions; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_gym_role_permissions ON public.gym_role_permissions USING btree (COALESCE(gym_id, '00000000-0000-0000-0000-000000000000'::uuid), role_id, permission_key);


--
-- Name: uq_invoices_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_invoices_payment_id ON public.invoices USING btree (payment_id) WHERE (payment_id IS NOT NULL);


--
-- Name: achievements achievements_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: ai_logs ai_logs_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_logs
    ADD CONSTRAINT ai_logs_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: ai_logs ai_logs_triggered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_logs
    ADD CONSTRAINT ai_logs_triggered_by_fkey FOREIGN KEY (triggered_by) REFERENCES public.users(id);


--
-- Name: attendance attendance_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: attendance attendance_marked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_marked_by_fkey FOREIGN KEY (marked_by) REFERENCES public.users(id);


--
-- Name: attendance attendance_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: branches branches_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: branches branches_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);


--
-- Name: coupons coupons_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id);


--
-- Name: diet_plans diet_plans_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: diet_plans diet_plans_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_trainer_id_fkey FOREIGN KEY (trainer_id) REFERENCES public.staff(id);


--
-- Name: equipment equipment_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: expenses expenses_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: gym_module_configs gym_module_configs_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gym_module_configs
    ADD CONSTRAINT gym_module_configs_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: gym_role_permissions gym_role_permissions_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gym_role_permissions
    ADD CONSTRAINT gym_role_permissions_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: gyms gyms_billing_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gyms
    ADD CONSTRAINT gyms_billing_plan_id_fkey FOREIGN KEY (billing_plan_id) REFERENCES public.billing_plans(id);


--
-- Name: gyms gyms_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gyms
    ADD CONSTRAINT gyms_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: invoice_sequences invoice_sequences_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_sequences
    ADD CONSTRAINT invoice_sequences_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: invoices invoices_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: lead_interactions lead_interactions_done_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_interactions
    ADD CONSTRAINT lead_interactions_done_by_fkey FOREIGN KEY (done_by) REFERENCES public.users(id);


--
-- Name: lead_interactions lead_interactions_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_interactions
    ADD CONSTRAINT lead_interactions_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: leads leads_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: leads leads_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: leads leads_converted_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_converted_member_id_fkey FOREIGN KEY (converted_member_id) REFERENCES public.members(id);


--
-- Name: maintenance_logs maintenance_logs_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_logs
    ADD CONSTRAINT maintenance_logs_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipment(id) ON DELETE CASCADE;


--
-- Name: member_documents member_documents_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents
    ADD CONSTRAINT member_documents_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_memberships member_memberships_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_memberships
    ADD CONSTRAINT member_memberships_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id);


--
-- Name: member_memberships member_memberships_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_memberships
    ADD CONSTRAINT member_memberships_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_memberships member_memberships_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_memberships
    ADD CONSTRAINT member_memberships_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.membership_plans(id);


--
-- Name: members members_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: members members_referred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_referred_by_fkey FOREIGN KEY (referred_by) REFERENCES public.members(id);


--
-- Name: members members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: membership_plans membership_plans_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_plans
    ADD CONSTRAINT membership_plans_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: messages messages_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: messages messages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: messages messages_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id);


--
-- Name: notifications notifications_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payments payments_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: payments payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: payments payments_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: payments payments_membership_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_membership_id_fkey FOREIGN KEY (membership_id) REFERENCES public.member_memberships(id);


--
-- Name: plans plans_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: push_tokens push_tokens_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: push_tokens push_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_referred_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referred_id_fkey FOREIGN KEY (referred_id) REFERENCES public.members(id);


--
-- Name: referrals referrals_referrer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES public.members(id);


--
-- Name: refunds refunds_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: refunds refunds_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: refunds refunds_refunded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_refunded_by_fkey FOREIGN KEY (refunded_by) REFERENCES public.users(id);


--
-- Name: reviews reviews_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: reviews reviews_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: reviews reviews_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_trainer_id_fkey FOREIGN KEY (trainer_id) REFERENCES public.staff(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: settings settings_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: staff_attendance staff_attendance_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance
    ADD CONSTRAINT staff_attendance_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: staff_attendance staff_attendance_marked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance
    ADD CONSTRAINT staff_attendance_marked_by_fkey FOREIGN KEY (marked_by) REFERENCES public.users(id);


--
-- Name: staff_attendance staff_attendance_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance
    ADD CONSTRAINT staff_attendance_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id) ON DELETE CASCADE;


--
-- Name: staff staff_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: staff staff_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: staff staff_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: subscriptions subscriptions_billing_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_billing_plan_id_fkey FOREIGN KEY (billing_plan_id) REFERENCES public.billing_plans(id);


--
-- Name: subscriptions subscriptions_gym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_gym_id_fkey FOREIGN KEY (gym_id) REFERENCES public.gyms(id) ON DELETE CASCADE;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: workout_plans workout_plans_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plans
    ADD CONSTRAINT workout_plans_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: workout_plans workout_plans_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plans
    ADD CONSTRAINT workout_plans_trainer_id_fkey FOREIGN KEY (trainer_id) REFERENCES public.staff(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 98VY5NnEcWNqXw9vv2j8injtRMWu5KWPeBkZjDgSFXqR2SznwZ4Ckd4W3Yre7D7

